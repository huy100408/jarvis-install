#!/usr/bin/env python3
"""
Exports Antigravity credentials from macOS Keychain and installed app
into secure account.json and oauth-client.json files for JARVIS Bridge.
Verifies and refreshes tokens directly against Google OAuth.
"""

from __future__ import annotations

import base64
import datetime
import json
import os
import re
import socket
import ssl
import subprocess
import sys
import urllib.error
import urllib.parse
import urllib.request
from contextlib import contextmanager
from pathlib import Path

def _unique(items: list[str], limit: int = 20) -> list[str]:
    seen: list[str] = []
    for item in items:
        if item not in seen:
            seen.append(item)
        if len(seen) >= limit:
            break
    return seen


def _windows_language_servers() -> list[Path]:
    """Antigravity's language server on Windows: running copies first, then install folders."""
    found: list[Path] = []
    try:
        out = subprocess.check_output(
            ["powershell", "-NoProfile", "-Command",
             "Get-CimInstance Win32_Process | Where-Object { $_.Name -like 'language_server*' } | ForEach-Object { $_.ExecutablePath }"],
            stderr=subprocess.DEVNULL, timeout=20,
        ).decode(errors="ignore")
        found += [Path(line.strip()) for line in out.splitlines() if line.strip()]
    except Exception:
        pass
    roots = [Path.home() / ".gemini" / "antigravity"]
    for env in ("LOCALAPPDATA", "ProgramFiles", "ProgramFiles(x86)"):
        base = os.environ.get(env)
        if base:
            roots += [Path(base) / "Programs" / "Antigravity", Path(base) / "Antigravity"]
    for root in roots:
        if root.is_dir():
            try:
                found += [p for p in root.rglob("language_server*") if p.is_file() and p.stat().st_size > 1_000_000]
            except OSError:
                continue
    return found


def discover_oauth_material() -> tuple[list[str], list[str]]:
    """Scan local Antigravity binaries for OAuth client ids and secrets.

    Go rodata stores the strings independently, so ids and secrets are not
    paired by position. Callers try the cartesian product.
    """
    cids: list[str] = []
    secs: list[str] = []

    if sys.platform == "win32":
        bin_candidates = _windows_language_servers()
    else:
        bin_candidates = [
            Path("/Applications/Antigravity.app/Contents/Resources/bin/language_server"),
            Path.home() / "Applications/Antigravity.app/Contents/Resources/bin/language_server",
            Path.home() / ".gemini/antigravity/bin/language_server",
        ]
        try:
            ps_out = subprocess.check_output(["ps", "-A", "-o", "command"], stderr=subprocess.DEVNULL).decode()
            for line in ps_out.splitlines():
                if "language_server" in line:
                    cmd_bin = line.split()[0]
                    if Path(cmd_bin).is_file():
                        bin_candidates.insert(0, Path(cmd_bin))
        except Exception:
            pass

    files: list[Path] = []
    seen_paths: set[Path] = set()
    for candidate in bin_candidates:
        if candidate.is_file() and candidate not in seen_paths:
            seen_paths.add(candidate)
            files.append(candidate)
    # The real language_server is the large binary. Scan it before small helpers
    # so a decoy earlier in the list cannot crowd out the live client.
    files.sort(key=lambda path: path.stat().st_size, reverse=True)

    for candidate in files:
        try:
            data = candidate.read_bytes()
            cids.extend(m.group(0).decode("utf-8") for m in re.finditer(rb"[0-9]+-[A-Za-z0-9_-]+\.apps\.googleusercontent\.com", data))
            # Secrets in Go rodata are GOCSPX- followed by 28 base64url characters (35 chars total)
            secs.extend(m.group(0).decode("utf-8") for m in re.finditer(rb"GOCSPX-[a-zA-Z0-9_-]{28}", data))
        except Exception:
            continue

    return _unique(cids), _unique(secs)


def _google_client_id(value: object) -> str | None:
    if isinstance(value, str) and value.endswith(".apps.googleusercontent.com") and 20 < len(value) < 200:
        return value
    return None


def _client_id_from_jwt(token: str) -> str | None:
    if token.count(".") < 2:
        return None
    try:
        segment = token.split(".")[1]
        segment += "=" * (-len(segment) % 4)
        payload = json.loads(base64.urlsafe_b64decode(segment))
    except Exception:
        return None
    if not isinstance(payload, dict):
        return None
    for key in ("azp", "aud"):
        found = _google_client_id(payload.get(key))
        if found:
            return found
    return None


def _ssl_context() -> ssl.SSLContext:
    """Trust the macOS system store. python.org builds ship with no CA bundle."""
    try:
        ctx = ssl.create_default_context()
    except Exception:
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
        ctx.check_hostname = True
        ctx.verify_mode = ssl.CERT_REQUIRED
    for path in ("/etc/ssl/cert.pem", "/private/etc/ssl/cert.pem"):
        if os.path.isfile(path):
            try:
                ctx.load_verify_locations(cafile=path)
            except ssl.SSLError:
                pass
            break
    try:
        import certifi
        ctx.load_verify_locations(cafile=certifi.where())
    except Exception:
        pass
    return ctx


_OPENER: urllib.request.OpenerDirector | None = None


def _opener() -> urllib.request.OpenerDirector:
    global _OPENER
    if _OPENER is None:
        # Ignore HTTP_PROXY. The refresh token must go only to Google.
        _OPENER = urllib.request.build_opener(
            urllib.request.ProxyHandler({}),
            urllib.request.HTTPSHandler(context=_ssl_context()),
        )
    return _OPENER


@contextmanager
def _force_ipv4():
    original = socket.getaddrinfo

    def getaddrinfo(host, port, family=0, type=0, proto=0, flags=0):
        return original(host, port, socket.AF_INET, type, proto, flags)

    socket.getaddrinfo = getaddrinfo
    try:
        yield
    finally:
        socket.getaddrinfo = original


def _open(make, timeout: float = 8):
    """Open a request. One IPv6 failure retries on IPv4. Never log the request."""
    try:
        return _opener().open(make(), timeout=timeout)
    except urllib.error.HTTPError:
        raise
    except Exception:
        with _force_ipv4():
            return _opener().open(make(), timeout=timeout)


def _transport_kind(exc: BaseException) -> str:
    """A short failure name. The exception text can contain the request URL."""
    reason = getattr(exc, "reason", exc)
    for item in (reason, exc, getattr(reason, "__cause__", None)):
        if item is None:
            continue
        if isinstance(item, ssl.SSLError) or "SSL" in type(item).__name__:
            return "certificate"
        if isinstance(item, (TimeoutError, socket.timeout)):
            return "timeout"
        if isinstance(item, socket.gaierror):
            return "dns"
        if isinstance(item, ConnectionRefusedError):
            return "refused"
    errno = getattr(reason, "errno", None)
    if errno in (60, 110):
        return "timeout"
    if errno == 61:
        return "refused"
    return "unreachable"


def _post_form(url: str, fields: dict[str, str]) -> dict:
    body = urllib.parse.urlencode(fields).encode("utf-8")

    def make() -> urllib.request.Request:
        return urllib.request.Request(
            url,
            data=body,
            headers={"content-type": "application/x-www-form-urlencoded"},
            method="POST",
        )

    with _open(make, timeout=8) as resp:
        payload = json.loads(resp.read().decode("utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("response")
    return payload


def _client_id_from_tokeninfo(access_token: str) -> str | None:
    """Ask Google which OAuth client issued this access token. Never log the token."""
    if not access_token:
        return None
    url = "https://oauth2.googleapis.com/tokeninfo?access_token=" + urllib.parse.quote(access_token, safe="")
    try:
        with _open(lambda: urllib.request.Request(url), timeout=8) as resp:
            payload = json.loads(resp.read().decode("utf-8"))
    except Exception:
        return None
    if not isinstance(payload, dict):
        return None
    for key in ("azp", "aud"):
        found = _google_client_id(payload.get(key))
        if found:
            return found
    return None


def _oauth_error(exc: BaseException) -> str:
    if isinstance(exc, urllib.error.HTTPError):
        try:
            body = json.loads(exc.read().decode("utf-8", "replace"))
            err = body.get("error") if isinstance(body, dict) else None
            if isinstance(err, str) and re.fullmatch(r"[a-z_]{1,40}", err):
                return err
        except Exception:
            pass
        return f"http_{exc.code}"
    return "unreachable"


def _format_errors(errors: dict[str, int]) -> str:
    if not errors:
        return "no response from Google"
    return ", ".join(f"{name} x{count}" for name, count in sorted(errors.items()))


def verify_or_refresh(
    client_ids: list[str],
    client_secrets: list[str],
    refresh_token: str,
    preferred_id: str | None = None,
) -> tuple[str, str, str | None, int | None, dict[str, int]]:
    """Test id/secret pairs against Google. The client that issued the login is tried first."""
    errors: dict[str, int] = {}
    if not client_secrets or not refresh_token:
        return "", "", None, None, errors

    ordered: list[str] = []
    if preferred_id:
        ordered.append(preferred_id)
    for cid in client_ids:
        if cid not in ordered:
            ordered.append(cid)
    if not ordered:
        return "", "", None, None, errors

    attempts = 0
    for cid in ordered:
        for sec in client_secrets:
            if attempts >= 40:
                return "", "", None, None, errors
            attempts += 1
            try:
                data = _post_form("https://oauth2.googleapis.com/token", {
                    "client_id": cid,
                    "client_secret": sec,
                    "refresh_token": refresh_token,
                    "grant_type": "refresh_token",
                })
                new_access_token = data.get("access_token")
                expires_in = data.get("expires_in", 3600)
                if not isinstance(new_access_token, str) or not new_access_token:
                    errors["empty_token"] = errors.get("empty_token", 0) + 1
                    continue
                if not isinstance(expires_in, (int, float)):
                    expires_in = 3600
                expires_at = int((datetime.datetime.now(datetime.timezone.utc).timestamp() + expires_in) * 1000)
                return cid, sec, new_access_token, expires_at, errors
            except urllib.error.HTTPError as exc:
                code = _oauth_error(exc)
                errors[code] = errors.get(code, 0) + 1
                # A wrong secret is invalid_client. invalid_grant on any other
                # client means that client did not issue this refresh token.
                # Keep trying every secret for the client that actually issued it.
                if code == "invalid_grant" and cid != preferred_id:
                    break
            except Exception as exc:
                # Same network failure for every pair. Do not sit through it again.
                kind = _transport_kind(exc)
                errors[kind] = errors.get(kind, 0) + 1
                return "", "", None, None, errors

    return "", "", None, None, errors


def _expiry_ms(value: object) -> int:
    if isinstance(value, (int, float)):
        number = float(value)
        if number > 10_000_000_000:
            return int(number)
        if number > 1_000_000_000:
            return int(number * 1000)
        return 0
    if isinstance(value, str):
        try:
            return int(datetime.datetime.fromisoformat(value).timestamp() * 1000)
        except Exception:
            return 0
    return 0


def _login_record(data: dict, source: str) -> dict | None:
    token = data.get("token") if isinstance(data.get("token"), dict) else data
    if not isinstance(token, dict):
        return None
    refresh = token.get("refresh_token")
    if not isinstance(refresh, str) or not refresh:
        return None
    access = token.get("access_token") if isinstance(token.get("access_token"), str) else ""
    email = data.get("id_token_email") or data.get("email") or "antigravity"
    if not isinstance(email, str) or not email.strip():
        email = "antigravity"
    id_token = ""
    for candidate in (data.get("id_token"), token.get("id_token")):
        if isinstance(candidate, str) and candidate.count(".") >= 2:
            id_token = candidate
            break
    return {
        "source": source,
        "refresh_token": refresh,
        "access_token": access,
        "email": email,
        "id_token": id_token,
        "expiry": _expiry_ms(token.get("expiry") or token.get("expires_at")),
    }


def _read_windows_credential() -> dict | None:
    """Antigravity saves its login with go-keyring, which uses Credential Manager target "gemini:antigravity"."""
    import ctypes
    from ctypes import wintypes

    class CREDENTIAL(ctypes.Structure):
        _fields_ = [("Flags", wintypes.DWORD), ("Type", wintypes.DWORD), ("TargetName", wintypes.LPWSTR),
                    ("Comment", wintypes.LPWSTR), ("LastWritten", wintypes.FILETIME),
                    ("CredentialBlobSize", wintypes.DWORD), ("CredentialBlob", ctypes.POINTER(ctypes.c_ubyte)),
                    ("Persist", wintypes.DWORD), ("AttributeCount", wintypes.DWORD), ("Attributes", ctypes.c_void_p),
                    ("TargetAlias", wintypes.LPWSTR), ("UserName", wintypes.LPWSTR)]

    advapi = ctypes.WinDLL("advapi32", use_last_error=True)
    advapi.CredReadW.argtypes = [wintypes.LPCWSTR, wintypes.DWORD, wintypes.DWORD, ctypes.POINTER(ctypes.POINTER(CREDENTIAL))]
    advapi.CredReadW.restype = wintypes.BOOL
    advapi.CredFree.argtypes = [ctypes.c_void_p]
    for target in ("gemini:antigravity", "antigravity@gemini", "gemini"):
        cred = ctypes.POINTER(CREDENTIAL)()
        if not advapi.CredReadW(target, 1, 0, ctypes.byref(cred)):
            continue
        try:
            blob = ctypes.string_at(cred.contents.CredentialBlob, cred.contents.CredentialBlobSize)
        finally:
            advapi.CredFree(cred)
        for encoding in ("utf-8", "utf-16-le"):
            try:
                record = _parse_secret(blob.decode(encoding), "Windows Credential Manager")
            except UnicodeDecodeError:
                continue
            if record:
                return record
    return None


def _parse_secret(raw: str, source: str) -> dict | None:
    raw = raw.strip().strip("\x00")
    if raw.startswith("go-keyring-base64:"):
        try:
            raw = base64.b64decode(raw.split(":", 1)[1]).decode()
        except Exception:
            return None
    try:
        data = json.loads(raw)
    except Exception:
        return None
    return _login_record(data, source) if isinstance(data, dict) else None


def _read_keychain() -> dict | None:
    if sys.platform == "win32":
        try:
            return _read_windows_credential()
        except Exception:
            return None
    try:
        raw = subprocess.check_output(
            ["security", "find-generic-password", "-s", "gemini", "-a", "antigravity", "-w"],
            stderr=subprocess.DEVNULL,
        ).decode().strip()
    except (subprocess.CalledProcessError, OSError):
        return None
    return _parse_secret(raw, "macOS Keychain")


def _read_jetski() -> dict | None:
    path = Path.home() / ".gemini" / "jetski-standalone-oauth-token"
    try:
        data = json.loads(path.read_text())
    except Exception:
        return None
    if not isinstance(data, dict):
        return None
    return _login_record(data, "Antigravity login file")


def _hint_client_id(login: dict) -> str | None:
    if login.get("id_token"):
        found = _client_id_from_jwt(login["id_token"])
        if found:
            return found
    return _client_id_from_tokeninfo(login.get("access_token") or "")


def main():
    print("Reading Antigravity credentials...")
    logins: list[dict] = []
    keychain = _read_keychain()
    if keychain:
        logins.append(keychain)
    jetski = _read_jetski()
    if jetski and all(item["refresh_token"] != jetski["refresh_token"] for item in logins):
        logins.append(jetski)
    if not logins:
        print("\nERROR: No Antigravity credentials found.")
        print("Make sure Antigravity is installed and signed in on this computer.")
        sys.exit(1)
    logins.sort(key=lambda item: item["expiry"], reverse=True)

    client_ids, client_secrets = discover_oauth_material()
    if not client_secrets:
        print("\nERROR: Could not locate Antigravity language_server binary to extract OAuth client.")
        print("Install Antigravity from https://antigravity.google and open it once.")
        sys.exit(1)

    chosen: tuple[dict, str, str, str, int] | None = None
    reports: list[tuple[str, dict[str, int]]] = []
    for login in logins:
        hint = _hint_client_id(login)
        client_id, client_secret, refreshed_token, refreshed_expiry, errors = verify_or_refresh(
            client_ids, client_secrets, login["refresh_token"], hint
        )
        if client_id and refreshed_token and refreshed_expiry:
            chosen = (login, client_id, client_secret, refreshed_token, refreshed_expiry)
            break
        reports.append((login["source"], errors))

    if chosen is None:
        transport = {"unreachable", "timeout", "dns", "refused", "certificate"}
        network = bool(reports) and all(set(errors) <= transport for _, errors in reports)
        if network:
            print("\nERROR: Could not reach Google to check the Antigravity login.")
        else:
            print("\nERROR: Google rejected every saved Antigravity login.")
        for source, errors in reports:
            print(f"  • {source}: {_format_errors(errors)}")
        if any("invalid_grant" in errors for _, errors in reports):
            print("Quit Antigravity completely, sign in again, then run: jarvis link")
        elif network and any("certificate" in errors for _, errors in reports):
            print("Could not verify Google's certificate from this computer.")
        sys.exit(1)

    login, client_id, client_secret, access_token, expires_at = chosen
    refresh_token = login["refresh_token"]
    email = login["email"]
    print(f"  • Using {login['source']}")
    print(f"  • Refreshed live access token via Google OAuth (expires in {int((expires_at - datetime.datetime.now(datetime.timezone.utc).timestamp()*1000)/1000)}s)")

    out_dir = Path.home() / ".jarvis-credentials"
    out_dir.mkdir(mode=0o700, parents=True, exist_ok=True)

    client_path = out_dir / "oauth-client.json"
    client_data = {
        "installed": {
            "client_id": client_id,
            "client_secret": client_secret,
        }
    }
    client_path.write_text(json.dumps(client_data, indent=2) + "\n")
    client_path.chmod(0o600)
    print(f"  • Verified OAuth client ({client_path})")

    # Write account.json
    account_path = out_dir / "account.json"
    account_data = {
        "label": email,
        "access_token": access_token,
        "expires_at": expires_at,
        "project_id": "aicode-consumers",
    }
    if refresh_token:
        account_data["refresh_token"] = refresh_token

    account_path.write_text(json.dumps(account_data, indent=2) + "\n")
    account_path.chmod(0o600)

    bridge_dir = Path.home() / "Library/Application Support/JARVIS/bridge"
    if bridge_dir.exists():
        bridge_dir.chmod(0o700)

    print("\nSUCCESS! Exported Antigravity credentials:")
    print(f"  • Account:      {email}")
    print(f"  • Account File: {account_path}")
    print("\nCredentials exported and verified.\n")


def connect_bridge(port_str: str) -> None:
    """Save bridge credentials and URL into provider-settings.json and the system credential store."""
    import uuid
    try:
        port = int(port_str)
        if not (1024 <= port <= 65535):
            raise ValueError
    except Exception:
        port = 20128

    key = sys.stdin.read().strip()
    if len(key) < 32 or any(c in key for c in ("\n", "\r", "\x00")):
        print("Invalid bridge API key.", file=sys.stderr)
        sys.exit(1)

    account = "provider-" + uuid.uuid4().hex
    path = Path.home() / "Library/Application Support/JARVIS/server/provider-settings.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    data = {
        "base_url": f"http://127.0.0.1:{port}/v1",
        "protocol": "openai",
        "model": "gemini-3-flash",
        "computer_use_enabled": False,
        "turbo_mode": False,
        "auto_approve": False,
        "safe_mode": False,
        "tts_engine": "kokoro",
        "kokoro_voice": "af_heart",
        "honorific": "Sir",
        "revision": 1,
        "secret_account": account,
    }
    if path.exists():
        try:
            existing = json.loads(path.read_text(encoding="utf-8"))
            for name, value in existing.items():
                if name not in ("base_url", "protocol", "secret_account"):
                    data[name] = value
            data["revision"] = int(existing.get("revision", 0)) + 1
        except Exception:
            pass

    if data.get("model") in ("gemini-3.8-flash-high", "gemini-3.8-flash-low", "gemini-2.5-flash-lite"):
        data["model"] = "gemini-3-flash"

    try:
        if sys.platform == "win32":
            from keyring.backends.Windows import WinVaultKeyring
            store = WinVaultKeyring()
        elif sys.platform == "darwin":
            from keyring.backends.macOS import Keyring
            store = Keyring()
        else:
            import keyring
            store = keyring.get_keyring()
        store.set_password("com.jarvis.provider-settings", account, key)
        store.set_password("com.jarvis.provider-settings", "provider_key", key)
    except Exception as exc:
        print(f"Failed to save bridge key to system credential store: {exc}", file=sys.stderr)
        sys.exit(1)

    path.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
    print(f"Connected Jarvis to Antigravity bridge at http://127.0.0.1:{port}/v1")


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "--connect-bridge":
        port = sys.argv[2] if len(sys.argv) > 2 else "20128"
        connect_bridge(port)
        sys.exit(0)
    main()
