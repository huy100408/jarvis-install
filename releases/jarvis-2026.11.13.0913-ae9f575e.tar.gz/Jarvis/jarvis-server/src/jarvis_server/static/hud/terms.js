// Terms gate for the Windows HUD: shows the Terms of Service and Privacy Policy
// until the current version is accepted. Mirrors TermsGateView.swift on Mac and iPhone.
(function () {
  'use strict';
  var H = window.JarvisHUD;
  if (!H) return;
  var KEY = 'jarvis.termsAccepted';

  // Renders the small Markdown subset used by terms.md with DOM nodes only (no innerHTML).
  function inline(parent, text) {
    text.split(/(\*\*[^*]+\*\*|https?:\/\/[^\s)]+)/).forEach(function (part) {
      if (!part) return;
      if (/^\*\*.+\*\*$/.test(part)) {
        var b = document.createElement('strong'); b.textContent = part.slice(2, -2); parent.appendChild(b);
      } else if (/^https?:\/\//.test(part)) {
        var url = part.replace(/[.,;]+$/, ''), a = document.createElement('a');
        a.href = url; a.textContent = url; a.target = '_blank'; a.rel = 'noopener';
        parent.appendChild(a); if (url !== part) parent.appendChild(document.createTextNode(part.slice(url.length)));
      } else parent.appendChild(document.createTextNode(part));
    });
  }
  function render(md, into) {
    var list = null;
    md.split(/\r?\n/).forEach(function (line) {
      var el;
      if (/^Version:/.test(line)) { el = document.createElement('p'); el.className = 'terms-ver'; el.textContent = line; }
      else if (/^# /.test(line)) { el = document.createElement('h2'); inline(el, line.slice(2)); }
      else if (/^## /.test(line)) { el = document.createElement('h3'); inline(el, line.slice(3)); }
      else if (/^- /.test(line)) {
        if (!list) { list = document.createElement('ul'); into.appendChild(list); }
        var li = document.createElement('li'); inline(li, line.slice(2)); list.appendChild(li); return;
      } else if (line.trim()) { el = document.createElement('p'); inline(el, line); }
      list = null;
      if (el) into.appendChild(el);
    });
  }

  var css = document.createElement('style');
  css.textContent =
    '#termsGate{position:fixed;inset:0;margin:auto;width:min(760px,calc(100vw - 32px));height:min(88vh,860px);max-width:none;max-height:none;padding:0;' +
    'border:1px solid rgba(0,229,255,.35);border-radius:14px;background:#070b12;color:#e6f4ff;display:flex;flex-direction:column;overflow:hidden}' +
    '#termsGate:not([open]){display:none}#termsGate::backdrop{background:rgba(2,4,8,.92)}' +
    '#termsGate header{padding:20px 24px 12px;border-bottom:1px solid rgba(255,255,255,.08)}' +
    '#termsGate header p{margin:0 0 4px;font:700 11px/1.4 ui-monospace,monospace;letter-spacing:.18em;color:#00e5ff}' +
    '#termsGate header h1{margin:0;font-size:20px}' +
    '#termsBody{flex:1;overflow:auto;padding:8px 24px 16px;font-size:14px;line-height:1.6;color:#c9d6e3}' +
    '#termsBody h2{font-size:18px;color:#fff}#termsBody h3{font-size:15px;color:#fff;margin:20px 0 6px}' +
    '#termsBody a{color:#00e5ff}#termsBody ul{padding-left:20px}.terms-ver{font:12px ui-monospace,monospace;color:#7d8fa3}' +
    '#termsGate footer{padding:14px 24px 18px;border-top:1px solid rgba(255,255,255,.08);display:flex;flex-wrap:wrap;gap:12px;align-items:center}' +
    '#termsGate label{flex:1 1 280px;display:flex;gap:10px;align-items:flex-start;font-size:14px;cursor:pointer}' +
    '#termsGate input{width:18px;height:18px;margin-top:2px;accent-color:#00e5ff}' +
    '#termsAccept{min-height:44px;padding:0 22px;border:0;border-radius:10px;background:#00e5ff;color:#001018;font-weight:700;cursor:pointer}' +
    '#termsAccept:disabled{opacity:.4;cursor:not-allowed}#termsAccept:focus-visible,#termsGate input:focus-visible{outline:2px solid #fff;outline-offset:2px}' +
    '#termsNote{flex-basis:100%;margin:0;font-size:12px;color:#7d8fa3}';
  document.head.appendChild(css);

  fetch('/hud/assets/terms.md').then(function (r) { return r.ok ? r.text() : ''; }).then(function (md) {
    var version = (/^Version:\s*(\S+)/.exec(md) || [])[1];
    if (!version || H.store.get(KEY) === version) return;
    var dlg = document.createElement('dialog');
    dlg.id = 'termsGate';
    dlg.setAttribute('aria-labelledby', 'termsTitle');
    dlg.innerHTML =
      '<header><p>BEFORE YOU START</p><h1 id="termsTitle">Terms of Service and Privacy Policy</h1></header>' +
      '<div id="termsBody" tabindex="0"></div>' +
      '<footer><label><input type="checkbox" id="termsCheck"> I have read and agree to the Terms of Service and Privacy Policy.</label>' +
      '<button type="button" id="termsAccept" disabled>I Agree</button>' +
      '<p id="termsNote">If you do not agree, close this window and uninstall Jarvis with <code>jarvis uninstall</code>.</p></footer>';
    render(md, dlg.querySelector('#termsBody'));
    document.body.appendChild(dlg);
    var check = dlg.querySelector('#termsCheck'), accept = dlg.querySelector('#termsAccept');
    check.onchange = function () { accept.disabled = !check.checked; };
    dlg.addEventListener('cancel', function (e) { e.preventDefault(); }); // Esc must not skip the terms
    accept.onclick = function () { H.store.set(KEY, version); dlg.close(); dlg.remove(); };
    dlg.showModal();
    check.focus();
  }).catch(function () {});
})();
