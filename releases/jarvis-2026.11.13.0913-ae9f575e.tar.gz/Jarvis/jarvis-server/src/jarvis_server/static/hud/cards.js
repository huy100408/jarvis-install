// HUD result cards, matching the Mac app (HUDPreviewCards, HUDPictureStrip, HUDWeatherCard,
// HUDCodeBlockView, HUDCesiumGlobe, HUDShellView). Every string from a tool goes in through
// textContent; links and images only take http(s) URLs.
(function () {
  'use strict';
  var H = window.JarvisHUD;
  if (!H) return;
  var SVG = 'http://www.w3.org/2000/svg';

  var css = document.createElement('style');
  css.textContent = [
    '.xc{pointer-events:auto;max-width:min(520px,100%);animation:hcin .35s ease both;--xc-ice:#bae6fd;--xc-muted:#7fb2f5;--xc-text:#e2e8f0;--xc-blue:#3b82f6}',
    'html[data-theme="light"] .xc{--xc-ice:#0369a1;--xc-muted:#4b6a96;--xc-text:#1c1c1e}',
    '.xc-stack{display:flex;flex-direction:column;gap:10px}',
    '.xc-glass{padding:14px;border-radius:18px;background:rgba(28,28,30,.66);border:1px solid rgba(255,255,255,.12);backdrop-filter:blur(18px);box-shadow:0 5px 14px rgba(0,0,0,.18);color:var(--text)}',
    'html[data-theme="light"] .xc-glass{background:rgba(255,255,255,.8);border-color:rgba(0,0,0,.08)}',
    '.xc-tac{padding:12px;background:rgba(2,5,10,.6);border:1px solid color-mix(in srgb,var(--accent) 40%,transparent);color:#e2e8f0;--xc-ice:#bae6fd;--xc-muted:#7fb2f5;--xc-text:#e2e8f0}',
    'html[data-theme="light"] .xc-tac{background:rgba(2,5,10,.82)}',
    '.xc-t{font:500 10px/1.3 var(--mono);letter-spacing:2.4px;text-transform:uppercase;color:var(--accent);margin-bottom:8px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}',
    '.xc-t.two{white-space:normal;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical}',
    '.xc-m{font-family:var(--mono)}',
    '.xc-btn{font:500 10px var(--mono);letter-spacing:1px;color:var(--accent);height:28px;padding:0 10px;border:1px solid color-mix(in srgb,var(--accent) 60%,transparent);display:inline-flex;align-items:center;flex:none;text-decoration:none;background:none}',
    '.xc-btn:hover{background:var(--accent);color:#02050a}',
    '.xc-row{display:flex;align-items:center;gap:10px}',
    '.xc-grow{flex:1;min-width:0}',
    '.xc-clip{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}',
    // weather
    '.xc-wx-top{display:flex;align-items:center;gap:14px}',
    '.xc-temp{font:500 34px/1.1 var(--mono);color:var(--text)}',
    '.xc-cond{font:500 11px var(--mono);letter-spacing:2px;text-transform:uppercase;color:var(--xc-ice)}',
    '.xc-stats{display:flex;gap:18px;margin-top:10px}',
    '.xc-stats small{display:block;font:500 8px var(--mono);letter-spacing:1.6px;color:var(--xc-muted)}',
    '.xc-stats b{font:500 11px var(--mono);color:var(--text)}',
    '.xc-hours{display:flex;align-items:flex-end;gap:10px;margin-top:14px;overflow-x:auto;scrollbar-width:none}',
    '.xc-hours div{display:flex;flex-direction:column;align-items:center;gap:4px;font:500 8px var(--mono);color:var(--text)}',
    '.xc-hours small{font:inherit;color:var(--xc-muted)}',
    '.xc-hours i{display:block;width:14px;border-radius:2px;background:rgba(59,130,246,.85)}',
    '.xc-art{width:84px;height:84px;flex:none;position:relative}',
    '.xc-sun{position:absolute;inset:0;border-radius:50%;background:radial-gradient(circle,#ffd966 0,rgba(255,153,38,.15) 100%);box-shadow:0 0 14px rgba(255,179,51,.7)}',
    '.xc-art svg{position:absolute;inset:0;overflow:visible}',
    '.xc-drift{animation:xcdrift 6s ease-in-out infinite alternate}',
    '.xc-drop{animation:xcfall 1.1s linear infinite}',
    '.xc-flake{animation:xcfall 2.9s linear infinite}',
    '.xc-bolt{filter:drop-shadow(0 0 6px #ffe64d)}',
    '@keyframes xcdrift{from{transform:translateX(-5px)}to{transform:translateX(5px)}}',
    '@keyframes xcfall{from{transform:translateY(0);opacity:1}to{transform:translateY(34px);opacity:.15}}',
    // map + resizable previews
    '.xc-rs-box{position:relative;overflow:hidden;border:1px solid color-mix(in srgb,var(--accent) 35%,transparent);background:#02050a}',
    '.xc-grip{height:12px;background:color-mix(in srgb,var(--accent) 28%,transparent);display:flex;align-items:center;justify-content:center;cursor:ns-resize;touch-action:none}',
    '.xc-grip::after{content:"";width:36px;height:3px;border-radius:2px;background:var(--accent)}',
    '.xc-map img{position:absolute;width:256px;height:256px;max-width:none;user-select:none;pointer-events:none}',
    '.xc-pin{position:absolute;left:50%;top:50%;width:14px;height:14px;margin:-7px;border-radius:50%;background:#38bdf8;border:2px solid #fff;box-shadow:0 0 0 4px rgba(56,189,248,.3)}',
    '.xc-credit{position:absolute;right:4px;bottom:2px;font:9px var(--sans);color:rgba(255,255,255,.55)}',
    '.xc-rs-box iframe{display:block;width:100%;height:100%;border:0;background:#000}',
    '.xc-none{display:flex;align-items:center;justify-content:center;min-height:80px;font:500 11px var(--mono);color:var(--xc-muted);text-align:center;padding:8px}',
    // pictures + lightbox
    '.xc-strip{display:flex;gap:10px;overflow-x:auto;scrollbar-width:none;padding-bottom:2px}',
    '.xc-strip::-webkit-scrollbar,.xc-hours::-webkit-scrollbar{display:none}',
    '.xc-pic{flex:none;width:160px;display:flex;flex-direction:column;gap:4px}',
    '.xc-thumb{position:relative;width:160px;height:100px;overflow:hidden;background:rgba(59,130,246,.25)}',
    '.xc-thumb img{width:100%;height:100%;object-fit:cover;display:block}',
    '.xc-thumb span{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;background:rgba(0,0,0,.35);font:500 10px var(--mono);letter-spacing:2px;color:#bae6fd;opacity:0;transition:opacity .15s}',
    '.xc-thumb:hover span,.xc-thumb:focus-visible span{opacity:1}',
    '.xc-thumb.dead{background:#02050a}.xc-thumb.dead span{opacity:1;background:none;color:#7fb2f5;font-size:8px}',
    '.xc-pic p{margin:0;font:500 8px/1.35 var(--mono);text-transform:uppercase;color:#e2e8f0;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;overflow-wrap:anywhere}',
    '#xcZoom{position:fixed;inset:0;z-index:95;background:rgba(0,0,0,.88);display:flex;align-items:center;justify-content:center}',
    '#xcZoom img{max-width:calc(100% - 96px);max-height:calc(100% - 136px);object-fit:contain;pointer-events:none}',
    '#xcZoom .xc-zh{position:absolute;top:0;left:0;right:0;display:flex;align-items:center;gap:12px;padding:20px}',
    '#xcZoom .xc-zh span{flex:1;min-width:0;font:500 11px var(--mono);letter-spacing:2px;text-transform:uppercase;color:var(--accent);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}',
    '#xcZoom button{height:44px;padding:0 16px;background:var(--accent);color:#02050a;font:600 12px var(--mono);letter-spacing:1px}',
    '#xcZoom .xc-zs{position:absolute;font:500 12px var(--mono);color:#7fb2f5}',
    '@media (max-width:760px){#xcZoom img{max-width:calc(100% - 32px)}}',
    // chart
    '.xc-chart{display:block;width:100%;height:160px}',
    '.xc-chart .bar{transform-box:view-box;transform-origin:0 160px;animation:xcgrow .7s ease-out both}',
    '@keyframes xcgrow{from{transform:scaleY(0)}to{transform:scaleY(1)}}',
    '.xc-labels{display:flex;gap:4px;margin-top:8px}',
    '.xc-labels span{flex:1;min-width:0;text-align:center;font:500 7px var(--mono);text-transform:uppercase;color:var(--xc-muted);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}',
    // website, files, earth, music
    '.xc-site{display:flex;flex-direction:column;justify-content:center;gap:6px;min-height:96px;padding:12px;border:1px solid color-mix(in srgb,var(--accent) 35%,transparent)}',
    '.xc-site b{font:500 14px var(--mono);color:#bae6fd;overflow-wrap:anywhere}',
    '.xc-site small{font:500 9px var(--mono);color:#7fb2f5;overflow-wrap:anywhere}',
    '.xc-files{display:flex;flex-direction:column;gap:8px}',
    '.xc-files b{display:block;font:500 10px var(--mono);text-transform:uppercase;color:#e2e8f0}',
    '.xc-files small{display:block;font:500 8px var(--mono);color:#7fb2f5}',
    '.xc-km{font:500 18px var(--mono);color:var(--xc-ice)}',
    '.xc-mi{font:500 11px var(--mono);color:var(--xc-muted)}',
    '.xc-elev{margin-left:auto;text-align:right;font:500 9px/1.6 var(--mono);color:var(--xc-text);white-space:pre}',
    '.xc-track{font:500 14px var(--mono);text-transform:uppercase;color:var(--xc-ice);display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}',
    '.xc-artist{font:500 10px var(--mono);text-transform:uppercase;color:var(--xc-text);margin-top:6px}',
    '.xc-state{font:500 9px var(--mono);text-transform:uppercase;color:var(--xc-muted);margin-top:6px}',
    '.xc-globe,.xc-vignette{position:absolute;inset:0;width:100%;height:100%;border:0;z-index:2}',
    '.xc-vignette{pointer-events:none;background:radial-gradient(circle at 50% 50%,transparent 45%,rgba(0,0,0,.16) 85%)}',
    'html[data-theme="light"] .xc-vignette{background:radial-gradient(circle at 50% 50%,transparent 45%,rgba(255,255,255,.1) 85%)}',
    '.xc-earth>.corner{display:none}',
    '.xc-corner{position:absolute;top:64px;right:18px;width:min(280px,calc(100% - 36px));z-index:4;display:flex;flex-direction:column;gap:12px;pointer-events:none}',
    '.xc-compact{display:none}',
    '#cornerMusic b{display:block;font-size:13px;font-weight:650;color:var(--text);display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}',
    '#cornerMusic small{display:block;font-size:11px;font-weight:400;color:var(--secondary);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}',
    // code blocks inside Jarvis replies
    '.msg.jarvis>span{min-width:0}.msg.jarvis>span.xc-has-code{flex:1}.msg.jarvis:has(.xc-code){width:min(520px,100%)}',
    '.xc-code{display:block;margin:8px 0;border-radius:10px;border:1px solid rgba(255,255,255,.14);overflow:hidden;white-space:normal}',
    '.xc-code-h{display:flex;align-items:center;gap:8px;padding:7px 10px;background:#1a1f26;border-bottom:1px solid rgba(255,255,255,.1)}',
    '.xc-lights{display:flex;gap:5px;padding-left:4px}.xc-lights i{width:8px;height:8px;border-radius:50%}',
    '.xc-lang{font:800 10px var(--mono);color:var(--accent);padding:2px 6px;border-radius:99px;background:color-mix(in srgb,var(--accent) 12%,transparent);margin-right:auto}',
    '.xc-copy{display:inline-flex;align-items:center;gap:4px;font:700 10px var(--mono);color:#8e8e93;padding:3px 7px;border-radius:6px;background:rgba(255,255,255,.06)}',
    '.xc-copy.done{color:var(--ok)}',
    '.xc-code pre{margin:0;border:0;border-radius:0;max-height:none;background:#0f1217;color:#e6edf5;padding:12px;font:12px/1.6 var(--mono);white-space:pre;overflow-x:auto;overflow-wrap:normal}',
    // generic tool, result, terminal and thought cards (Mac cardBody fallback)
    '.hcard.xc-gen{padding:14px;border-radius:14px;border-color:rgba(255,255,255,.12);box-shadow:0 2px 8px rgba(0,0,0,.1)}',
    '.hcard.xc-gen .ht{font:600 11px/1.3 var(--sans);letter-spacing:0;color:var(--secondary);margin-bottom:6px;overflow-wrap:anywhere}',
    '.hcard.xc-gen.err .ht{color:var(--bad)}',
    '.hcard.xc-gen .hd{font:12px/1.55 var(--sans);font-style:normal;color:var(--text);max-height:none;overflow:hidden;display:-webkit-box;-webkit-line-clamp:6;-webkit-box-orient:vertical}',
    '.hcard.xc-gen.long .hd{font-family:var(--mono);line-height:1.45}',
    '@media (max-width:760px){.xc-corner{display:none}.xc-compact{display:block}.hcard.xc-gen .hd{font-size:11px}}',
    '@media (prefers-reduced-motion:reduce){.xc,.xc-drift,.xc-drop,.xc-flake,.xc-chart .bar{animation:none!important}}'
  ].join('\n');
  document.head.appendChild(css);

  // ---- helpers ----
  function el(tag, cls, text) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text != null) e.textContent = String(text);
    return e;
  }
  function svg(tag, attrs) {
    var e = document.createElementNS(SVG, tag);
    for (var k in attrs) e.setAttribute(k, attrs[k]);
    return e;
  }
  function safeUrl(u) {
    try { var x = new URL(String(u || '')); return x.protocol === 'https:' || x.protocol === 'http:' ? x.href : ''; } catch (e) { return ''; }
  }
  function num(v) { v = typeof v === 'number' ? v : parseFloat(v); return isFinite(v) ? v : null; }
  function str(v, max) { return v == null ? '' : String(v).slice(0, max || 200); }
  function title(text, two) { return el('div', 'xc-t' + (two ? ' two' : ''), text); }
  function card(kind, cls) { return el('div', 'xc ' + kind + (cls ? ' ' + cls : '')); }
  function hudOf(item) {
    var h = item && item.hud;
    if (typeof h === 'string') { try { h = JSON.parse(h); } catch (e) { h = null; } }
    return h && typeof h === 'object' && typeof h.type === 'string' ? h : null;
  }
  function copyText(text) {
    if (navigator.clipboard && window.isSecureContext) return navigator.clipboard.writeText(text);
    var ta = el('textarea'); ta.value = text; ta.style.position = 'fixed'; ta.style.opacity = '0';
    document.body.appendChild(ta); ta.select();
    try { document.execCommand('copy'); } finally { ta.remove(); }
    return Promise.resolve();
  }
  // Drag handle under a preview, like HUDResizablePreview (140 to 560 px).
  function resizable(content, height) {
    var wrap = el('div'), box = el('div', 'xc-rs-box'), grip = el('div', 'xc-grip');
    box.style.height = height + 'px';
    box.appendChild(content);
    grip.tabIndex = 0;
    grip.setAttribute('role', 'separator');
    grip.setAttribute('aria-orientation', 'horizontal');
    grip.setAttribute('aria-label', 'Resize preview');
    function set(h) { height = Math.max(140, Math.min(560, h)); box.style.height = height + 'px'; }
    var startY = 0, startH = 0;
    grip.addEventListener('pointerdown', function (e) {
      startY = e.clientY; startH = height; grip.setPointerCapture(e.pointerId);
      grip.onpointermove = function (m) { set(startH + m.clientY - startY); };
    });
    grip.addEventListener('pointerup', function () { grip.onpointermove = null; });
    grip.addEventListener('keydown', function (e) {
      if (e.key === 'ArrowDown' || e.key === 'ArrowUp') { e.preventDefault(); set(height + (e.key === 'ArrowDown' ? 20 : -20)); }
    });
    wrap.appendChild(box); wrap.appendChild(grip);
    return wrap;
  }

  // ---- weather (HUDWeatherCard + HUDMapCard) ----
  var WMO = { 0: 'Clear sky', 1: 'Mainly clear', 2: 'Partly cloudy', 3: 'Overcast', 45: 'Fog', 48: 'Fog', 51: 'Drizzle', 53: 'Drizzle', 55: 'Drizzle',
    56: 'Freezing drizzle', 57: 'Freezing drizzle', 61: 'Rain', 63: 'Rain', 65: 'Rain', 66: 'Freezing rain', 67: 'Freezing rain',
    71: 'Snow', 73: 'Snow', 75: 'Snow', 77: 'Snow', 80: 'Showers', 81: 'Showers', 82: 'Showers', 85: 'Snow showers', 86: 'Snow showers',
    95: 'Thunderstorm', 96: 'Storm + hail', 99: 'Storm + hail' };
  function weatherArt(code) {
    var art = el('div', 'xc-art');
    var rain = (code >= 51 && code <= 67) || (code >= 80 && code <= 82);
    var snow = (code >= 71 && code <= 77) || code === 85 || code === 86;
    var storm = code >= 95, cloud = code === 2 || code === 3 || code === 45 || code === 48;
    art.setAttribute('aria-hidden', 'true');
    if (!rain && !snow && !storm && !cloud) { art.appendChild(el('div', 'xc-sun')); return art; }
    var s = svg('svg', { width: 84, height: 84, viewBox: '0 0 84 84' });
    var g = svg('g', { 'class': 'xc-drift' });
    [[26.9, 31.9, 12.6], [40.3, 37.9, 10.1], [53.8, 31.9, 8.4]].forEach(function (c) {
      g.appendChild(svg('circle', { cx: c[0], cy: c[1], r: c[2], fill: 'rgba(186,230,253,.9)' }));
    });
    s.appendChild(g);
    if (cloud) s.appendChild(svg('circle', { cx: 64.7, cy: 19.3, r: 12.6, fill: 'rgba(255,204,89,.85)' }));
    if (rain || storm) {
      for (var i = 0; i < 14; i++) {
        var x = i * 6.3;
        var d = svg('line', { x1: x, y1: 46.2, x2: x - 3, y2: 55.2, stroke: storm ? '#38bdf8' : '#3b82f6', 'stroke-width': 1.6, 'class': 'xc-drop' });
        d.style.animationDelay = (-((i * 0.37) % 1) * 1.1).toFixed(2) + 's';
        s.appendChild(d);
      }
    } else if (snow) {
      for (var j = 0; j < 12; j++) {
        var f = svg('circle', { cx: j * 7 + 1.5, cy: 47.7, r: 1.5, fill: '#fff', 'class': 'xc-flake' });
        f.style.animationDelay = (-((j * 0.53) % 1) * 2.9).toFixed(2) + 's';
        s.appendChild(f);
      }
    }
    if (storm) s.appendChild(svg('polyline', { points: '43.7,42 35.3,60.5 42,60.5 33.6,79.8', fill: 'none', stroke: '#ffd94d', 'stroke-width': 2.5, 'class': 'xc-bolt' }));
    art.appendChild(s);
    return art;
  }
  function weather(h) {
    var code = Math.round(num(h.code) || 0), city = str(h.city, 80) || 'UNKNOWN';
    var deg = function (v) { v = num(v); return v === null ? '--' : Math.round(v) + '°C'; };
    var c = card('xc-glass');
    c.appendChild(title(city));
    var top = el('div', 'xc-wx-top'), txt = el('div');
    top.appendChild(weatherArt(code));
    txt.appendChild(el('div', 'xc-temp', deg(h.temp_c)));
    txt.appendChild(el('div', 'xc-cond', WMO[code] || 'Unknown'));
    top.appendChild(txt);
    c.appendChild(top);
    var stats = el('div', 'xc-stats'), hum = num(h.humidity), wind = num(h.wind_kmh);
    [['FEELS', deg(h.feels_like_c)], ['HUM', hum === null ? '--' : Math.trunc(hum) + '%'], ['WIND', wind === null ? '--' : Math.trunc(wind) + ' KM/H']].forEach(function (s) {
      var d = el('div'); d.appendChild(el('small', '', s[0])); d.appendChild(el('b', '', s[1])); stats.appendChild(d);
    });
    c.appendChild(stats);
    var hours = (Array.isArray(h.hourly) ? h.hourly : []).slice(0, 8);
    if (hours.length) {
      var temps = hours.map(function (x) { return num(x && x.temp_c); }).filter(function (v) { return v !== null; });
      var t0 = num(h.temp_c) || 0, lo = temps.length ? Math.min.apply(null, temps) : t0, hi = temps.length ? Math.max.apply(null, temps) : t0 + 1;
      var span = Math.max(hi - lo, 1), row = el('div', 'xc-hours');
      hours.forEach(function (x) {
        var tv = num(x && x.temp_c) || 0, col = el('div'), bar = el('i');
        bar.style.height = (8 + 44 * (tv - lo) / span) + 'px';
        col.appendChild(el('small', '', str(x && x.time, 5) || '--:--'));
        col.appendChild(bar);
        col.appendChild(el('span', '', Math.round(tv) + '°'));
        row.appendChild(col);
      });
      c.appendChild(row);
    }
    var lat = num(h.lat), lon = num(h.lon);
    if (lat === null || lon === null || Math.abs(lat) > 85 || Math.abs(lon) > 180) return c;
    var stack = card('xc-stack');
    c.classList.remove('xc');
    stack.appendChild(c);
    var m = el('div', 'xc-glass');
    m.appendChild(title(city));
    m.appendChild(resizable(tileMap(lat, lon), 200));
    stack.appendChild(m);
    return stack;
  }
  // Dark street map from Esri tiles around a point (stands in for MapKit; tiles are plain <img>).
  function tileMap(lat, lon) {
    var z = 11, n = 1 << z, map = el('div', 'xc-map');
    map.style.cssText = 'position:absolute;inset:0';
    var r = lat * Math.PI / 180;
    var px = (lon + 180) / 360 * n * 256;
    var py = (1 - Math.log(Math.tan(r) + 1 / Math.cos(r)) / Math.PI) / 2 * n * 256;
    var base = 'https://services.arcgisonline.com/ArcGIS/rest/services/Canvas/';
    for (var ty = Math.floor((py - 290) / 256); ty <= Math.floor((py + 290) / 256); ty++) {
      if (ty < 0 || ty >= n) continue;
      for (var tx = Math.floor((px - 280) / 256); tx <= Math.floor((px + 280) / 256); tx++) {
        ['World_Dark_Gray_Base', 'World_Dark_Gray_Reference'].forEach(function (layer) {
          var img = el('img');
          img.alt = ''; img.decoding = 'async'; img.referrerPolicy = 'no-referrer';
          img.src = base + layer + '/MapServer/tile/' + z + '/' + ty + '/' + (((tx % n) + n) % n);
          img.style.left = 'calc(50% + ' + Math.round(tx * 256 - px) + 'px)';
          img.style.top = 'calc(50% + ' + Math.round(ty * 256 - py) + 'px)';
          img.onerror = function () { img.remove(); };
          map.appendChild(img);
        });
      }
    }
    map.appendChild(el('div', 'xc-pin'));
    map.appendChild(el('div', 'xc-credit', 'Esri'));
    return map;
  }

  // ---- pictures (HUDPictureStrip) + zoom overlay ----
  var zoom = null, zoomFrom = null;
  function bigger(u) {
    try {
      var x = new URL(u);
      if (x.hostname === 'upload.wikimedia.org' && /\/thumb\//.test(x.pathname)) x.pathname = x.pathname.replace(/\/\d+px-([^/]+)$/, '/1280px-$1');
      return x.href;
    } catch (e) { return u; }
  }
  function closeZoom() {
    if (!zoom) return;
    zoom.remove(); zoom = null;
    document.removeEventListener('keydown', zoomKeys, true);
    var back = zoomFrom;
    if (back && !back.isConnected) back = document.querySelector('.xc-thumb[data-src="' + CSS.escape(back.dataset.src || '') + '"]');
    zoomFrom = null;
    if (back) back.focus();
  }
  function zoomKeys(e) {
    if (!zoom) return;
    if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); closeZoom(); }
    else if (e.key === 'Tab') { e.preventDefault(); zoom.querySelector('button').focus(); }
  }
  function openZoom(thumb, src, name) {
    closeZoom();
    zoomFrom = thumb;
    zoom = el('div');
    zoom.id = 'xcZoom';
    zoom.setAttribute('role', 'dialog');
    zoom.setAttribute('aria-modal', 'true');
    zoom.setAttribute('aria-label', name || 'Picture');
    var status = el('div', 'xc-zs', 'LOADING…'), img = el('img');
    img.alt = name || ''; img.referrerPolicy = 'no-referrer';
    var big = bigger(src);
    img.onload = function () { status.remove(); };
    img.onerror = function () { if (img.src !== src) img.src = src; else status.textContent = 'NO SIGNAL'; };
    img.src = big;
    var head = el('div', 'xc-zh'), close = el('button', '', 'CLOSE');
    close.type = 'button';
    close.onclick = closeZoom;
    head.appendChild(el('span', '', name));
    head.appendChild(close);
    zoom.onclick = function (e) { if (e.target === zoom) closeZoom(); };
    zoom.appendChild(status); zoom.appendChild(img); zoom.appendChild(head);
    document.body.appendChild(zoom);
    document.addEventListener('keydown', zoomKeys, true);
    close.focus();
  }
  function pictures(h) {
    var seen = {}, items = (Array.isArray(h.items) ? h.items : []).filter(function (it) {
      var u = it && safeUrl(it.thumb);
      if (!u || seen[u]) return false;
      return (seen[u] = true);
    }).slice(0, 10);
    if (!items.length) return null;
    var c = card('xc-tac');
    c.style.padding = '14px';
    c.appendChild(title('IMAGERY // ' + (str(h.query, 80) || 'IMAGERY')));
    var strip = el('div', 'xc-strip');
    items.forEach(function (it) {
      var src = safeUrl(it.thumb), name = str(it.title, 80) || 'UNTITLED';
      var pic = el('div', 'xc-pic'), b = el('button', 'xc-thumb'), img = el('img');
      b.type = 'button';
      b.dataset.src = src;
      b.setAttribute('aria-label', 'Zoom ' + name);
      img.alt = ''; img.loading = 'lazy'; img.decoding = 'async'; img.referrerPolicy = 'no-referrer'; img.src = src;
      img.onerror = function () { img.remove(); b.classList.add('dead'); b.lastChild.textContent = 'NO SIGNAL'; };
      b.appendChild(img);
      b.appendChild(el('span', '', 'ZOOM'));
      b.onclick = function () { openZoom(b, src, name); };
      pic.appendChild(b);
      pic.appendChild(el('p', '', name));
      strip.appendChild(pic);
    });
    c.appendChild(strip);
    return c;
  }

  // ---- youtube, chart, website, files, camera ----
  function youtube(h) {
    var id = /^[A-Za-z0-9_-]{11}$/.test(h.video_id || '') ? h.video_id : '';
    var c = card('xc-glass');
    c.appendChild(title(str(h.title, 120) || str(h.query, 120) || id || 'YOUTUBE'));
    if (!id) { c.appendChild(el('div', 'xc-none', 'NO VIDEO ID')); return c; }
    var f = el('iframe');
    f.src = 'https://www.youtube-nocookie.com/embed/' + id + '?playsinline=1&rel=0';
    f.title = str(h.title, 120) || 'YouTube video';
    f.allow = 'autoplay; encrypted-media; picture-in-picture; fullscreen';
    f.allowFullscreen = true;
    // YouTube refuses to play without a referrer; send only this page's origin.
    f.referrerPolicy = 'strict-origin-when-cross-origin';
    c.appendChild(resizable(f, 240));
    return c;
  }
  function chart(h) {
    var labels = Array.isArray(h.labels) ? h.labels : [], values = Array.isArray(h.values) ? h.values : [];
    var n = Math.min(labels.length, values.length, 16);
    if (n < 2) return null;
    var vals = values.slice(0, n).map(function (v) { return Math.max(0, num(v) || 0); });
    var maxV = Math.max.apply(null, vals), W = 480, Ht = 160, gap = 6;
    var barW = Math.max(4, (W - gap * (n + 1)) / n);
    var c = card('xc-glass');
    c.appendChild(title(str(h.title, 80) || 'CHART', true));
    var s = svg('svg', { 'class': 'xc-chart', viewBox: '0 0 ' + W + ' ' + Ht, preserveAspectRatio: 'none', role: 'img', 'aria-label': str(h.title, 80) || 'Chart' });
    if (maxV > 0) {
      if (h.kind === 'line') {
        var g = svg('g', { 'class': 'bar' }), pts = vals.map(function (v, i) {
          return [gap + i * (barW + gap) + barW / 2, Ht - v / maxV * (Ht - 10) - 2];
        });
        g.appendChild(svg('polyline', { points: pts.map(function (p) { return p.join(','); }).join(' '), fill: 'none', stroke: '#38bdf8', 'stroke-width': 2, 'vector-effect': 'non-scaling-stroke' }));
        pts.forEach(function (p) {
          g.appendChild(svg('path', { d: 'M' + p[0] + ' ' + p[1] + 'h0', stroke: '#bae6fd', 'stroke-width': 6, 'stroke-linecap': 'round', 'vector-effect': 'non-scaling-stroke' }));
        });
        s.appendChild(g);
      } else {
        vals.forEach(function (v, i) {
          var bh = Math.max(2, v / maxV * (Ht - 8));
          s.appendChild(svg('rect', { 'class': 'bar', x: gap + i * (barW + gap), y: Ht - bh, width: barW, height: bh, fill: 'rgba(56,189,248,.85)' }));
        });
      }
    }
    c.appendChild(s);
    var row = el('div', 'xc-labels');
    labels.slice(0, n).forEach(function (l) { var sp = el('span', '', str(l, 24)); sp.title = str(l, 24); row.appendChild(sp); });
    c.appendChild(row);
    return c;
  }
  function website(h) {
    var url = safeUrl(h.url);
    if (!url) return null;
    var host = new URL(url).host, c = card('xc-tac');
    var head = el('div', 'xc-row'), t = title(str(h.title, 120) || host);
    t.classList.add('xc-grow');
    t.style.marginBottom = '0';
    head.appendChild(t);
    var open = el('a', 'xc-btn', 'OPEN');
    open.href = url; open.target = '_blank'; open.rel = 'noopener noreferrer';
    head.appendChild(open);
    c.appendChild(head);
    var box = el('div', 'xc-site');
    box.style.marginTop = '8px';
    box.appendChild(el('b', '', host));
    box.appendChild(el('small', '', url));
    c.appendChild(box);
    return c;
  }
  function files(h) {
    var items = (Array.isArray(h.items) ? h.items : []).filter(function (it) { return it && typeof it.path === 'string' && it.path; }).slice(0, 16);
    if (!items.length) return null;
    var c = card('xc-tac'), list = el('div', 'xc-files');
    c.appendChild(title('FILES // ' + (str(h.query, 80) || 'FILES')));
    items.forEach(function (it) {
      var row = el('div', 'xc-row'), txt = el('div', 'xc-grow');
      var path = str(it.path, 1000), name = str(it.name, 200) || path.split(/[\\/]/).pop();
      txt.appendChild(el('b', 'xc-clip', name));
      var p = el('small', 'xc-clip', path); p.title = path;
      txt.appendChild(p);
      // The browser cannot open Explorer, so the action copies the path instead of the Mac's JUMP.
      var b = el('button', 'xc-btn', 'COPY');
      b.type = 'button';
      b.setAttribute('aria-label', 'Copy path of ' + name);
      b.onclick = function () {
        copyText(path).then(function () { b.textContent = 'COPIED'; setTimeout(function () { b.textContent = 'COPY'; }, 2000); },
          function () { H.setStatus('Could not copy the path.'); });
      };
      row.appendChild(txt); row.appendChild(b);
      list.appendChild(row);
    });
    c.appendChild(list);
    return c;
  }
  function camera() {
    var c = card('xc-tac'), box = el('div', 'xc-none');
    c.appendChild(title('SCREEN FEED'));
    box.style.cssText = 'flex-direction:column;gap:10px;min-height:120px;border:1px solid color-mix(in srgb,var(--accent) 35%,transparent)';
    box.appendChild(el('span', '', 'LIVE SCREEN IS ON THE SCREEN TAB'));
    var b = el('button', 'xc-btn', 'OPEN SCREEN');
    b.type = 'button';
    b.onclick = function () { H.go('screen'); };
    box.appendChild(b);
    c.appendChild(box);
    return c;
  }

  // ---- earth (HUDEarthCard), music (HUDMusicCard) ----
  function place(p) {
    var lat = num(p && p.lat), lon = num(p && p.lon);
    if (lat === null || lon === null || Math.abs(lat) > 90 || Math.abs(lon) > 180) return null;
    return { name: str(p.name, 80), lat: lat, lon: lon, elev: num(p.elev_m) };
  }
  function earthOf(h) {
    if (!h || h.type !== 'earth') return null;
    var o = place(h.origin), d = place(h.dest);
    if (!o || !d) return null;
    var km = num(h.distance_km) || 0;
    return { o: o, d: d, km: km, mi: num(h.distance_mi) === null ? km * 0.621371 : num(h.distance_mi) };
  }
  function earthCard(e) {
    var c = card('xc-tac'), row = el('div', 'xc-row'), dist = el('div');
    c.appendChild(title('EARTH // ' + e.o.name + ' → ' + e.d.name, true));
    row.style.alignItems = 'flex-start';
    dist.appendChild(el('div', 'xc-km', Math.round(e.km) + ' KM'));
    dist.appendChild(el('div', 'xc-mi', Math.round(e.mi) + ' MI'));
    row.appendChild(dist);
    var elev = function (tag, m) { return tag + '  ' + (m === null ? '—' : Math.round(m) + ' M'); };
    row.appendChild(el('div', 'xc-elev', elev('HERE', e.o.elev) + '\n' + elev('DEST', e.d.elev)));
    c.appendChild(row);
    return c;
  }
  function musicCard(h) {
    var c = card('xc-glass');
    c.appendChild(title('MUSIC // ' + (str(h.app, 40) || 'Spotify')));
    if (h.track) c.appendChild(el('div', 'xc-track', str(h.track, 200)));
    if (h.artist) c.appendChild(el('div', 'xc-artist xc-clip', str(h.artist, 120)));
    if (h.state) c.appendChild(el('div', 'xc-state', str(h.state, 40)));
    return c;
  }

  var BUILD = { weather: weather, pictures: pictures, youtube: youtube, chart: chart, website: website, files: files, camera: camera,
    earth: function (h) {
      // The Mac shows the route on the globe and in the corner; a narrow window gets the card in the deck.
      var e = earthOf(h), c = e ? earthCard(e) : el('div');
      c.classList.add('xc-compact');
      if (!e) c.hidden = true;
      return c;
    } };
  var built = new WeakMap();
  H.cardRenderer(function (item) {
    var h = hudOf(item);
    if (!h || !BUILD[h.type]) return null;
    if (!built.has(item)) built.set(item, BUILD[h.type](h) || null);
    return built.get(item);
  });
  // Mac fallback card for tool calls, results, terminal output and thoughts. Registered last so
  // other modules' renderers win.
  window.addEventListener('load', function () {
    H.cardRenderer(function (item) {
      var long = (item.k === 'term' || item.k === 'thought') && !hudOf(item) && (item.text || '').length > 400;
      var c = el('div', 'hcard xc-gen' + (long ? ' long' : '') + (item.ok === false ? ' err' : ''));
      if (!long) c.appendChild(el('div', 'ht', item.title || ''));
      c.appendChild(el('div', 'hd', item.text || ''));
      return c;
    });
  });

  // ---- deck surroundings: globe, corner cards, now playing, code blocks ----
  var view = document.querySelector('[data-view="assistant"]'), log = H.$('log');
  var globe = null, vignette = null, corner = null, globeKey = '', cornerKey = '', musicKey = null;
  function latest(items, type) {
    var start = 0;
    for (var i = items.length - 1; i >= 0; i--) if (items[i].k === 'user') { start = i; break; }
    for (var j = items.length - 1; j >= start; j--) { var h = hudOf(items[j]); if (h && h.type === type) return h; }
    return null;
  }
  function syncSurroundings() {
    var items = H.thread().items, earth = earthOf(latest(items, 'earth')), music = latest(items, 'music');
    var light = document.documentElement.getAttribute('data-theme') === 'light';
    var key = earth ? JSON.stringify([earth.o.lat, earth.o.lon, earth.o.name, earth.d.lat, earth.d.lon, earth.d.name, light]) : '';
    if (key !== globeKey) {
      globeKey = key;
      if (!earth) {
        if (globe) { globe.remove(); vignette.remove(); globe = vignette = null; }
      } else {
        if (!globe) {
          globe = el('iframe', 'xc-globe');
          globe.setAttribute('sandbox', 'allow-scripts');
          globe.title = 'Route globe';
          vignette = el('div', 'xc-vignette');
          view.insertBefore(vignette, log);
          view.insertBefore(globe, vignette);
        }
        var q = new URLSearchParams({ olat: earth.o.lat, olon: earth.o.lon, on: earth.o.name.slice(0, 22),
          dlat: earth.d.lat, dlon: earth.d.lon, dn: earth.d.name.slice(0, 22) });
        if (light) q.set('light', '1');
        var mapMode = localStorage.getItem('jarvis.map_mode');
        if (mapMode) q.set('mode', mapMode);
        globe.src = '/hud/globe?' + q.toString();
      }
      view.classList.toggle('xc-earth', !!earth);
    }
    var ck = earth ? JSON.stringify([key, music]) : '';
    if (ck !== cornerKey) {
      cornerKey = ck;
      if (corner) { corner.remove(); corner = null; }
      if (earth) {
        corner = el('div', 'xc-corner');
        corner.appendChild(earthCard(earth));
        if (music) corner.appendChild(musicCard(music));
        view.insertBefore(corner, log);
      }
    }
    // Corner widget "now playing" line, as in HUDCornerPanel. The Mac has no player controls here.
    var mk = music && music.track ? JSON.stringify([music.track, music.app, music.artist]) : '';
    if (mk !== musicKey) {
      musicKey = mk;
      var p = H.$('cornerMusic');
      if (!mk) p.textContent = 'Nothing playing';
      else {
        var by = (str(music.app, 40) || 'Spotify') + (music.artist ? ' · ' + str(music.artist, 120) : '');
        p.replaceChildren(el('b', '', str(music.track, 200)), el('small', '', by));
      }
    }
    log.querySelectorAll('.msg.jarvis>span').forEach(codeBlocks);
  }
  function codeBlocks(span) {
    var text = span.textContent;
    if (span.dataset.xc || text.indexOf('```') < 0) return;
    span.dataset.xc = '1';
    span.classList.add('xc-has-code');
    var parts = text.split('```'), out = [];
    parts.forEach(function (part, i) {
      if (i % 2 === 0) { var t = part.replace(/^\s+|\s+$/g, ''); if (t) out.push(el('span', '', t)); return; }
      var nl = part.indexOf('\n'), lang = (nl < 0 ? '' : part.slice(0, nl)).trim().toLowerCase() || 'code';
      out.push(codeBlock(nl < 0 ? part : part.slice(nl + 1), lang));
    });
    span.replaceChildren.apply(span, out);
  }
  function codeBlock(code, lang) {
    code = code.replace(/\s+$/, '');
    var box = el('span', 'xc-code'), head = el('span', 'xc-code-h'), lights = el('span', 'xc-lights');
    ['#ff5c57', '#ffbd2e', '#28c962'].forEach(function (c) { var i = el('i'); i.style.background = c; lights.appendChild(i); });
    head.appendChild(lights);
    head.appendChild(el('span', 'xc-lang', lang.slice(0, 20).toUpperCase()));
    var copy = el('button', 'xc-copy', 'Copy');
    copy.type = 'button';
    copy.title = 'Copy code to clipboard';
    copy.onclick = function () {
      copyText(code).then(function () {
        copy.textContent = 'Copied'; copy.classList.add('done');
        setTimeout(function () { copy.textContent = 'Copy'; copy.classList.remove('done'); }, 2000);
      }, function () { H.setStatus('Could not copy the code.'); });
    };
    head.appendChild(copy);
    var pre = el('pre'), c = el('code', '', code);
    pre.appendChild(c);
    box.appendChild(head); box.appendChild(pre);
    return box;
  }
  // render() can return before emitting (empty chat), so watch the deck itself as well.
  new MutationObserver(syncSurroundings).observe(log, { childList: true });
  new MutationObserver(syncSurroundings).observe(document.documentElement, { attributes: true, attributeFilter: ['data-theme'] });
  window.addEventListener('message', function (ev) {
    if (ev && ev.data && ev.data.type === 'jarvis:map_mode' && typeof ev.data.mode === 'string') {
      try { localStorage.setItem('jarvis.map_mode', ev.data.mode); } catch (e) {}
    }
  });
  H.on('render', syncSurroundings);
  syncSurroundings();
})();
