# Jarvis launcher for Windows 10/11. Windows PowerShell 5.1 compatible; keep this file ASCII only.
# Usage: jarvis {launch|stop|status|update [--force]|uninstall|install-package <folder>}
param([string]$Command = 'launch', [string]$Arg = '')

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
[Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12

$Site = 'https://huy100408.github.io/jarvis-install'
$Dest = Join-Path $env:LOCALAPPDATA 'Jarvis'
$LogDir = Join-Path $env:LOCALAPPDATA 'Jarvis-logs'
$TokenFile = Join-Path $env:USERPROFILE '.jarvis\server_token'
$Port = 20129

function Find-Python312 {
    $found = @()
    $launcher = Get-Command py.exe -ErrorAction SilentlyContinue
    if ($launcher) {
        try {
            $path = & $launcher.Source -3.12 -c "import sys; print(sys.executable)"
            if ($LASTEXITCODE -eq 0 -and $path) { $found += "$path".Trim() }
        } catch { }
    }
    $found += (Join-Path $env:LOCALAPPDATA 'Programs\Python\Python312\python.exe')
    $found += (Join-Path $env:ProgramFiles 'Python312\python.exe')
    foreach ($candidate in $found) {
        if ($candidate -and (Test-Path -LiteralPath $candidate)) { return $candidate }
    }
    return $null
}

function Test-Python312([string]$Python) {
    if (-not (Test-Path -LiteralPath $Python)) { return $false }
    try {
        & $Python -c "import sys; sys.exit(0 if sys.version_info[:2] == (3, 12) else 1)"
        return ($LASTEXITCODE -eq 0)
    } catch { return $false }
}

function Get-ServerProcesses {
    Get-CimInstance Win32_Process -Filter "Name = 'python.exe'" |
        Where-Object { $_.CommandLine -and $_.CommandLine -like '*jarvis_server*' }
}

function Stop-Jarvis {
    foreach ($proc in @(Get-ServerProcesses)) {
        Stop-Process -Id $proc.ProcessId -Force -ErrorAction SilentlyContinue
    }
}

function Test-Server {
    $client = New-Object Net.Sockets.TcpClient
    try { $client.Connect('127.0.0.1', $Port); return $true } catch { return $false } finally { $client.Close() }
}

function Initialize-Token {
    # A fresh random token per computer, written before the server first starts.
    $current = ''
    if (Test-Path -LiteralPath $TokenFile) { $current = ([IO.File]::ReadAllText($TokenFile)).Trim() }
    if ($current.Length -ge 32) { return }
    $bytes = New-Object byte[] 32
    $rng = [Security.Cryptography.RandomNumberGenerator]::Create()
    $rng.GetBytes($bytes)
    $rng.Dispose()
    $token = -join ($bytes | ForEach-Object { $_.ToString('x2') })
    New-Item -ItemType Directory -Force -Path (Split-Path $TokenFile) | Out-Null
    [IO.File]::WriteAllText($TokenFile, $token)
}

function Show-Problem([string]$Message) {
    Write-Host $Message -ForegroundColor Red
    try {
        Add-Type -AssemblyName System.Windows.Forms
        [void][System.Windows.Forms.MessageBox]::Show($Message, 'Jarvis')
    } catch { }
}

function Start-Server {
    $python = Join-Path $Dest '.venv312\Scripts\python.exe'
    if (-not (Test-Path -LiteralPath $python)) { throw "Jarvis is not installed correctly. Run the installer again." }
    Initialize-Token
    New-Item -ItemType Directory -Force -Path $LogDir | Out-Null
    $env:PYTHONUTF8 = '1'
    $env:PYTHONPATH = (Join-Path $Dest 'jarvis-core\src') + ';' + (Join-Path $Dest 'jarvis-server\src')
    Start-Process -FilePath $python -WorkingDirectory $Dest -WindowStyle Hidden `
        -ArgumentList '-m', 'jarvis_server', 'serve', '--host', '0.0.0.0', '--port', "$Port" `
        -RedirectStandardOutput (Join-Path $LogDir 'server.log') `
        -RedirectStandardError (Join-Path $LogDir 'server.err.log')
}

function Open-Hud {
    $token = ([IO.File]::ReadAllText($TokenFile)).Trim()
    # The token rides in the URL fragment, which the browser never sends to any server.
    $url = "http://127.0.0.1:$Port/hud#token=$token"
    $browsers = @(
        (Join-Path ${env:ProgramFiles(x86)} 'Microsoft\Edge\Application\msedge.exe'),
        (Join-Path $env:ProgramFiles 'Microsoft\Edge\Application\msedge.exe'),
        (Join-Path $env:ProgramFiles 'Google\Chrome\Application\chrome.exe'),
        (Join-Path ${env:ProgramFiles(x86)} 'Google\Chrome\Application\chrome.exe'),
        (Join-Path $env:LOCALAPPDATA 'Google\Chrome\Application\chrome.exe')
    )
    foreach ($browser in $browsers) {
        if ($browser -and (Test-Path -LiteralPath $browser)) {
            Start-Process -FilePath $browser -ArgumentList "--app=$url", '--window-size=1040,800'
            return
        }
    }
    Start-Process $url
}

function Start-Jarvis {
    if (-not (Test-Server)) {
        Start-Server
        $ready = $false
        for ($i = 0; $i -lt 90; $i++) {
            Start-Sleep -Seconds 1
            if (Test-Server) { $ready = $true; break }
        }
        if (-not $ready) {
            Show-Problem "Jarvis did not start. Details are in $LogDir\server.err.log"
            exit 1
        }
    }
    Open-Hud
}

function New-Shortcut([string]$Folder) {
    if (-not $Folder -or -not (Test-Path -LiteralPath $Folder)) { return }
    $shell = New-Object -ComObject WScript.Shell
    $link = $shell.CreateShortcut((Join-Path $Folder 'Jarvis.lnk'))
    $link.TargetPath = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
    $link.Arguments = '-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + (Join-Path $Dest 'scripts\jarvis.ps1') + '" launch'
    $link.WorkingDirectory = $Dest
    $link.IconLocation = Join-Path $Dest 'Jarvis.ico'
    $link.WindowStyle = 7
    $link.Description = 'Jarvis'
    $link.Save()
}

function Install-Package([string]$Source) {
    if (-not $Source -or -not (Test-Path -LiteralPath (Join-Path $Source 'VERSION'))) {
        throw "Not a Jarvis release folder: $Source"
    }
    if (Test-Path -LiteralPath (Join-Path $Dest '.jarvis-dev')) {
        throw "This is a development copy ($Dest\.jarvis-dev). Not replacing it."
    }
    $python312 = Find-Python312
    if (-not $python312 -or -not (Test-Python312 $python312)) {
        throw "Jarvis needs Python 3.12. Nothing was changed. Run the installer again."
    }

    # Stop the running copy, then swap folders. The previous install stays in Jarvis.previous.
    Stop-Jarvis
    Start-Sleep -Seconds 1
    $previous = "$Dest.previous"
    if (Test-Path -LiteralPath $previous) { Remove-Item -LiteralPath $previous -Recurse -Force }
    if (Test-Path -LiteralPath $Dest) { Move-Item -LiteralPath $Dest -Destination $previous }
    Copy-Item -LiteralPath $Source -Destination $Dest -Recurse -Force

    $venv = Join-Path $Dest '.venv312'
    $venvPython = Join-Path $venv 'Scripts\python.exe'
    $oldVenv = Join-Path $previous '.venv312'
    if (Test-Python312 (Join-Path $oldVenv 'Scripts\python.exe')) {
        Move-Item -LiteralPath $oldVenv -Destination $venv
    } else {
        Write-Host 'Creating the Python environment...'
        & $python312 -m venv $venv
        if ($LASTEXITCODE -ne 0) { throw 'Could not create the Python environment.' }
    }
    Write-Host 'Installing Python packages (a few minutes the first time)...'
    & $venvPython -m pip install --quiet --disable-pip-version-check --upgrade pip
    & $venvPython -m pip install --quiet --disable-pip-version-check -r (Join-Path $Dest 'requirements.txt')
    if ($LASTEXITCODE -ne 0) { throw 'Installing Python packages failed. Check the internet connection and run the installer again.' }

    Initialize-Token

    # "jarvis" command: this folder is on every user's PATH on Windows 10 and 11.
    $apps = Join-Path $env:LOCALAPPDATA 'Microsoft\WindowsApps'
    if (Test-Path -LiteralPath $apps) {
        Copy-Item -LiteralPath (Join-Path $Dest 'scripts\jarvis.cmd') -Destination (Join-Path $apps 'jarvis.cmd') -Force
    }
    New-Shortcut ([Environment]::GetFolderPath('Programs'))
    New-Shortcut ([Environment]::GetFolderPath('Desktop'))

    $version = ([IO.File]::ReadAllText((Join-Path $Dest 'VERSION'))).Trim()
    Write-Host "Jarvis $version is installed. Opening it now..." -ForegroundColor Green
    Write-Host 'Next time, open Jarvis from the Start Menu or the desktop shortcut.'
    Start-Jarvis
}

function Update-Jarvis([bool]$Force) {
    if (Test-Path -LiteralPath (Join-Path $Dest '.jarvis-dev')) {
        throw "This is a development copy ($Dest\.jarvis-dev). Not replacing it."
    }
    $latest = Invoke-RestMethod -Uri "$Site/latest-windows.json?t=$([DateTime]::UtcNow.Ticks)"
    $local = 'none'
    $versionFile = Join-Path $Dest 'VERSION'
    if (Test-Path -LiteralPath $versionFile) { $local = ([IO.File]::ReadAllText($versionFile)).Trim() }
    if ($local -eq $latest.version -and -not $Force) {
        Write-Host "Jarvis is already up to date ($local)."
        return
    }
    Write-Host "Updating Jarvis $local -> $($latest.version)..."
    $temp = Join-Path ([IO.Path]::GetTempPath()) ('jarvis-' + [Guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Force -Path $temp | Out-Null
    try {
        $zip = Join-Path $temp 'jarvis.zip'
        Invoke-WebRequest -UseBasicParsing -Uri "$Site/$($latest.file)" -OutFile $zip
        $hash = (Get-FileHash -LiteralPath $zip -Algorithm SHA256).Hash.ToLower()
        if ($hash -ne "$($latest.sha256)".ToLower()) { throw 'Download check failed (hash mismatch). Keeping the current version.' }
        Expand-Archive -LiteralPath $zip -DestinationPath (Join-Path $temp 'pkg') -Force
        # The new release installs itself, so new install steps always run.
        $package = Join-Path $temp 'pkg\Jarvis'
        & (Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe') -NoProfile -ExecutionPolicy Bypass `
            -File (Join-Path $package 'scripts\jarvis.ps1') install-package $package
        if ($LASTEXITCODE -ne 0) { throw 'The update did not finish.' }
    } finally {
        Remove-Item -LiteralPath $temp -Recurse -Force -ErrorAction SilentlyContinue
    }
}

function Uninstall-Jarvis {
    Stop-Jarvis
    Start-Sleep -Seconds 1
    foreach ($folder in @([Environment]::GetFolderPath('Programs'), [Environment]::GetFolderPath('Desktop'))) {
        $link = Join-Path $folder 'Jarvis.lnk'
        if (Test-Path -LiteralPath $link) { Remove-Item -LiteralPath $link -Force }
    }
    $shim = Join-Path $env:LOCALAPPDATA 'Microsoft\WindowsApps\jarvis.cmd'
    if (Test-Path -LiteralPath $shim) { Remove-Item -LiteralPath $shim -Force }
    foreach ($folder in @($Dest, "$Dest.previous", $LogDir)) {
        if (Test-Path -LiteralPath $folder) { Remove-Item -LiteralPath $folder -Recurse -Force }
    }
    Write-Host 'Jarvis was removed. Your settings and sign-in stay in your user folder (.jarvis and Library).'
}

try {
    switch ($Command) {
        'launch' { Start-Jarvis }
        'stop' { Stop-Jarvis; Write-Host 'Jarvis stopped.' }
        'status' {
            $versionFile = Join-Path $Dest 'VERSION'
            if (Test-Path -LiteralPath $versionFile) { Write-Host ('Version: ' + ([IO.File]::ReadAllText($versionFile)).Trim()) }
            if (Test-Server) { Write-Host 'Jarvis is running.' } else { Write-Host 'Jarvis is not running.' }
        }
        'update' { Update-Jarvis ($Arg -eq '--force') }
        'install-package' { Install-Package $Arg }
        'uninstall' { Uninstall-Jarvis }
        default { Write-Host 'Usage: jarvis {launch|stop|status|update [--force]|uninstall}'; exit 1 }
    }
} catch {
    Write-Host $_.Exception.Message -ForegroundColor Red
    exit 1
}
