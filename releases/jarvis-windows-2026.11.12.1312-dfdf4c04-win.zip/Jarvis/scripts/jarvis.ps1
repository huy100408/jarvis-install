# Jarvis launcher for Windows 10/11. Windows PowerShell 5.1 compatible; keep this file ASCII only.
# Usage: jarvis {launch|stop|status|link|update [--force]|bridge <args>|uninstall [-Yes] [-KeepData]|install-package <folder>}
param([string]$Command = 'launch', [string]$Arg = '')
$Rest = @($args)

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
[Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12

$Site = 'https://huy100408.github.io/jarvis-install'
$Dest = Join-Path $env:LOCALAPPDATA 'Jarvis'
$LogDir = Join-Path $env:LOCALAPPDATA 'Jarvis-logs'
$TokenFile = Join-Path $env:USERPROFILE '.jarvis\server_token'
$Port = 20129

function Find-Python312 {
    $found = @()
    $launcher = Get-Command py.exe -ErrorAction SilentlyContinue
    if ($launcher) {
        try {
            $path = & $launcher.Source -3.12 -c "import sys; print(sys.executable)"
            if ($LASTEXITCODE -eq 0 -and $path) { $found += "$path".Trim() }
        } catch { }
    }
    $found += (Join-Path $env:LOCALAPPDATA 'Programs\Python\Python312\python.exe')
    $found += (Join-Path $env:ProgramFiles 'Python312\python.exe')
    foreach ($candidate in $found) {
        if ($candidate -and (Test-Path -LiteralPath $candidate)) { return $candidate }
    }
    return $null
}

function Test-Python312([string]$Python) {
    if (-not (Test-Path -LiteralPath $Python)) { return $false }
    try {
        & $Python -c "import sys; sys.exit(0 if sys.version_info[:2] == (3, 12) else 1)"
        return ($LASTEXITCODE -eq 0)
    } catch { return $false }
}

function Get-ServerProcesses {
    Get-CimInstance Win32_Process -Filter "Name = 'python.exe'" |
        Where-Object { $_.CommandLine -and $_.CommandLine -like '*jarvis_server*' }
}

function Get-BridgeProcesses {
    Get-CimInstance Win32_Process -Filter "Name = 'node.exe'" |
        Where-Object { $_.CommandLine -and $_.CommandLine -like '*jarvis-bridge*' -and $_.CommandLine -like '*cli.js*' }
}

function Stop-Jarvis {
    foreach ($proc in @(@(Get-ServerProcesses) + @(Get-BridgeProcesses))) {
        Stop-Process -Id $proc.ProcessId -Force -ErrorAction SilentlyContinue
    }
}

function Test-Port([int]$Number) {
    $client = New-Object Net.Sockets.TcpClient
    try { $client.Connect('127.0.0.1', $Number); return $true } catch { return $false } finally { $client.Close() }
}

function Test-Server { return (Test-Port $Port) }

function Find-Node {
    $bundled = Join-Path $Dest 'runtime\node.exe'
    if (Test-Path -LiteralPath $bundled) { return $bundled }
    $cmd = Get-Command node.exe -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }
    return $null
}

function Get-BridgePort {
    $cfg = Join-Path $env:USERPROFILE 'Library\Application Support\JARVIS\bridge\config.json'
    if (Test-Path -LiteralPath $cfg) {
        $text = [IO.File]::ReadAllText($cfg)
        if ($text -match '"port"\s*:\s*(\d+)') { return [int]$Matches[1] }
    }
    return 20128
}

function Start-Bridge {
    $vault = Join-Path $env:USERPROFILE 'Library\Application Support\JARVIS\bridge\vault.enc'
    if (-not (Test-Path -LiteralPath $vault)) { return }
    $bridgePort = Get-BridgePort
    if (Test-Port $bridgePort) { return }
    $node = Find-Node
    $bridge = Join-Path $Dest 'jarvis-bridge'
    $cli = Join-Path $bridge 'dist\src\cli.js'
    if (-not $node -or -not (Test-Path -LiteralPath $cli)) {
        Write-Host 'Antigravity bridge is set up, but it could not be started.'
        return
    }
    New-Item -ItemType Directory -Force -Path $LogDir | Out-Null
    Start-Process -FilePath $node -WorkingDirectory $bridge -WindowStyle Hidden `
        -ArgumentList $cli, 'serve' `
        -RedirectStandardOutput (Join-Path $LogDir 'bridge.log') `
        -RedirectStandardError (Join-Path $LogDir 'bridge.err.log')
}

function Connect-BridgeProvider {
    # Point Jarvis at the local bridge after a sign-in. The key is piped, never printed.
    $node = Find-Node
    $cli = Join-Path $Dest 'jarvis-bridge\dist\src\cli.js'
    $python = Join-Path $Dest '.venv312\Scripts\python.exe'
    $bridgePort = Get-BridgePort
    if (-not $node -or -not (Test-Path -LiteralPath $cli) -or -not (Test-Path -LiteralPath $python)) {
        Write-Host "Signed in. In Settings, set the base URL to http://127.0.0.1:${bridgePort}/v1"
        return
    }
    $key = (& $node $cli 'api-key' | Out-String).Trim()
    if ($LASTEXITCODE -ne 0 -or $key.Length -lt 32) {
        Write-Host 'Signed in, but Jarvis settings were not changed.'
        return
    }
    $py = @'
import json, sys, uuid
from pathlib import Path
key = sys.stdin.read().strip()
if len(key) < 32 or "\n" in key:
    sys.exit(1)
port = sys.argv[1]
path = Path.home() / "Library/Application Support/JARVIS/server/provider-settings.json"
path.parent.mkdir(parents=True, exist_ok=True)
account = "provider-" + uuid.uuid4().hex
data = {
    "base_url": "http://127.0.0.1:%s/v1" % port,
    "protocol": "openai",
    "model": "gemini-3-flash",
    "computer_use_enabled": False,
    "turbo_mode": False,
    "auto_approve": False,
    "safe_mode": False,
    "tts_engine": "kokoro",
    "kokoro_voice": "af_heart",
    "honorific": "Sir",
    "revision": 1,
    "secret_account": account,
}
if path.exists():
    try:
        existing = json.loads(path.read_text(encoding="utf-8"))
        for name, value in existing.items():
            if name not in ("base_url", "protocol", "secret_account"):
                data[name] = value
        data["revision"] = int(existing.get("revision", 0)) + 1
    except Exception:
        pass
if data.get("model") in ("gemini-3.8-flash-high", "gemini-3.8-flash-low", "gemini-2.5-flash-lite"):
    data["model"] = "gemini-3-flash"
from keyring.backends.Windows import WinVaultKeyring
store = WinVaultKeyring()
store.set_password("com.jarvis.provider-settings", account, key)
store.set_password("com.jarvis.provider-settings", "provider_key", key)
path.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
'@
    $key | & $python -c $py "$bridgePort"
    if ($LASTEXITCODE -ne 0) {
        Write-Host "Signed in, but Jarvis settings were not updated. In Settings, set the base URL to http://127.0.0.1:${bridgePort}/v1"
        return
    }
    $running = Test-Server
    if ($running) {
        foreach ($proc in @(Get-ServerProcesses)) {
            Stop-Process -Id $proc.ProcessId -Force -ErrorAction SilentlyContinue
        }
        Start-Sleep -Seconds 1
        Start-Server
    }
    Start-Bridge
    Write-Host "Jarvis will use the Antigravity bridge at http://127.0.0.1:${bridgePort}/v1"
}

function Set-LinkState([string]$State) {
    # Read by the HUD's Link Antigravity button through /api/settings/bridge.
    New-Item -ItemType Directory -Force -Path $LogDir | Out-Null
    [IO.File]::WriteAllText((Join-Path $LogDir 'link.state'), $State)
}

function Reset-BridgeState([string]$State, [string]$Node, [string]$Cli, [string]$Client) {
    # Kept, not deleted: renamed to bridge.old-<time> next to it.
    if (Test-Path -LiteralPath $State) {
        Rename-Item -LiteralPath $State -NewName ('bridge.old-' + (Get-Date -Format 'yyyyMMddHHmmss'))
    }
    & $Node $Cli 'init' '--oauth-client' $Client | Out-Null
}

function Link-Antigravity([bool]$Force) {
    # Reuse the Antigravity sign-in already on this PC, like jarvis link on the Mac. Nothing is typed or printed.
    $stamp = Join-Path $env:USERPROFILE '.jarvis-credentials\link.ok'
    $state = Join-Path $env:USERPROFILE 'Library\Application Support\JARVIS\bridge'
    $vault = Join-Path $state 'vault.enc'
    $config = Join-Path $state 'config.json'
    $complete = (Test-Path -LiteralPath $vault) -and (Test-Path -LiteralPath $config)
    if (-not $Force -and (Test-Path -LiteralPath $stamp) -and $complete) { return }
    $python = Join-Path $Dest '.venv312\Scripts\python.exe'
    $export = Join-Path $Dest 'scripts\export_antigravity.py'
    $node = Find-Node
    $cli = Join-Path $Dest 'jarvis-bridge\dist\src\cli.js'
    if (-not (Test-Path -LiteralPath $python) -or -not (Test-Path -LiteralPath $export) -or -not $node -or -not (Test-Path -LiteralPath $cli)) {
        Write-Host 'Antigravity linking is not in this install. Run jarvis update.'
        return
    }
    $creds = Join-Path $env:USERPROFILE '.jarvis-credentials'
    $client = Join-Path $creds 'oauth-client.json'
    $account = Join-Path $creds 'account.json'
    Write-Host 'Linking Antigravity...'
    $env:PYTHONUTF8 = '1'
    & $python -I $export
    if ($LASTEXITCODE -ne 0) {
        Write-Host 'Antigravity is not linked yet. Install Antigravity, sign in to it, then run: jarvis link'
        Set-LinkState 'failed'
        return
    }
    try {
        foreach ($proc in @(Get-BridgeProcesses)) {
            Stop-Process -Id $proc.ProcessId -Force -ErrorAction SilentlyContinue
        }
        Start-Sleep -Seconds 1
        # A half-made or unreadable bridge state (vault without config, or a lost vault key) is moved aside and rebuilt.
        $fresh = $false
        if (-not $complete) { Reset-BridgeState $state $node $cli $client; $fresh = $true }
        & $node $cli 'oauth-client' '--file' $client '--force' | Out-Null
        if ($LASTEXITCODE -ne 0 -and -not $fresh) {
            Reset-BridgeState $state $node $cli $client
            & $node $cli 'oauth-client' '--file' $client '--force' | Out-Null
        }
        if ($LASTEXITCODE -ne 0) { Write-Host 'Antigravity link failed while saving the Google client.'; Set-LinkState 'failed'; return }
        & $node $cli 'import-account' '--file' $account | Out-Null
        if ($LASTEXITCODE -ne 0) { Write-Host 'Antigravity link failed while importing the account.'; Set-LinkState 'failed'; return }
    } finally {
        # The bridge vault now holds them; do not leave copies on disk.
        Remove-Item -LiteralPath $client, $account -Force -ErrorAction SilentlyContinue
    }
    Connect-BridgeProvider
    New-Item -ItemType Directory -Force -Path $creds | Out-Null
    [IO.File]::WriteAllText($stamp, 'ok')
    Set-LinkState 'ok'
    Write-Host 'Antigravity linked.'
}

function Initialize-Token {
    # A fresh random token per computer, written before the server first starts.
    $current = ''
    if (Test-Path -LiteralPath $TokenFile) { $current = ([IO.File]::ReadAllText($TokenFile)).Trim() }
    if ($current.Length -ge 32) { return }
    $bytes = New-Object byte[] 32
    $rng = [Security.Cryptography.RandomNumberGenerator]::Create()
    $rng.GetBytes($bytes)
    $rng.Dispose()
    $token = -join ($bytes | ForEach-Object { $_.ToString('x2') })
    New-Item -ItemType Directory -Force -Path (Split-Path $TokenFile) | Out-Null
    [IO.File]::WriteAllText($TokenFile, $token)
}

function Show-Problem([string]$Message) {
    Write-Host $Message -ForegroundColor Red
    try {
        Add-Type -AssemblyName System.Windows.Forms
        [void][System.Windows.Forms.MessageBox]::Show($Message, 'Jarvis')
    } catch { }
}

function Start-Server {
    $python = Join-Path $Dest '.venv312\Scripts\python.exe'
    if (-not (Test-Path -LiteralPath $python)) { throw "Jarvis is not installed correctly. Run the installer again." }
    Initialize-Token
    New-Item -ItemType Directory -Force -Path $LogDir | Out-Null
    $env:PYTHONUTF8 = '1'
    $env:PYTHONPATH = (Join-Path $Dest 'jarvis-core\src') + ';' + (Join-Path $Dest 'jarvis-server\src')
    Start-Process -FilePath $python -WorkingDirectory $Dest -WindowStyle Hidden `
        -ArgumentList '-m', 'jarvis_server', 'serve', '--host', '0.0.0.0', '--port', "$Port" `
        -RedirectStandardOutput (Join-Path $LogDir 'server.log') `
        -RedirectStandardError (Join-Path $LogDir 'server.err.log')
}

function Open-Hud {
    $token = ([IO.File]::ReadAllText($TokenFile)).Trim()
    # The token rides in the URL fragment, which the browser never sends to any server.
    $url = "http://127.0.0.1:$Port/hud#token=$token"
    $browsers = @(
        (Join-Path ${env:ProgramFiles(x86)} 'Microsoft\Edge\Application\msedge.exe'),
        (Join-Path $env:ProgramFiles 'Microsoft\Edge\Application\msedge.exe'),
        (Join-Path $env:ProgramFiles 'Google\Chrome\Application\chrome.exe'),
        (Join-Path ${env:ProgramFiles(x86)} 'Google\Chrome\Application\chrome.exe'),
        (Join-Path $env:LOCALAPPDATA 'Google\Chrome\Application\chrome.exe')
    )
    foreach ($browser in $browsers) {
        if ($browser -and (Test-Path -LiteralPath $browser)) {
            Start-Process -FilePath $browser -ArgumentList "--app=$url", '--window-size=1040,800'
            return
        }
    }
    Start-Process $url
}

function Start-Jarvis {
    Link-Antigravity $false
    Start-Bridge
    if (-not (Test-Server)) {
        Start-Server
        $ready = $false
        for ($i = 0; $i -lt 90; $i++) {
            Start-Sleep -Seconds 1
            if (Test-Server) { $ready = $true; break }
        }
        if (-not $ready) {
            Show-Problem "Jarvis did not start. Details are in $LogDir\server.err.log"
            exit 1
        }
    }
    Open-Hud
}

function New-Shortcut([string]$Folder) {
    if (-not $Folder -or -not (Test-Path -LiteralPath $Folder)) { return }
    $shell = New-Object -ComObject WScript.Shell
    $link = $shell.CreateShortcut((Join-Path $Folder 'Jarvis.lnk'))
    $link.TargetPath = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
    $link.Arguments = '-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + (Join-Path $Dest 'scripts\jarvis.ps1') + '" launch'
    $link.WorkingDirectory = $Dest
    $link.IconLocation = Join-Path $Dest 'Jarvis.ico'
    $link.WindowStyle = 7
    $link.Description = 'Jarvis'
    $link.Save()
}

function Install-Package([string]$Source) {
    if (-not $Source -or -not (Test-Path -LiteralPath (Join-Path $Source 'VERSION'))) {
        throw "Not a Jarvis release folder: $Source"
    }
    if (Test-Path -LiteralPath (Join-Path $Dest '.jarvis-dev')) {
        throw "This is a development copy ($Dest\.jarvis-dev). Not replacing it."
    }
    $python312 = Find-Python312
    if (-not $python312 -or -not (Test-Python312 $python312)) {
        throw "Jarvis needs Python 3.12. Nothing was changed. Run the installer again."
    }

    # Stop the running copy, then swap folders. The previous install stays in Jarvis.previous.
    Stop-Jarvis
    Start-Sleep -Seconds 1
    $previous = "$Dest.previous"
    if (Test-Path -LiteralPath $previous) { Remove-Item -LiteralPath $previous -Recurse -Force }
    if (Test-Path -LiteralPath $Dest) { Move-Item -LiteralPath $Dest -Destination $previous }
    Copy-Item -LiteralPath $Source -Destination $Dest -Recurse -Force

    $venv = Join-Path $Dest '.venv312'
    $venvPython = Join-Path $venv 'Scripts\python.exe'
    $oldVenv = Join-Path $previous '.venv312'
    if (Test-Python312 (Join-Path $oldVenv 'Scripts\python.exe')) {
        Move-Item -LiteralPath $oldVenv -Destination $venv
    } else {
        Write-Host 'Creating the Python environment...'
        & $python312 -m venv $venv
        if ($LASTEXITCODE -ne 0) { throw 'Could not create the Python environment.' }
    }
    Write-Host 'Installing Python packages (a few minutes the first time)...'
    & $venvPython -m pip install --quiet --disable-pip-version-check --upgrade pip
    & $venvPython -m pip install --quiet --disable-pip-version-check -r (Join-Path $Dest 'requirements.txt')
    if ($LASTEXITCODE -ne 0) { throw 'Installing Python packages failed. Check the internet connection and run the installer again.' }

    Initialize-Token

    # "jarvis" command: this folder is on every user's PATH on Windows 10 and 11.
    $apps = Join-Path $env:LOCALAPPDATA 'Microsoft\WindowsApps'
    if (Test-Path -LiteralPath $apps) {
        Copy-Item -LiteralPath (Join-Path $Dest 'scripts\jarvis.cmd') -Destination (Join-Path $apps 'jarvis.cmd') -Force
    }
    New-Shortcut ([Environment]::GetFolderPath('Programs'))
    New-Shortcut ([Environment]::GetFolderPath('Desktop'))

    $version = ([IO.File]::ReadAllText((Join-Path $Dest 'VERSION'))).Trim()
    Write-Host "Jarvis $version is installed. Opening it now..." -ForegroundColor Green
    Write-Host 'Next time, open Jarvis from the Start Menu or the desktop shortcut.'
    Start-Jarvis
}

function Update-Jarvis([bool]$Force) {
    if (Test-Path -LiteralPath (Join-Path $Dest '.jarvis-dev')) {
        throw "This is a development copy ($Dest\.jarvis-dev). Not replacing it."
    }
    $latest = Invoke-RestMethod -Uri "$Site/latest-windows.json?t=$([DateTime]::UtcNow.Ticks)"
    $local = 'none'
    $versionFile = Join-Path $Dest 'VERSION'
    if (Test-Path -LiteralPath $versionFile) { $local = ([IO.File]::ReadAllText($versionFile)).Trim() }
    if ($local -eq $latest.version -and -not $Force) {
        Write-Host "Jarvis is already up to date ($local)."
        return
    }
    Write-Host "Updating Jarvis $local -> $($latest.version)..."
    $temp = Join-Path ([IO.Path]::GetTempPath()) ('jarvis-' + [Guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Force -Path $temp | Out-Null
    try {
        $zip = Join-Path $temp 'jarvis.zip'
        Invoke-WebRequest -UseBasicParsing -Uri "$Site/$($latest.file)" -OutFile $zip
        $hash = (Get-FileHash -LiteralPath $zip -Algorithm SHA256).Hash.ToLower()
        if ($hash -ne "$($latest.sha256)".ToLower()) { throw 'Download check failed (hash mismatch). Keeping the current version.' }
        Expand-Archive -LiteralPath $zip -DestinationPath (Join-Path $temp 'pkg') -Force
        # The new release installs itself, so new install steps always run.
        $package = Join-Path $temp 'pkg\Jarvis'
        & (Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe') -NoProfile -ExecutionPolicy Bypass `
            -File (Join-Path $package 'scripts\jarvis.ps1') install-package $package
        if ($LASTEXITCODE -ne 0) { throw 'The update did not finish.' }
    } finally {
        Remove-Item -LiteralPath $temp -Recurse -Force -ErrorAction SilentlyContinue
    }
}

function Uninstall-Jarvis([string[]]$Options) {
    # Run a copy from TEMP: the uninstaller deletes this script's folder.
    $copy = Join-Path ([IO.Path]::GetTempPath()) ('jarvis-uninstall-' + [Guid]::NewGuid().ToString('N') + '.ps1')
    $packaged = Join-Path $Dest 'uninstall.ps1'
    if (Test-Path -LiteralPath $packaged) { Copy-Item -LiteralPath $packaged -Destination $copy }
    else { Invoke-WebRequest -UseBasicParsing -Uri "$Site/uninstall.ps1" -OutFile $copy }
    Set-Location -LiteralPath $env:TEMP
    try { & $copy @Options } finally { Remove-Item -LiteralPath $copy -Force -ErrorAction SilentlyContinue }
}

try {
    switch ($Command) {
        'launch' { Start-Jarvis }
        'link' { Link-Antigravity $true }
        'stop' { Stop-Jarvis; Write-Host 'Jarvis stopped.' }
        'status' {
            $versionFile = Join-Path $Dest 'VERSION'
            if (Test-Path -LiteralPath $versionFile) { Write-Host ('Version: ' + ([IO.File]::ReadAllText($versionFile)).Trim()) }
            if (Test-Server) { Write-Host 'Jarvis is running.' } else { Write-Host 'Jarvis is not running.' }
            $vault = Join-Path $env:USERPROFILE 'Library\Application Support\JARVIS\bridge\vault.enc'
            if ((Test-Path -LiteralPath $vault) -or (Test-Port 20128)) {
                if (Test-Port (Get-BridgePort)) { Write-Host 'Antigravity bridge is running.' }
                else { Write-Host 'Antigravity bridge is not running.' }
            }
        }
        'update' { Update-Jarvis ($Arg -eq '--force') }
        'install-package' { Install-Package $Arg }
        'bridge' {
            $node = Find-Node
            $bridge = Join-Path $Dest 'jarvis-bridge'
            $cli = Join-Path $bridge 'dist\src\cli.js'
            if (-not $node -or -not (Test-Path -LiteralPath $cli)) {
                throw 'The Antigravity bridge is not in this install. Update Jarvis and try again.'
            }
            $mutating = @('init', 'oauth-client', 'login', 'import-account', 'remove-account', 'alias-set', 'rotate-api-key', 'serve')
            if ($mutating -contains $Arg) {
                foreach ($proc in @(Get-BridgeProcesses)) {
                    Stop-Process -Id $proc.ProcessId -Force -ErrorAction SilentlyContinue
                }
                Start-Sleep -Seconds 1
            }
            $bridgeArgs = @()
            if ($Arg) { $bridgeArgs += $Arg }
            if ($Rest) { $bridgeArgs += @($Rest) }
            & $node $cli @bridgeArgs
            $code = $LASTEXITCODE
            if ($code -eq 0 -and ($Arg -eq 'login' -or $Arg -eq 'import-account')) { Connect-BridgeProvider }
            if ($code -ne 0) { exit $code }
        }
        'uninstall' { Uninstall-Jarvis (@($Arg) + $Rest) }
        default { Write-Host 'Usage: jarvis {launch|stop|status|link|update [--force]|bridge <args>|uninstall [-Yes] [-KeepData]}'; exit 1 }
    }
} catch {
    Write-Host $_.Exception.Message -ForegroundColor Red
    exit 1
}
