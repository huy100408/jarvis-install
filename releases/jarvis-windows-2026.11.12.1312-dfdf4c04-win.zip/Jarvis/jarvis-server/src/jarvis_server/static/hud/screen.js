// Live screen module for the Windows HUD: mirrors LiveScreenView, VirtualKeyboardBar and
// the Screen Streaming settings section of the Mac app. Talks to /ws/screen only while
// the Screen view is open. Input goes to the server exactly as the Mac app sends it.
(function () {
  'use strict';
  var H = window.JarvisHUD;
  if (!H) return;
  var $ = H.$, store = H.store;

  var css = [
    'html[data-theme="light"] .mod-screen,html[data-theme="light"] #modStream{--warn:#a8650c}',
    '.mod-screen{display:flex;flex-direction:column;height:100%;min-height:0;background:var(--void)}',
    '.scr-bar{display:flex;align-items:center;gap:12px;padding:8px 14px;background:var(--bar);border-bottom:1px solid var(--line);font:11px var(--mono);flex:none;min-width:0}',
    '.scr-live{display:flex;align-items:center;gap:6px;font-weight:700;color:var(--text);white-space:nowrap}',
    '.scr-live i{width:8px;height:8px;border-radius:50%;background:var(--bad);flex:none}',
    '.scr-live i.on{background:var(--ok)}',
    '.scr-bar .sp{flex:1}',
    '.scr-dim{color:var(--secondary);white-space:nowrap}',
    '.scr-fps{color:var(--accent);font-weight:600;white-space:nowrap}',
    '.scr-lat{color:var(--warn);white-space:nowrap}',
    '.scr-ico{width:28px;height:28px;border-radius:6px;background:var(--fill);color:var(--accent);display:inline-flex;align-items:center;justify-content:center;flex:none}',
    '.scr-view{position:relative;flex:1;min-height:0;overflow:hidden;touch-action:none;outline:none;background:var(--void)}',
    '.scr-view canvas{position:absolute;inset:0;width:100%;height:100%;display:block}',
    '.scr-view.m-pan{cursor:grab}.scr-view.m-click{cursor:crosshair}',
    '.scr-ph{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:14px;padding:24px;text-align:center}',
    '.scr-ph svg{color:var(--accent);opacity:.75}',
    '.scr-ph b{font:700 14px var(--mono);color:var(--text)}',
    '.scr-ph small{font:11px var(--mono);color:var(--secondary);overflow-wrap:anywhere}',
    '.scr-ph .err{color:var(--bad)}',
    '.scr-go{font:700 12px var(--mono);color:#041018;background:var(--accent);padding:10px 16px;border-radius:8px}',
    '.scr-rip{position:absolute;width:34px;height:34px;margin:-17px 0 0 -17px;border-radius:50%;border:2.5px solid var(--accent);pointer-events:none;animation:scrRip .42s ease-out forwards}',
    '.scr-rip.r{border-color:var(--warn)}',
    '@keyframes scrRip{from{transform:scale(.6);opacity:1}to{transform:scale(1.25);opacity:0}}',
    '.scr-tools{display:flex;align-items:center;gap:8px;padding:8px 12px;background:var(--bar);border-top:1px solid var(--line);flex:none;min-width:0}',
    '.scr-modes{flex:1;min-width:0;overflow-x:auto;scrollbar-width:none}',
    '.scr-modes::-webkit-scrollbar{display:none}',
    '.scr-modes .seg button{height:30px;padding:0 12px}',
    '.scr-one{font:700 11px var(--mono);color:var(--warn);padding:0 10px;height:34px;border-radius:8px;background:color-mix(in srgb,var(--warn) 14%,transparent);border:.75px solid color-mix(in srgb,var(--warn) 30%,transparent);flex:none}',
    '.scr-kb{min-height:40px;padding:0 12px;border-radius:10px;background:var(--fill);color:var(--accent);display:inline-flex;align-items:center;flex:none}',
    '.scr-kb.on{background:var(--accent);color:#041018}',
    '.scr-keys{margin:0 10px 6px;padding:12px;border-radius:16px;background:var(--card);border:1px solid color-mix(in srgb,var(--accent) 55%,transparent);display:flex;flex-direction:column;gap:10px;flex:none}',
    '.scr-row{display:flex;gap:8px;align-items:center;overflow-x:auto;scrollbar-width:none;padding:0 4px}',
    '.scr-row::-webkit-scrollbar{display:none}',
    '.scr-row button{flex:none;font:500 12px var(--mono);padding:6px 10px;border-radius:6px;white-space:nowrap}',
    '.k-mod{color:var(--accent);background:var(--fill);border:1px solid color-mix(in srgb,var(--accent) 45%,transparent);font-weight:600 !important}',
    '.k-mod.on{background:var(--accent);color:#041018}',
    '.k-sp{color:var(--text);background:var(--fill);border:1px solid color-mix(in srgb,var(--accent) 35%,transparent)}',
    '.k-hot{color:var(--warn);background:color-mix(in srgb,var(--warn) 14%,transparent);border:1px solid color-mix(in srgb,var(--warn) 45%,transparent);font-weight:700 !important;font-size:11px !important}',
    '.k-div{width:1px;height:22px;background:color-mix(in srgb,var(--accent) 30%,transparent);flex:none}',
    '.scr-type{display:flex;gap:8px;align-items:center}',
    '.scr-type input{flex:1;min-width:0;font:14px var(--mono);padding:9px 12px;border-radius:8px;background:var(--input);color:var(--text);border:1px solid color-mix(in srgb,var(--accent) 40%,transparent)}',
    '.scr-send{font:700 12px var(--mono);color:#041018;background:var(--accent);padding:10px 14px;border-radius:8px;flex:none}',
    '.scr-close{padding:9px;border-radius:8px;background:var(--fill);color:var(--secondary);display:inline-flex;flex:none}',
    '.mod-screen:fullscreen{width:100vw;height:100vh}',
    '.stream-row{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:6px 0;color:var(--text)}',
    '.stepper{display:inline-flex;align-items:center;gap:10px}',
    '.stepper output{font-family:var(--mono);min-width:48px;text-align:right;color:var(--secondary)}',
    '.stepper span{display:inline-flex;background:var(--seg);border-radius:8px;padding:2px}',
    '.stepper button{width:34px;height:26px;border-radius:6px;font-size:16px;line-height:1;color:var(--text)}',
    '.stepper button:hover:not(:disabled){background:var(--seg-on)}',
    '@media (max-width:760px){.scr-bar{gap:8px;padding:8px 10px}.scr-dim{display:none}.scr-tools{padding:8px}.scr-modes .seg button span{display:none}.scr-modes .seg button{padding:0 10px}}'
  ].join('\n');
  var style = document.createElement('style');
  style.textContent = css;
  document.head.appendChild(style);

  function svg(d, size) {
    return '<svg width="' + (size || 14) + '" height="' + (size || 14) + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">' + d + '</svg>';
  }
  var ICON = {
    bolt: '<path d="M13 3L5 13h6l-1 8 8-10h-6z"/>',
    retry: '<path d="M20 11a8 8 0 1 0-2.3 5.7"/><path d="M20 4v7h-7"/>',
    full: '<path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/>',
    exit: '<path d="M9 4v5H4M15 4v5h5M9 20v-5H4M15 20v-5h5"/>',
    kb: '<rect x="2" y="6" width="20" height="12" rx="2"/><path d="M6 10h.01M10 10h.01M14 10h.01M18 10h.01M7 14h10"/>',
    kbDown: '<rect x="2" y="3" width="20" height="11" rx="2"/><path d="M7 10h10M9 18l3 3 3-3"/>',
    display: '<rect x="3" y="4" width="18" height="12" rx="2"/><path d="M8 20h8M12 7v4M12 13h.01"/>',
    tap: '<path d="M9 11V5a2 2 0 0 1 4 0v6l4 1a2 2 0 0 1 1.5 2.3L17.5 20H10l-4-5 1.3-1.3a1.5 1.5 0 0 1 1.7-.3z"/>',
    dbl: '<path d="M9 11V5a2 2 0 0 1 4 0v6l4 1a2 2 0 0 1 1.5 2.3L17.5 20H10l-4-5 1.3-1.3a1.5 1.5 0 0 1 1.7-.3z"/><path d="M5 5a6 6 0 0 1 2-2M19 5a6 6 0 0 0-2-2"/>',
    right: '<rect x="3" y="3" width="11" height="14" rx="2"/><path d="M3 8h11M15 13l6 6M15 13v6l1.5-1.5"/>',
    drag: '<path d="M8 13V5a2 2 0 0 1 4 0v6M12 11V4a2 2 0 0 1 4 0v8M16 12V7a2 2 0 0 1 4 0v7a7 7 0 0 1-7 7h-1a7 7 0 0 1-6-3.5L4 14a2 2 0 0 1 3.4-2.1L8 13"/>',
    scroll: '<path d="M12 3v18M3 12h18M9 6l3-3 3 3M9 18l3 3 3-3M6 9l-3 3 3 3M18 9l3 3-3 3"/>',
    zoom: '<circle cx="10.5" cy="10.5" r="6.5"/><path d="M21 21l-5.5-5.5M10.5 7.5v6M7.5 10.5h6"/>'
  };
  var MODES = [
    ['tap', 'Left Click', ICON.tap], ['double', 'Double Click', ICON.dbl], ['right', 'Right Click', ICON.right],
    ['drag', 'Drag', ICON.drag], ['scroll', 'Scroll', ICON.scroll], ['pan', 'Pan & Zoom', ICON.zoom]
  ];

  // ---- stream settings (the server keeps its own fps/quality in config; these are saved on this PC like the Mac app) ----
  function num(k, d, lo, hi) { var v = parseInt(store.get(k), 10); return isNaN(v) ? d : Math.min(hi, Math.max(lo, v)); }
  var prefs = {
    fps: num('jarvis.screen.fps', 20, 1, 30),
    quality: num('jarvis.screen.quality', 65, 25, 95),
    reconnect: store.get('jarvis.screen.reconnect') !== '0'
  };

  // ---- DOM ----
  var root = $('modScreen');
  root.innerHTML =
    '<div class="scr-bar">' +
      '<span class="scr-live"><i id="scrDot"></i><span id="scrState">STREAM OFFLINE</span></span><span class="sp"></span>' +
      '<span class="scr-dim" id="scrDim">0×0</span><span class="scr-fps" id="scrFps">0.0 FPS</span><span class="scr-lat" id="scrLat">0 ms</span>' +
      '<button type="button" class="scr-ico" id="scrToggle" aria-label="Connect display stream">' + svg(ICON.retry, 13) + '</button>' +
      '<button type="button" class="scr-ico" id="scrFull" aria-label="Full screen">' + svg(ICON.full, 13) + '</button>' +
    '</div>' +
    '<div class="scr-view m-click" id="scrView" tabindex="0" aria-label="Live screen">' +
      '<canvas id="scrCanvas"></canvas>' +
      '<div class="scr-ph" id="scrPh">' + svg(ICON.display, 44) +
        '<b>AWAITING SCREEN STREAM</b><small id="scrUrl"></small><small class="err" id="scrErr"></small>' +
        '<button type="button" class="scr-go" id="scrGo">CONNECT DISPLAY STREAM</button></div>' +
    '</div>' +
    '<div class="scr-keys" id="scrKeys" hidden>' +
      '<div class="scr-row" id="kRow1"></div><div class="scr-row" id="kRow2"></div>' +
      '<div class="scr-type"><input id="scrText" type="text" autocomplete="off" spellcheck="false" placeholder="Type text to send to the computer..." aria-label="Text to send">' +
      '<button type="button" class="scr-send" id="scrSend">SEND</button>' +
      '<button type="button" class="scr-close" id="scrKbClose" aria-label="Hide keyboard">' + svg(ICON.kbDown, 16) + '</button></div>' +
    '</div>' +
    '<div class="scr-tools">' +
      '<div class="scr-modes"><div class="seg" id="scrModes">' + MODES.map(function (m, i) {
        return '<button type="button" data-mode="' + m[0] + '"' + (i ? '' : ' class="on"') + ' title="' + m[1] + '">' + svg(m[2], 14) + '<span>' + m[1] + '</span></button>';
      }).join('') + '</div></div>' +
      '<button type="button" class="scr-one" id="scrOne" hidden>1:1</button>' +
      '<button type="button" class="scr-kb" id="scrKb" aria-label="Keyboard" aria-pressed="false">' + svg(ICON.kb, 18) + '</button>' +
    '</div>';
  $('scrUrl').textContent = (location.protocol === 'https:' ? 'wss://' : 'ws://') + location.host + '/ws/screen';

  var view = $('scrView'), canvas = $('scrCanvas'), ctx = canvas.getContext('2d');

  // ---- connection ----
  var ws = null, wantOpen = false, manualOff = false, retry = 1000, retryTimer = 0, pingTimer = 0;
  var live = false, remote = { w: 0, h: 0 }, bitmap = null, measured = 0, latency = 0;
  var winCount = 0, winStart = 0, pendingBlob = null, decoding = false, lastDecode = 0, frameTimer = 0;

  function connect() {
    var token = store.get('jarvis.token'); // used only to authenticate the socket, never shown or logged
    if (!token || (ws && ws.readyState < 2)) return;
    clearTimeout(retryTimer);
    $('scrErr').textContent = '';
    var sock = new WebSocket((location.protocol === 'https:' ? 'wss://' : 'ws://') + location.host + '/ws/screen?token=' + encodeURIComponent(token));
    sock.binaryType = 'blob';
    ws = sock;
    sock.onopen = function () {
      if (ws !== sock) return;
      live = true; retry = 1000; winCount = 0; winStart = performance.now();
      clearInterval(pingTimer);
      pingTimer = setInterval(function () { send({ type: 'ping', timestamp: Date.now() / 1000 }); }, 5000);
      paintStatus();
    };
    sock.onmessage = function (ev) { if (ws === sock) onMessage(ev.data); };
    sock.onclose = function () {
      if (ws !== sock) return;
      ws = null; live = false; measured = 0;
      clearInterval(pingTimer);
      paintStatus();
      if (wantOpen && !manualOff && prefs.reconnect) {
        $('scrErr').textContent = 'Stream dropped. Reconnecting in ' + Math.round(retry / 1000) + ' s…';
        retryTimer = setTimeout(connect, retry);
        retry = Math.min(retry * 2, 15000);
      } else if (wantOpen && !manualOff) {
        $('scrErr').textContent = 'Stream closed.';
      }
    };
  }
  function disconnect() {
    clearTimeout(retryTimer); clearInterval(pingTimer); clearTimeout(frameTimer);
    var s = ws; ws = null; live = false; measured = 0; pendingBlob = null;
    if (s && typeof s.close === 'function') { try { s.close(1000); } catch (e) {} }
    paintStatus(); draw();
  }
  function send(obj) {
    if (!ws || ws.readyState !== 1) return false;
    ws.send(JSON.stringify(obj));
    return true;
  }
  function onMessage(data) {
    if (typeof data !== 'string') { pendingBlob = data; pump(); return; }
    var d; try { d = JSON.parse(data); } catch (e) { return; }
    if (d.type === 'init') { remote = { w: +d.width || 0, h: +d.height || 0 }; paintStatus(); }
    else if (d.action === 'pong' && d.timestamp > 0) { latency = Math.max(1, Math.min(9999, Math.round(Date.now() - d.timestamp * 1000))); paintStatus(); }
    else if (d.type === 'error' && d.error) { $('scrErr').textContent = String(d.error); }
  }
  // Decode the newest frame only, at most at the target frame rate.
  function pump() {
    if (decoding || !pendingBlob) return;
    var wait = 1000 / prefs.fps - (performance.now() - lastDecode);
    if (wait > 1) { clearTimeout(frameTimer); frameTimer = setTimeout(pump, wait); return; }
    var blob = pendingBlob; pendingBlob = null; decoding = true; lastDecode = performance.now();
    createImageBitmap(blob).then(function (bmp) {
      decoding = false;
      if (!live) { bmp.close && bmp.close(); return; }
      if (bitmap && bitmap.close) bitmap.close();
      bitmap = bmp;
      if (!remote.w) remote = { w: bmp.width, h: bmp.height };
      winCount++;
      var now = performance.now();
      if (now - winStart >= 1000) { measured = winCount * 1000 / (now - winStart); winCount = 0; winStart = now; paintStatus(); }
      draw(); pump();
    }, function () { decoding = false; pump(); });
  }

  // ---- status / telemetry ----
  var shownLive = null;
  function paintStatus() {
    $('scrDot').classList.toggle('on', live);
    $('scrState').textContent = live ? 'DISPLAY LIVE' : 'STREAM OFFLINE';
    $('scrDim').textContent = remote.w + '×' + remote.h;
    $('scrFps').textContent = measured.toFixed(1) + ' FPS';
    $('scrLat').textContent = latency + ' ms';
    if (shownLive !== live) {
      shownLive = live;
      $('scrToggle').innerHTML = svg(live ? ICON.bolt : ICON.retry, 13);
      $('scrToggle').setAttribute('aria-label', live ? 'Disconnect display stream' : 'Connect display stream');
    }
    $('scrPh').hidden = !!(live && bitmap);
    $('scrGo').hidden = !!(ws && ws.readyState < 2);
    var t = $('tel-screen'); if (t) t.textContent = measured.toFixed(1) + ' FPS · ' + latency + ' MS';
    var dsp = $('tel-display'); if (dsp) dsp.textContent = remote.w + '×' + remote.h;
    var c = $('cornerFps'); if (c) c.textContent = live ? Math.round(measured) + ' FPS' : '—';
  }

  // ---- drawing, zoom and pan (same maths as ViewportCoordinateMapper) ----
  var zoom = 1, pan = { x: 0, y: 0 }, raf = 0;
  function size() { return { w: view.clientWidth, h: view.clientHeight }; }
  function fitted() {
    var s = size(), iw = bitmap ? bitmap.width : remote.w, ih = bitmap ? bitmap.height : remote.h;
    if (!iw || !ih || !s.w || !s.h) return { x: 0, y: 0, w: s.w, h: s.h };
    var k = Math.min(s.w / iw, s.h / ih);
    return { x: (s.w - iw * k) / 2, y: (s.h - ih * k) / 2, w: iw * k, h: ih * k };
  }
  function draw() {
    if (raf) return;
    raf = requestAnimationFrame(function () {
      raf = 0;
      var s = size(), dpr = window.devicePixelRatio || 1;
      var cw = Math.round(s.w * dpr), ch = Math.round(s.h * dpr);
      if (canvas.width !== cw || canvas.height !== ch) { canvas.width = cw; canvas.height = ch; }
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, s.w, s.h);
      paintStatus();
      if (!bitmap || !live) return;
      var r = fitted(), cx = s.w / 2, cy = s.h / 2;
      ctx.imageSmoothingQuality = 'high';
      ctx.drawImage(bitmap, cx + (r.x - cx) * zoom + pan.x, cy + (r.y - cy) * zoom + pan.y, r.w * zoom, r.h * zoom);
    });
  }
  function normalized(px, py) {
    var r = fitted(), s = size();
    if (!r.w || !r.h) return null;
    var cx = s.w / 2, cy = s.h / 2;
    var ux = cx + (px - pan.x - cx) / zoom, uy = cy + (py - pan.y - cy) / zoom;
    var nx = (ux - r.x) / r.w, ny = (uy - r.y) / r.h;
    if (nx < -0.02 || nx > 1.02 || ny < -0.02 || ny > 1.02) return null;
    return { x: Math.min(1, Math.max(0, nx)), y: Math.min(1, Math.max(0, ny)) };
  }
  function setZoom(z) {
    zoom = Math.min(4.5, Math.max(1, z));
    if (zoom <= 1.02) { zoom = 1; pan = { x: 0, y: 0 }; }
    $('scrOne').hidden = !(zoom > 1.01 || pan.x || pan.y);
    draw();
  }
  if (window.ResizeObserver) new ResizeObserver(draw).observe(view);
  else window.addEventListener('resize', draw);

  // ---- pointer input ----
  var mode = 'tap', pointers = {}, gesture = null;
  function local(e) { var b = view.getBoundingClientRect(); return { x: e.clientX - b.left, y: e.clientY - b.top }; }
  function ripple(p, right) {
    var el = document.createElement('div');
    el.className = 'scr-rip' + (right ? ' r' : '');
    el.style.left = p.x + 'px'; el.style.top = p.y + 'px';
    view.appendChild(el);
    setTimeout(function () { el.remove(); }, 420);
  }
  function tapAt(p, forceRight) {
    var n = normalized(p.x, p.y);
    if (!n || !live) return;
    var right = forceRight || mode === 'right';
    ripple(p, right);
    if (right) send({ type: 'click', x: n.x, y: n.y, normalized: true, button: 'right' });
    else send({ type: 'tap', x: n.x, y: n.y, normalized: true, button: 'left', double: mode === 'double' });
  }
  view.addEventListener('pointerdown', function (e) {
    if ((e.button !== 0 && e.pointerType === 'mouse') || e.target.closest('button')) return;
    view.focus({ preventScroll: true });
    view.setPointerCapture(e.pointerId);
    pointers[e.pointerId] = local(e);
    var ids = Object.keys(pointers);
    if (ids.length === 2) {
      var a = pointers[ids[0]], b = pointers[ids[1]];
      gesture = { pinch: Math.hypot(a.x - b.x, a.y - b.y) || 1, zoom: zoom };
      return;
    }
    var p = pointers[e.pointerId];
    gesture = { start: p, last: p, pan: { x: pan.x, y: pan.y }, moved: 0, from: mode === 'drag' ? normalized(p.x, p.y) : null };
  });
  view.addEventListener('pointermove', function (e) {
    if (!pointers[e.pointerId] || !gesture) return;
    var p = pointers[e.pointerId] = local(e), ids = Object.keys(pointers);
    if (gesture.pinch) {
      if (ids.length === 2) { var a = pointers[ids[0]], b = pointers[ids[1]]; setZoom(gesture.zoom * Math.hypot(a.x - b.x, a.y - b.y) / gesture.pinch); }
      return;
    }
    var dx = p.x - gesture.start.x, dy = p.y - gesture.start.y;
    gesture.moved = Math.max(gesture.moved, Math.hypot(dx, dy));
    if (mode === 'pan' || (zoom > 1.05 && gesture.moved > 6 && mode !== 'scroll' && mode !== 'drag')) {
      pan = { x: gesture.pan.x + dx, y: gesture.pan.y + dy };
      setZoom(zoom);
    } else if (mode === 'scroll' && gesture.moved > 4) {
      // Incremental: content follows the finger like the Mac trackpad mode.
      var sx = Math.round(-(p.x - gesture.last.x) / 18), sy = Math.round((p.y - gesture.last.y) / 14);
      if (sx || sy) { send({ type: 'scroll', dx: sx, dy: sy }); gesture.last = p; }
    }
  });
  function endPointer(e) {
    if (!pointers[e.pointerId]) return;
    var p = local(e);
    delete pointers[e.pointerId];
    var g = gesture;
    if (!g || g.pinch) { if (!Object.keys(pointers).length) gesture = null; return; }
    gesture = null;
    if (e.type === 'pointercancel' || mode === 'pan' || mode === 'scroll') return;
    if (mode === 'drag') {
      var to = normalized(p.x, p.y);
      if (g.moved > 6 && g.from && to) {
        if (live) send({ type: 'drag', from_x: g.from.x, from_y: g.from.y, to_x: to.x, to_y: to.y, normalized: true, button: 'left', duration: 0.22 });
      } else tapAt(g.start);
      return;
    }
    if (zoom > 1.05 && g.moved > 8) return;
    tapAt(g.start);
  }
  view.addEventListener('pointerup', endPointer);
  view.addEventListener('pointercancel', endPointer);
  // A real right click is a right click in any pointer mode.
  view.addEventListener('contextmenu', function (e) {
    e.preventDefault();
    if (mode !== 'pan' && mode !== 'scroll') tapAt(local(e), true);
  });
  view.addEventListener('wheel', function (e) {
    e.preventDefault();
    if (e.ctrlKey || mode === 'pan') { setZoom(zoom * Math.exp(-e.deltaY / 300)); return; }
    if (mode !== 'scroll') return;
    var unit = e.deltaMode === 1 ? 1 : 40;
    var sx = Math.round(e.deltaX / unit), sy = Math.round(-e.deltaY / unit);
    if (!sx && e.deltaX) sx = e.deltaX > 0 ? 1 : -1;
    if (!sy && e.deltaY) sy = e.deltaY > 0 ? -1 : 1;
    send({ type: 'scroll', dx: sx, dy: sy });
  }, { passive: false });

  $('scrModes').addEventListener('click', function (e) {
    var b = e.target.closest('[data-mode]');
    if (!b) return;
    mode = b.getAttribute('data-mode');
    this.querySelectorAll('button').forEach(function (x) { x.classList.toggle('on', x === b); });
    view.className = 'scr-view ' + (mode === 'pan' ? 'm-pan' : 'm-click');
  });
  $('scrOne').onclick = function () { pan = { x: 0, y: 0 }; setZoom(1); };

  // ---- header buttons ----
  function userConnect() { manualOff = false; retry = 1000; connect(); paintStatus(); }
  $('scrGo').onclick = userConnect;
  $('scrToggle').onclick = function () {
    if (ws && ws.readyState < 2) { manualOff = true; disconnect(); } else userConnect();
  };
  $('scrFull').onclick = function () {
    if (document.fullscreenElement) document.exitFullscreen();
    else if (root.requestFullscreen) root.requestFullscreen().catch(function () {});
  };
  document.addEventListener('fullscreenchange', function () {
    var on = document.fullscreenElement === root;
    $('scrFull').innerHTML = svg(on ? ICON.exit : ICON.full, 13);
    $('scrFull').setAttribute('aria-label', on ? 'Exit full screen' : 'Full screen');
    draw();
  });

  // ---- virtual keyboard bar ----
  var mods = { command: false, option: false, control: false, shift: false };
  function activeMods() { return Object.keys(mods).filter(function (k) { return mods[k]; }); }
  function clearMods() { Object.keys(mods).forEach(function (k) { mods[k] = false; }); paintMods(); }
  function paintMods() { $('kRow1').querySelectorAll('[data-mod]').forEach(function (b) { var on = mods[b.getAttribute('data-mod')]; b.classList.toggle('on', on); b.setAttribute('aria-pressed', on ? 'true' : 'false'); }); }
  function sendKey(key, m) { var p = { type: 'key', key: key }; if (m.length) p.modifiers = m; send(p); }
  function btn(cls, label, attrs) { return '<button type="button" class="' + cls + '"' + (attrs || '') + '>' + label + '</button>'; }
  $('kRow1').innerHTML =
    [['command', '⌘ Cmd'], ['option', '⌥ Opt'], ['control', '⌃ Ctrl'], ['shift', '⇧ Shift']].map(function (m) { return btn('k-mod', m[1], ' data-mod="' + m[0] + '" aria-pressed="false"'); }).join('') +
    '<i class="k-div"></i>' +
    [['⌘Space', 'command,space'], ['⌘C', 'command,c'], ['⌘V', 'command,v'], ['⌘Z', 'command,z'], ['⌘W', 'command,w'], ['⌘Tab', 'command,tab']].map(function (h) { return btn('k-hot', h[0], ' data-hot="' + h[1] + '"'); }).join('');
  $('kRow2').innerHTML = [['Esc', 'escape'], ['Tab ⇥', 'tab'], ['Space', 'space'], ['⌫ Back', 'backspace'], ['⏎ Return', 'return'], ['←', 'left'], ['↑', 'up'], ['↓', 'down'], ['→', 'right']]
    .map(function (k) { return btn('k-sp', k[0], ' data-key="' + k[1] + '"'); }).join('');
  $('scrKeys').addEventListener('click', function (e) {
    var b = e.target.closest('button');
    if (!b) return;
    if (b.hasAttribute('data-mod')) { var k = b.getAttribute('data-mod'); mods[k] = !mods[k]; paintMods(); }
    else if (b.hasAttribute('data-hot')) send({ type: 'hotkey', keys: b.getAttribute('data-hot').split(',') });
    else if (b.hasAttribute('data-key')) { sendKey(b.getAttribute('data-key'), activeMods()); clearMods(); }
  });
  function submitText() {
    var t = $('scrText').value, m = activeMods();
    if (!t) sendKey('return', m);
    else if (m.length && t.length === 1) sendKey(t.toLowerCase(), m);
    else send({ type: 'type_text', text: t });
    $('scrText').value = '';
    clearMods();
  }
  $('scrSend').onclick = submitText;
  $('scrText').addEventListener('keydown', function (e) { if (e.key === 'Enter' && !e.isComposing) { e.preventDefault(); submitText(); } });
  function showKeys(on) {
    $('scrKeys').hidden = !on;
    $('scrKb').classList.toggle('on', on);
    $('scrKb').setAttribute('aria-pressed', on ? 'true' : 'false');
    $('scrKb').innerHTML = svg(ICON.kb, 18);
    draw();
  }
  $('scrKb').onclick = function () { showKeys($('scrKeys').hidden); };
  $('scrKbClose').onclick = function () { showKeys(false); };

  // ---- connect only while the Screen view is visible ----
  H.on('view', function (dest) {
    wantOpen = dest === 'screen';
    if (wantOpen) { if (!manualOff) connect(); draw(); }
    else { disconnect(); if (document.fullscreenElement === root) document.exitFullscreen(); }
  });

  // ---- Settings > Connection > Screen Streaming ----
  var slot = $('modStream');
  if (slot) {
    slot.innerHTML = '<h3>Screen Streaming</h3><div class="card">' +
      '<div class="stream-row"><span>Target Frame Rate</span><span class="stepper"><output id="stFps"></output><span>' +
        '<button type="button" data-step="fps,-1" aria-label="Lower frame rate">−</button><button type="button" data-step="fps,1" aria-label="Raise frame rate">+</button></span></span></div>' +
      '<div class="stream-row"><span>JPEG Compression Quality</span><span class="stepper"><output id="stQ"></output><span>' +
        '<button type="button" data-step="quality,-5" aria-label="Lower quality">−</button><button type="button" data-step="quality,5" aria-label="Raise quality">+</button></span></span></div>' +
      '<label class="switchline"><span>Reconnect automatically<small>Retry the live screen when the stream drops.</small></span><input type="checkbox" id="stRe"></label>' +
      '<p class="note" style="margin:6px 0 0">Saved on this PC. The frame rate limits how often the live screen redraws here; the server encodes frames at the quality in its own config.</p>' +
      '</div>';
    var draft = {};
    var LIM = { fps: [1, 30], quality: [25, 95] };
    var paintDraft = function () {
      $('stFps').textContent = draft.fps + ' fps';
      $('stQ').textContent = draft.quality + '%';
      $('stRe').checked = draft.reconnect;
      slot.querySelectorAll('[data-step]').forEach(function (b) {
        var a = b.getAttribute('data-step').split(','), d = +a[1], v = draft[a[0]];
        b.disabled = d < 0 ? v <= LIM[a[0]][0] : v >= LIM[a[0]][1];
      });
    };
    var reset = function () { draft = { fps: prefs.fps, quality: prefs.quality, reconnect: prefs.reconnect }; paintDraft(); };
    slot.addEventListener('click', function (e) {
      var b = e.target.closest('[data-step]');
      if (!b) return;
      var a = b.getAttribute('data-step').split(','), k = a[0];
      draft[k] = Math.min(LIM[k][1], Math.max(LIM[k][0], draft[k] + +a[1]));
      paintDraft();
    });
    $('stRe').onchange = function () { draft.reconnect = this.checked; };
    reset();
    H.on('settings', reset);
    // The server has no fields for these, so they never go into the PUT body.
    H.on('settings:collect', function () {
      prefs = { fps: draft.fps, quality: draft.quality, reconnect: draft.reconnect };
      store.set('jarvis.screen.fps', String(prefs.fps));
      store.set('jarvis.screen.quality', String(prefs.quality));
      store.set('jarvis.screen.reconnect', prefs.reconnect ? '1' : '0');
    });
  }

  paintStatus();
})();
