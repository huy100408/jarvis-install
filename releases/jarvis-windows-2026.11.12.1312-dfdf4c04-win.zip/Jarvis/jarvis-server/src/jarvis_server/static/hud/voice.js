// Voice module for the Windows HUD: spoken replies, startup music and greeting,
// "Hey Jarvis" wake word, hold-to-talk mic and the Speech & Audio Synthesis settings.
// Mirrors the Mac AudioPlayerService, SpeechRecognizerService, JarvisStartupView and SettingsView.
(function () {
  'use strict';
  var H = window.JarvisHUD;
  if (!H) return;
  var $ = H.$, store = H.store;

  var css = document.createElement('style');
  css.textContent = [
    '.mic-btn{touch-action:none}',
    '.voice-copy{bottom:40px;display:flex;flex-direction:column;align-items:center;gap:14px}',
    '.voice-copy p{margin:0;font-size:13px;font-weight:500;color:var(--secondary)}',
    '.voice-copy .mic-btn{width:60px;height:60px}',
    '.voice-copy .mic-btn svg{width:22px;height:22px}',
    '.voice-wake{font:11px/1 var(--mono);letter-spacing:.08em;color:var(--accent)}',
    '.vx-seg{display:flex;flex-wrap:wrap;width:100%;margin:8px 0}',
    '.vx-seg button{flex:1 1 0;min-width:0;justify-content:center;padding:7px 6px;overflow:hidden;text-overflow:ellipsis}',
    '@media (max-width:760px){.voice-copy{bottom:28px}}'
  ].join('\n');
  document.head.appendChild(css);

  function clean(text) { return String(text || '').replace(/\*/g, '').replace(/\s+/g, ' ').trim(); }

  // ---------- Playback: one ordered queue for server audio and browser speech ----------
  var queue = [], current = null, ctx = null, analyser = null, meter = 0, safety = 0;
  function audioCtx() {
    var AC = window.AudioContext || window.webkitAudioContext;
    if (!ctx && AC) {
      try { ctx = new AC(); analyser = ctx.createAnalyser(); analyser.fftSize = 1024; analyser.connect(ctx.destination); } catch (e) { ctx = null; }
    }
    if (ctx && ctx.state === 'suspended') ctx.resume().catch(function () {});
    return ctx;
  }
  // Browsers only start audio after a click; unlock the analyser on the first one.
  document.addEventListener('pointerdown', audioCtx, true);

  function setLevel(v) { H.setLevel(v); }
  function startMeter(fromAnalyser) {
    clearInterval(meter);
    var buf = fromAnalyser ? new Float32Array(analyser.fftSize) : null, phase = 0;
    meter = setInterval(function () {
      if (buf) {
        // Same scale as the Mac meter: -50 dB..0 dB mapped to 0..1.
        analyser.getFloatTimeDomainData(buf);
        var sum = 0;
        for (var i = 0; i < buf.length; i++) sum += buf[i] * buf[i];
        var db = 20 * Math.log10(Math.sqrt(sum / buf.length) || 1e-8);
        setLevel((Math.max(-50, Math.min(0, db)) + 50) / 50);
      } else {
        phase += 0.4;
        setLevel(Math.min(1, Math.max(0.1, (Math.sin(phase) + 1) / 2 * 0.5 + 0.2 + Math.random() * 0.3)));
      }
    }, 50);
  }
  function finishItem(item) {
    if (current !== item) return;
    clearInterval(meter); clearTimeout(safety);
    if (item.url) URL.revokeObjectURL(item.url);
    current = null;
    next();
  }
  function next() {
    if (current) return;
    var item = queue.shift();
    if (!item) { setLevel(0); H.setSpeaking(false); emitSpeaking(false); return; }
    current = item;
    H.setSpeaking(true); emitSpeaking(true);
    if (item.blob) playBlob(item); else speakNative(item);
  }
  function playBlob(item) {
    item.url = URL.createObjectURL(item.blob);
    var el = new Audio(item.url);
    item.el = el;
    var c = audioCtx(), routed = false;
    // A suspended context would silence the element, so only route through it when running.
    if (c && c.state === 'running') {
      try { c.createMediaElementSource(el).connect(analyser); routed = true; } catch (e) { routed = false; }
    }
    el.onended = function () { finishItem(item); };
    el.onerror = function () { if (current === item) { item.blob = null; speakNative(item); } };
    el.play().then(function () { if (current === item) startMeter(routed); })
      .catch(function () { if (current === item) { item.blob = null; speakNative(item); } });
  }
  function pickVoice(lang) {
    var list = (window.speechSynthesis && speechSynthesis.getVoices()) || [];
    var mine = list.filter(function (v) { return (v.lang || '').toLowerCase().indexOf(lang) === 0; });
    if (lang === 'en') {
      var names = ['Daniel', 'Samantha', 'Alex', 'George', 'Ryan'];
      for (var i = 0; i < names.length; i++) {
        for (var j = 0; j < mine.length; j++) if (mine[j].name.indexOf(names[i]) >= 0) return mine[j];
      }
      return mine.filter(function (v) { return /en-GB/i.test(v.lang); })[0] || mine[0] || null;
    }
    return mine.filter(function (v) { return /Linh|An\b/.test(v.name); })[0] || mine[0] || null;
  }
  function speakNative(item) {
    var text = clean(item.text);
    if (!text || !window.speechSynthesis || !window.SpeechSynthesisUtterance) { finishItem(item); return; }
    var lang = H.language === 'vi' ? 'vi' : 'en';
    var u = new SpeechSynthesisUtterance(text);
    u.lang = lang === 'vi' ? 'vi-VN' : 'en-GB';
    var v = pickVoice(lang);
    if (v) u.voice = v;
    u.onend = u.onerror = function () { finishItem(item); };
    item.utterance = u;
    startMeter(false);
    // Some engines never fire onend; never leave the HUD stuck on "Speaking".
    clearTimeout(safety);
    safety = setTimeout(function () { finishItem(item); }, 6000 + text.length * 120);
    try { speechSynthesis.speak(u); } catch (e) { finishItem(item); }
  }
  function b64Blob(b64, format) {
    var s = String(b64);
    var comma = s.indexOf(',');
    if (comma >= 0) s = s.slice(comma + 1);
    try {
      var bin = atob(s.replace(/\s/g, '')), bytes = new Uint8Array(bin.length);
      for (var i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
      if (!bytes.length) return null;
      var f = String(format || 'mp3').toLowerCase();
      return new Blob([bytes], { type: f === 'wav' ? 'audio/wav' : f === 'ogg' ? 'audio/ogg' : 'audio/mpeg' });
    } catch (e) { return null; }
  }
  function enqueue(text, blob) {
    if (!blob && !clean(text)) return;
    queue.push({ text: text, blob: blob || null });
    next();
  }
  function stopPlayback() {
    queue = [];
    var item = current;
    current = null;
    clearInterval(meter); clearTimeout(safety);
    if (item && item.el) { try { item.el.pause(); } catch (e) {} }
    if (item && item.url) URL.revokeObjectURL(item.url);
    if (window.speechSynthesis) { try { speechSynthesis.cancel(); } catch (e) {} }
    if (item) { setLevel(0); H.setSpeaking(false); emitSpeaking(false); }
  }
  function autoPlay() { return store.get('jarvis.autoPlay') !== '0'; }

  H.on('ws:voice', function (d) {
    if (!autoPlay()) return;
    enqueue(d.text || '', d.audio ? b64Blob(d.audio, d.format) : null);
  });
  H.on('command', stopPlayback);
  H.on('ws:task_cancelled', stopPlayback);
  H.on('ws:status', function (d) { if (/^Executing: /.test(d.command || d.detail || '')) stopPlayback(); });

  // ---------- Startup music and greeting (JarvisStartupView) ----------
  var music = null;
  function greetingText(hon) {
    var h = new Date().getHours();
    var prefix = h >= 4 && h < 12 ? 'Good morning' : (h >= 12 && h < 18 ? 'Good afternoon' : 'Good evening');
    return prefix + ', ' + (String(hon || '').trim() || 'Sir') + '. Jarvis is online and ready.';
  }
  H.on('boot', function (ok) {
    if (!ok) return;
    try {
      music = new Audio('/hud/assets/startup.mp3');
      music.volume = 0.55;
      var p = music.play();
      if (p && p.catch) p.catch(function () { music = null; });
    } catch (e) { music = null; }
    setTimeout(function () {
      var s = H.settings;
      if (s) { stopPlayback(); enqueue(greetingText(s.honorific)); return; }
      H.api('/api/settings').then(function (x) { return x.honorific; }, function () { return 'Sir'; })
        .then(function (hon) { stopPlayback(); enqueue(greetingText(hon)); });
    }, 250);
  });
  H.on('reveal', function () {
    var m = music;
    music = null;
    if (!m) return;
    var step = 10;
    var t = setInterval(function () {
      step -= 1;
      m.volume = Math.max(0, step / 10 * 0.55);
      if (step <= 0) { clearInterval(t); m.pause(); }
    }, 60);
  });

  // hud.html owns hold-to-talk; a press just silences Jarvis and frees the mic from the wake word.
  document.querySelectorAll('.mic-btn').forEach(function (b) {
    b.addEventListener('pointerdown', function (e) { if (e.button === 0) { stopPlayback(); stopWake(); } }, true);
    b.addEventListener('keydown', function (e) { if (e.key === 'Enter' || e.key === ' ') stopWake(); }, true);
  });
  var ear = $('btnEar');
  if (ear) ear.addEventListener('click', function () { stopWake(); }, true);

  // Voice view: the Mac comms panel is the orb with a large hold-to-talk mic.
  var copy = document.querySelector('[data-view="voice"] .voice-copy');
  if (copy) {
    var label = copy.querySelector('p');
    if (label) label.textContent = 'Hold to talk';
    var wakeLine = document.createElement('div');
    wakeLine.className = 'voice-wake';
    wakeLine.hidden = true;
    copy.insertBefore(wakeLine, copy.firstChild);
  }

  // ---------- "Hey Jarvis" wake word (SpeechRecognizerService hands-free mode) ----------
  var SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  var wake = null, wakeGen = 0, awaiting = false, lastCmd = '', commitT = 0, restartT = 0, speakingNow = false;
  function wakeOn() { return !!SR && store.get('jarvis.wake') === '1'; }
  function earOn() { return !!(ear && ear.getAttribute('aria-pressed') === 'true'); }
  function canWake() {
    return wakeOn() && H.revealed && H.connected && !speakingNow && !earOn() && H.orbState !== 'listening';
  }
  function showWake() {
    if (typeof wakeLine === 'undefined' || !wakeLine) return;
    wakeLine.hidden = !wake;
    wakeLine.textContent = H.language === 'vi' ? 'Đang nghe "Này Jarvis"...' : 'Listening for "Hey Jarvis"...';
  }
  function afterWake(t) {
    var m = /\bjarvis\b/i.exec(t);
    return m ? t.slice(m.index + m[0].length).replace(/^[\s.,!?;:]+|[\s.,!?;:]+$/g, '') : null;
  }
  function evaluate(t) {
    var cmd = afterWake(t);
    if (cmd === null && !awaiting) return;
    if (cmd === null) cmd = t.replace(/^[\s.,!?;:]+|[\s.,!?;:]+$/g, '');
    if (cmd.length < 3) { awaiting = true; return; }
    if (cmd === lastCmd) return;
    clearTimeout(commitT);
    // The Mac app commits after a 1.4 s pause.
    commitT = setTimeout(function () {
      if (!wake) return;
      awaiting = false; lastCmd = cmd;
      H.sendText(cmd);
      stopWake(); scheduleWake();
    }, 1400);
  }
  function startWake() {
    if (wake || !canWake()) return;
    var mine = ++wakeGen;
    try { wake = new SR(); } catch (e) { wake = null; return; }
    wake.lang = H.language === 'vi' ? 'vi-VN' : 'en-US';
    wake.continuous = true;
    wake.interimResults = true;
    wake.onresult = function (ev) {
      if (mine !== wakeGen) return;
      var t = '';
      for (var i = 0; i < ev.results.length; i++) t += ev.results[i][0].transcript + ' ';
      evaluate(t.trim());
    };
    wake.onerror = function (ev) {
      if (mine !== wakeGen) return;
      if (ev && (ev.error === 'not-allowed' || ev.error === 'service-not-allowed')) {
        store.set('jarvis.wake', '');
        syncWakeBox('Microphone access was blocked, so "Hey Jarvis" is off.');
      }
    };
    wake.onend = function () {
      if (mine !== wakeGen) return;
      wake = null; showWake();
      scheduleWake();
    };
    try { wake.start(); } catch (e) { wake = null; }
    showWake();
  }
  function stopWake() {
    clearTimeout(commitT); clearTimeout(restartT);
    awaiting = false;
    if (!wake) return;
    var w = wake;
    wake = null; wakeGen++;
    try { w.abort ? w.abort() : w.stop(); } catch (e) {}
    showWake();
  }
  function scheduleWake() {
    clearTimeout(restartT);
    restartT = setTimeout(startWake, 350);
  }
  function emitSpeaking(on) {
    speakingNow = on;
    // Mute the wake word while Jarvis talks so it does not hear itself.
    if (on) stopWake(); else scheduleWake();
  }
  H.on('state', function (s) { if (s === 'listening' || s === 'offline' || earOn()) stopWake(); else if (!wake) scheduleWake(); });
  H.on('reveal', scheduleWake);
  H.on('open', scheduleWake);
  H.on('close', stopWake);

  // ---------- Speech & Audio Synthesis settings (SettingsView ttsVoiceCard) ----------
  var box = $('modVoice');
  var loaded = null, el = {};
  function make(tag, cls, text) {
    var n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text) n.textContent = text;
    return n;
  }
  function seg(name, items) {
    var s = make('div', 'seg vx-seg');
    s.setAttribute('role', 'group');
    s.setAttribute('aria-label', name);
    items.forEach(function (it) {
      var b = make('button', '', it[1]);
      b.type = 'button';
      b.setAttribute('data-v', it[0]);
      b.onclick = function () { setSeg(s, it[0]); if (s === el.engine) showEngine(); };
      s.appendChild(b);
    });
    return s;
  }
  function setSeg(s, v) {
    s.value = v;
    Array.prototype.forEach.call(s.children, function (b) {
      var on = b.getAttribute('data-v') === v;
      b.classList.toggle('on', on);
      b.setAttribute('aria-pressed', on ? 'true' : 'false');
    });
  }
  function toggleLine(text, sub, key, def) {
    var l = make('label', 'switchline');
    var span = make('span', '', text);
    if (sub) span.appendChild(make('small', '', sub));
    var i = make('input');
    i.type = 'checkbox';
    i.checked = def ? store.get(key) !== '0' : store.get(key) === '1';
    l.appendChild(span); l.appendChild(i);
    return { line: l, input: i };
  }
  function msg(text, cls) { el.msg.textContent = text || ''; el.msg.className = 'note vx-msg' + (cls ? ' ' + cls : ''); }
  function showEngine() {
    var fish = el.engine.value === 'fish';
    el.kokoro.hidden = fish;
    el.fish.hidden = !fish;
  }
  function syncWakeBox(note) {
    if (el.wake) el.wake.input.checked = wakeOn();
    if (note && el.msg) msg(note, 'bad');
  }
  if (box) {
    var card = make('div', 'card');
    var auto = toggleLine('Auto-play voice responses', '', 'jarvis.autoPlay', true);
    auto.input.onchange = function () { store.set('jarvis.autoPlay', this.checked ? '' : '0'); if (!this.checked) stopPlayback(); };
    card.appendChild(auto.line);
    el.wake = toggleLine('Listen for "Hey Jarvis"', 'Say "Hey Jarvis" and then your command. Uses this browser\'s speech recognition and the microphone.', 'jarvis.wake', false);
    el.wake.input.disabled = !SR;
    el.wake.input.onchange = function () {
      store.set('jarvis.wake', this.checked ? '1' : '');
      if (this.checked) scheduleWake(); else stopWake();
    };
    card.appendChild(el.wake.line);

    el.engine = seg('Voice engine', [['kokoro', 'Kokoro (Local)'], ['fish', 'Fish Audio (Cloud)']]);
    card.appendChild(el.engine);

    el.kokoro = make('div');
    el.voice = seg('Kokoro voice', [['af_heart', 'Heart (F)'], ['af_bella', 'Bella (F)'], ['af_nicole', 'Nicole (F)'], ['am_fenrir', 'Fenrir (M)']]);
    el.kokoro.appendChild(el.voice);
    el.kokoro.appendChild(make('p', 'note', 'Local on-device synthesis. No cloud API key required.'));
    card.appendChild(el.kokoro);

    el.fish = make('div');
    var keyField = make('label', 'field', 'Fish Audio API key');
    el.key = make('input');
    el.key.type = 'password'; el.key.autocomplete = 'off'; el.key.spellcheck = false;
    keyField.appendChild(el.key);
    var refField = make('label', 'field', 'Fish voice reference ID');
    el.ref = make('input');
    el.ref.type = 'text'; el.ref.autocomplete = 'off'; el.ref.spellcheck = false; el.ref.maxLength = 32;
    refField.appendChild(el.ref);
    el.model = seg('Fish model', [['s2.1-pro-free', 's2.1-pro-free'], ['s2.1-pro', 's2.1-pro'], ['s2-pro', 's2-pro'], ['s1', 's1']]);
    el.fish.appendChild(keyField); el.fish.appendChild(refField); el.fish.appendChild(el.model);
    card.appendChild(el.fish);

    var row = make('div', 'row');
    el.test = make('button', 'btn', 'Test Voice');
    el.test.type = 'button';
    row.appendChild(el.test);
    card.appendChild(row);
    el.msg = make('p', 'note vx-msg');
    el.msg.style.margin = '10px 0 0';
    card.appendChild(el.msg);
    box.appendChild(card);

    setSeg(el.engine, 'kokoro'); setSeg(el.voice, 'af_heart'); setSeg(el.model, 's2.1-pro-free');
    showEngine();
    el.test.onclick = testVoice;
  }

  H.on('settings', function (s) {
    if (!box) return;
    loaded = s || {};
    setSeg(el.engine, loaded.tts_engine === 'fish' ? 'fish' : 'kokoro');
    setSeg(el.voice, loaded.kokoro_voice || 'af_heart');
    setSeg(el.model, loaded.fish_model || 's2.1-pro-free');
    el.ref.value = loaded.fish_reference_id || '';
    // The saved key is never sent back; only show that one exists.
    el.key.value = '';
    el.key.placeholder = loaded.fish_api_key_configured ? 'Saved · type to replace' : 'Paste your Fish Audio API key';
    syncWakeBox();
    showEngine();
    msg('');
  });
  H.on('settings:collect', function (body) {
    if (!box || !loaded) return;
    body.tts_engine = el.engine.value;
    body.kokoro_voice = el.voice.value;
    body.fish_model = el.model.value;
    var ref = el.ref.value.trim();
    if (ref) body.fish_reference_id = ref;
    if (el.key.value.trim()) body.fish_api_key = el.key.value.trim();
  });

  // Mac testServerVoice: synthesize with the saved voice, fall back to the local voice.
  function fetchAudio(path, body) {
    // api() parses JSON; wrap fetch for this one synchronous call to keep the raw WAV response.
    var real = window.fetch, res = null;
    window.fetch = function (u, o) { res = real.call(window, u, o); return res.then(function (r) { return r.clone(); }); };
    try { H.api(path, 'POST', body).catch(function () {}); } finally { window.fetch = real; }
    if (!res) return Promise.reject(new Error('No request'));
    return res.then(function (r) {
      if (!r.ok) throw new Error('Request failed (' + r.status + ').');
      return r.status === 204 ? null : r.blob();
    });
  }
  function testVoice() {
    var vi = H.language === 'vi';
    var sample = vi ? 'Đây là giọng nói của Jarvis.' : 'This is Jarvis.';
    el.test.disabled = true;
    msg('Testing…');
    audioCtx();
    fetchAudio('/api/voice/synthesize', { text: sample, language: vi ? 'vi' : 'en' }).then(function (blob) {
      el.test.disabled = false;
      stopPlayback();
      if (blob && blob.size) { enqueue(sample, new Blob([blob], { type: 'audio/wav' })); msg('Playing the server voice.'); }
      else { enqueue(sample); msg('Server returned no audio. Playing this computer\'s voice instead.'); }
    }).catch(function () {
      el.test.disabled = false;
      stopPlayback();
      enqueue(sample);
      msg('Server voice unavailable. Playing this computer\'s voice instead.');
    });
  }

  window.JarvisVoice = { stop: stopPlayback, speak: function (t) { enqueue(t); }, get speaking() { return !!current; } };
})();
