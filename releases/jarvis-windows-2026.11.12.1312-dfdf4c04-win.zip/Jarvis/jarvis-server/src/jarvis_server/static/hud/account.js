// Account module for the Windows HUD: sign-in gate, guest mode, profile & avatar,
// plans and payment, family, referral, admin dashboard, honorific onboarding and
// the sidebar plan capsule. Mirrors the Mac app (AccountViews.swift and friends).
// Never log tokens or bank details.
(function () {
  'use strict';
  var H = window.JarvisHUD;
  if (!H) return;
  var $ = H.$, store = H.store;

  // ---------- helpers ----------
  function h(tag, props, kids) {
    var el = document.createElement(tag);
    for (var k in props || {}) {
      var v = props[k];
      if (v == null || v === false) continue;
      if (k === 'text') el.textContent = v;
      else if (k === 'html') el.innerHTML = v; // static icon markup only, never data
      else if (k === 'class') el.className = v;
      else if (k.slice(0, 2) === 'on') el.addEventListener(k.slice(2), v);
      else if (k === 'value' || k === 'disabled' || k === 'hidden' || k === 'maxLength') el[k] = v;
      else el.setAttribute(k, v === true ? '' : v);
    }
    (kids || []).forEach(function (c) {
      if (c != null && c !== false) el.appendChild(typeof c === 'string' ? document.createTextNode(c) : c);
    });
    return el;
  }
  function btn(text, cls, onclick, extra) {
    var p = { type: 'button', class: 'btn' + (cls ? ' ' + cls : ''), text: text, onclick: onclick };
    for (var k in extra || {}) p[k] = extra[k];
    return h('button', p);
  }
  function svg(body, size, sw) {
    return '<svg width="' + (size || 14) + '" height="' + (size || 14) + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="' + (sw || 1.8) + '" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + body + '</svg>';
  }
  var ICON = {
    copy: '<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V5a1 1 0 0 0-1-1H5a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h3"/>',
    check: '<path d="M5 12l5 5L20 7"/>',
    back: '<path d="M15 6l-6 6 6 6"/>',
    x: '<path d="M6 6l12 12M18 6L6 18"/>',
    warn: '<path d="M12 3l10 18H2z"/><path d="M12 10v5M12 18v.5"/>',
    ok: '<circle cx="12" cy="12" r="9"/><path d="M8 12l3 3 5-6"/>',
    family: '<circle cx="8" cy="8" r="3"/><circle cx="17" cy="9" r="2.5"/><path d="M2.5 19c.8-3.5 3-5 5.5-5s4.7 1.5 5.5 5M14 14.5c.9-.4 1.9-.5 3-.5 2.2 0 3.9 1.3 4.5 4.5"/>',
    gift: '<rect x="3" y="9" width="18" height="12" rx="1.5"/><path d="M12 9v12M3 13h18M12 9C10 5 6 5 6.5 7.5S12 9 12 9zm0 0c2-4 6-4 5.5-1.5S12 9 12 9z"/>',
    seal: '<path d="M12 2l2.4 2 3.1-.3.9 3 2.6 1.8-1.2 2.9 1.2 2.9-2.6 1.8-.9 3-3.1-.3L12 21l-2.4-2-3.1.3-.9-3L3 14.5l1.2-2.9L3 8.7l2.6-1.8.9-3 3.1.3z"/><path d="M8.5 12l2.5 2.5 4.5-5"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    photo: '<rect x="3" y="5" width="18" height="14" rx="2"/><circle cx="9" cy="10" r="2"/><path d="M21 16l-5-5-8 8"/>',
    trash: '<path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13"/>',
    sparkle: '<path d="M12 2.5l1.9 6.6 6.6 1.9-6.6 1.9L12 19.5l-1.9-6.6L3.5 11l6.6-1.9z"/>',
    person: '<circle cx="12" cy="8" r="3.5"/><path d="M5 20c1.2-3.6 4-5.5 7-5.5s5.8 1.9 7 5.5"/>',
    admin: '<circle cx="9" cy="8" r="3"/><path d="M3 19c.8-3.5 3.2-5 6-5 1.3 0 2.4.3 3.4.9"/><circle cx="17.5" cy="16.5" r="2"/><path d="M17.5 12.5v1.5M17.5 19v1.5M21.5 16.5H20M15 16.5h-1.5"/>',
    qr: '<rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><path d="M14 14h3v3h-3zM20 14v.01M14 20h.01M17 20h4v-3"/>',
    google: '<path d="M21 12.2c0-.7-.1-1.3-.2-1.9H12v3.6h5.1a4.4 4.4 0 0 1-1.9 2.9v2.4h3c1.8-1.6 2.8-4 2.8-7z"/><path d="M12 21c2.5 0 4.6-.8 6.2-2.3l-3-2.4c-.8.6-1.9.9-3.2.9-2.4 0-4.5-1.6-5.2-3.9H3.7v2.5A9 9 0 0 0 12 21z"/><path d="M6.8 13.3a5.4 5.4 0 0 1 0-3.4V7.4H3.7a9 9 0 0 0 0 8.1z"/><path d="M12 6.6c1.4 0 2.6.5 3.5 1.4l2.7-2.7A9 9 0 0 0 3.7 7.4l3.1 2.5C7.5 8.1 9.6 6.6 12 6.6z"/>'
  };
  function icon(name, size, sw) { return h('span', { class: 'acc-ic', html: svg(ICON[name], size, sw) }); }
  function money(n) { return Number(n || 0).toLocaleString('vi-VN') + 'đ'; }
  function day(sec) { return sec ? new Date(sec * 1000).toLocaleDateString() : ''; }
  function when(sec) { return new Date(sec * 1000).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' }); }
  function setText(el, t) { if (el && el.textContent !== t) el.textContent = t; }
  function copyText(text) {
    if (navigator.clipboard && window.isSecureContext) return navigator.clipboard.writeText(text).catch(fallback);
    fallback();
    function fallback() {
      var ta = h('textarea', { value: text, style: 'position:fixed;opacity:0' });
      document.body.appendChild(ta); ta.select();
      try { document.execCommand('copy'); } catch (e) {}
      ta.remove();
    }
    return Promise.resolve();
  }
  // A copy button that shows a check for two seconds, like the Mac.
  function copyBtn(value, label) {
    var b = h('button', { type: 'button', class: label ? 'btn acc-copy' : 'acc-iconbtn', 'aria-label': 'Copy' });
    function paint(done) {
      b.textContent = '';
      b.appendChild(icon(done ? 'check' : 'copy', 13));
      if (label) b.appendChild(document.createTextNode(done ? 'Copied' : label));
      b.classList.toggle('done', done);
    }
    paint(false);
    b.onclick = function () { copyText(value).then(function () { paint(true); setTimeout(function () { paint(false); }, 2000); }); };
    return b;
  }
  // Promise-based confirmation sheet; resolves null on cancel, the input text or true on confirm.
  function ask(o) {
    return new Promise(function (resolve) {
      var input = o.input != null ? h('input', { type: 'text', value: o.input, placeholder: o.placeholder || '', maxLength: 200, 'aria-label': o.placeholder || 'Value' }) : null;
      var dlg = h('dialog', { class: 'acc-dlg', 'aria-label': o.title }, [
        h('h3', { text: o.title }),
        o.message ? h('p', { class: 'note', text: o.message }) : null,
        input,
        h('div', { class: 'row end' }, [
          btn('Cancel', '', function () { done(null); }),
          btn(o.confirm, o.danger ? 'danger' : 'primary', function () { done(input ? input.value.trim() : true); }, { 'data-ok': '1' })
        ])
      ]);
      function done(v) { if (dlg.open) dlg.close(); dlg.remove(); resolve(v); }
      dlg.addEventListener('cancel', function (e) { e.preventDefault(); done(null); });
      document.body.appendChild(dlg);
      dlg.showModal();
      (input || dlg.querySelector('[data-ok]')).focus();
    });
  }

  // ---------- styles ----------
  document.head.appendChild(h('style', { text: [
    '.acc-ic{display:inline-flex;flex:none}',
    '.acc .acc-top{display:flex;align-items:center;gap:8px;margin:8px 0 14px}',
    '.acc .acc-top h2{margin:0}',
    '.acc-back{display:inline-flex;align-items:center;gap:2px;color:var(--accent);padding:4px 6px 4px 0;font-weight:550}',
    '.acc h3.sec{font-size:12px;font-weight:650;letter-spacing:.04em;color:var(--secondary);margin:18px 0 6px;text-transform:uppercase}',
    '.acc-av{border-radius:50%;object-fit:cover;flex:none;box-shadow:0 0 0 1px rgba(255,255,255,.12)}',
    '.acc-id{display:flex;align-items:center;gap:16px;min-width:0}',
    '.acc-id>div{min-width:0;display:flex;flex-direction:column;gap:4px}',
    '.acc-id strong{font-size:20px;font-weight:650;overflow-wrap:anywhere}',
    '.acc-id .mail{color:var(--secondary);overflow-wrap:anywhere;user-select:text}',
    '.acc-caps{display:flex;gap:8px;flex-wrap:wrap}',
    '.acc-cap{display:inline-flex;font-size:10.5px;font-weight:800;letter-spacing:.04em;padding:3px 10px;border-radius:99px;background:var(--fill);color:var(--secondary);width:max-content}',
    '.acc-cap.pro{background:rgba(255,159,10,.15);color:#ff9f0a}',
    '.acc-cap.reward{background:rgba(50,215,75,.12);color:var(--ok)}',
    '.acc-cap.admin{background:color-mix(in srgb,var(--accent) 15%,transparent);color:var(--accent)}',
    '.acc-kv{display:flex;justify-content:space-between;align-items:center;gap:12px;padding:7px 0;border-bottom:1px solid var(--line)}',
    '.acc-kv:last-of-type{border-bottom:0}',
    '.acc-kv span:first-child{color:var(--secondary)}',
    '.acc-kv b{font-weight:550;text-align:right;overflow-wrap:anywhere;min-width:0}',
    '.acc-big{font:700 18px var(--mono);overflow-wrap:anywhere}',
    '.acc-label{font-size:10px;font-weight:700;letter-spacing:.06em;color:var(--secondary)}',
    '.acc-split{display:flex;align-items:center;justify-content:space-between;gap:12px}',
    '.acc-split>div{min-width:0}',
    '.acc-copy{display:inline-flex;align-items:center;gap:6px;flex:none}',
    '.acc-copy.done{color:var(--ok)}',
    '.acc-iconbtn{width:26px;height:26px;border-radius:6px;display:inline-flex;align-items:center;justify-content:center;color:var(--secondary);flex:none}',
    '.acc-iconbtn:hover{background:var(--fill)}.acc-iconbtn.done{color:var(--ok)}',
    '.acc-banner{display:flex;align-items:center;gap:10px;padding:12px;border-radius:10px;margin:0 0 14px;font-size:12.5px}',
    '.acc-banner.ok{background:rgba(50,215,75,.12)}.acc-banner.ok .acc-ic{color:var(--ok)}',
    '.acc-banner.bad{background:rgba(255,69,58,.12)}.acc-banner.bad .acc-ic:first-child{color:var(--bad)}',
    '.acc-banner span.t{flex:1;min-width:0;overflow-wrap:anywhere}',
    '.acc-tiers{display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:14px}',
    '.acc-tier{padding:14px;border-radius:14px;border:1px solid var(--line);background:var(--card);display:flex;flex-direction:column;gap:8px}',
    '.acc-tier.pro{border-color:rgba(255,159,10,.35)}',
    '.acc-tier .acc-split b{font-size:15px}.acc-tier.pro .acc-split *{color:#ff9f0a}',
    '.acc-tier strong{font-size:13px}.acc-tier p{margin:0;font-size:11.5px;color:var(--secondary)}',
    '.acc-state{display:flex;align-items:center;gap:12px;padding:14px;border-radius:14px;margin-bottom:14px}',
    '.acc-state strong{display:block;font-size:14px}.acc-state p{margin:2px 0 0;font-size:12px;color:var(--secondary)}',
    '.acc-state.pro{background:rgba(50,215,75,.1);border:1px solid rgba(50,215,75,.3)}.acc-state.pro>.acc-ic{color:var(--ok)}',
    '.acc-state.wait{background:rgba(255,159,10,.1);border:1px solid rgba(255,159,10,.35);flex-wrap:wrap}.acc-state.wait>.acc-ic{color:#ff9f0a}',
    '.acc-state .mono{font:11px var(--mono);color:var(--secondary);overflow-wrap:anywhere}',
    '.acc-pay{padding:18px;border-radius:20px;border:1px solid rgba(217,31,133,.3);background:var(--card);margin-bottom:14px;display:flex;flex-direction:column;gap:14px}',
    '.acc-momo{display:inline-flex;align-items:center;gap:6px;padding:4px 10px;border-radius:99px;background:rgba(217,31,133,.12);color:#d91f85;font-weight:700}',
    '.acc-momo i{width:14px;height:14px;border-radius:50%;background:#d91f85}',
    '.acc-pay .acc-split{flex-wrap:wrap}.acc-pay .net{font:600 12px var(--mono);color:var(--secondary);margin-right:auto}',
    '.acc-pay .amt{font-size:16px;font-weight:700}',
    '.acc-qr{display:flex;flex-direction:column;align-items:center;gap:8px;text-align:center;font-size:11.5px;color:var(--secondary)}',
    '.acc-qr img{width:240px;max-width:100%;border-radius:12px;border:1px solid var(--line);background:#fff}',
    '.acc-qr .ph{width:200px;height:200px;max-width:100%;border-radius:12px;background:var(--fill);display:flex;flex-direction:column;align-items:center;justify-content:center;gap:10px}',
    '.acc-row{display:flex;align-items:center;gap:8px;padding:2px 0;font-size:13px}',
    '.acc-row span{color:var(--secondary);font-size:12px;flex:none;max-width:45%}',
    '.acc-row b{margin-left:auto;font-weight:550;text-align:right;overflow-wrap:anywhere;min-width:0;user-select:text}',
    '.acc-row.hi b{font-family:var(--mono);font-weight:700;color:#ff9f0a}',
    '.acc-pay hr,.acc-sect hr{border:0;border-top:1px solid var(--line);margin:0;width:100%}',
    '.acc-pay .center{text-align:center;font-size:11.5px;color:var(--secondary);margin:0}',
    '.acc-paybtn{width:100%;min-height:44px;border-radius:10px;background:#d91f85;color:#fff;font-weight:650}',
    '.acc-sect{padding:16px;border-radius:16px;border:1px solid var(--line);background:var(--card);margin-bottom:14px;display:flex;flex-direction:column;gap:12px}',
    '.acc-sect.gift{border-color:rgba(50,215,75,.2)}',
    '.acc-sect .hd{display:flex;align-items:center;gap:4px 8px;flex-wrap:wrap;font-size:15px;font-weight:650}',
    '.acc-sect .hd small{margin-left:auto;font:500 11px var(--mono);color:var(--secondary);white-space:nowrap}',
    '.acc-sect .hd .acc-ic{color:var(--accent)}.acc-sect.gift .hd .acc-ic,.acc-sect.gift .hd small{color:var(--ok)}',
    '.acc-sect p{margin:0;font-size:12px;color:var(--secondary)}',
    '.acc-sect .fam{font:700 20px var(--mono);color:var(--accent);overflow-wrap:anywhere}',
    '.acc-bar{height:6px;border-radius:3px;background:var(--fill);overflow:hidden}.acc-bar i{display:block;height:100%;background:var(--accent)}',
    '.acc-member{display:flex;align-items:center;gap:10px;padding:2px 0}',
    '.acc-member>div{min-width:0;flex:1}.acc-member .nm{font-size:12.5px;font-weight:550;display:flex;gap:6px;align-items:center;flex-wrap:wrap}',
    '.acc-member .em{font-size:11px;color:var(--secondary);overflow-wrap:anywhere}',
    '.acc-member .used{font:11px var(--mono);color:var(--tertiary);flex:none}',
    '.acc-owner{font-size:8.5px;font-weight:800;color:#ff9f0a;background:rgba(255,159,10,.12);border-radius:99px;padding:1px 5px}',
    '.acc-join{display:flex;gap:8px}.acc-join input{flex:1;min-width:0;text-transform:uppercase}',
    '.acc-link{color:var(--bad);font-size:12px;align-self:flex-start}',
    '.acc-ok{color:var(--ok);font-size:11.5px;font-weight:550}',
    '.acc-item{padding:10px 0;border-bottom:1px solid var(--line);display:flex;flex-direction:column;gap:6px}',
    '.acc-item:last-child{border-bottom:0}.acc-item strong{font-size:14px;overflow-wrap:anywhere}',
    '.acc-item .sub{color:var(--secondary);overflow-wrap:anywhere}',
    '.acc-item .files{font:11.5px/1.5 var(--mono);white-space:pre-wrap;overflow-wrap:anywhere;color:var(--secondary)}',
    '.acc-item select{width:auto}.acc-bad{color:var(--bad);font-weight:550}',
    '.acc-form label.field input{font-family:var(--sans)}',
    '.acc-msg{color:var(--bad);margin:8px 0;overflow-wrap:anywhere}',
    '.acc-dlg{border:1px solid var(--card-line);border-radius:14px;background:var(--sidebar);color:var(--text);padding:18px;width:min(420px,calc(100% - 32px))}',
    '.acc-dlg::backdrop{background:rgba(0,0,0,.55)}.acc-dlg h3{margin:0 0 8px;font-size:15px}.acc-dlg input{margin:0 0 12px}',
    '.acc-gate{position:fixed;inset:0;z-index:70;background:var(--bg);display:flex;flex-direction:column;align-items:center;justify-content:center;gap:22px;padding:28px 16px;overflow:auto;text-align:center}',
    '.acc-gate>.acc-ic{color:var(--accent)}',
    '.acc-gate h1{margin:0;font-size:30px;font-weight:650}.acc-gate .sub{margin:6px 0 0;font-size:17px;color:var(--secondary)}',
    '.acc-gate .col{display:flex;flex-direction:column;gap:12px;width:min(360px,100%)}',
    '.acc-gate .col .btn{display:inline-flex;align-items:center;justify-content:center;gap:8px;min-height:38px}',
    '.acc-gate .col .btn.primary{min-height:44px}',
    '.acc-gate .fine{font-size:12px;color:var(--secondary);margin:0}',
    '.acc-gate .err{color:var(--bad);margin:0;overflow-wrap:anywhere}',
    '.acc-spin{width:13px;height:13px;border-radius:50%;border:2px solid currentColor;border-right-color:transparent;animation:spin .8s linear infinite;display:inline-block}',
    '.acc-ob{border:0;border-radius:18px;padding:32px 28px 24px;width:min(420px,calc(100% - 32px));max-height:calc(100% - 32px);background:var(--void);color:var(--text);display:flex;flex-direction:column;gap:22px;min-height:min(480px,calc(100% - 32px))}',
    '.acc-ob:not([open]){display:none}.acc-ob::backdrop{background:rgba(0,0,0,.7)}',
    '.acc-ob .kicker{font:800 13px var(--mono);letter-spacing:3.2px;color:var(--accent);text-align:center}',
    '.acc-ob h2{margin:6px 0 0;font-size:22px;font-weight:600;text-align:center}',
    '.acc-ob .seg{width:100%;display:flex}.acc-ob .seg button{flex:1;justify-content:center;min-height:34px}',
    '.acc-ob .go{margin-top:auto;height:52px;border-radius:14px;background:var(--accent);color:#02050a;font:700 13px var(--mono);letter-spacing:3px}',
    '.acc-prof{display:flex;align-items:center;gap:16px;flex-wrap:wrap}',
    '.acc-prof .acc-av{box-shadow:0 0 12px color-mix(in srgb,var(--accent) 35%,transparent)}',
    '.acc-prof>div{flex:1;min-width:160px}.acc-prof strong{display:block;font-size:14px}.acc-prof small{color:var(--secondary)}',
    '.acc-prof .btn{display:inline-flex;align-items:center;gap:6px}',
    '.acc-presets{display:flex;gap:12px;overflow-x:auto;padding:4px 2px 6px}',
    '.acc-preset{width:44px;height:44px;border-radius:50%;background:var(--fill);border:2px solid transparent;color:var(--secondary);display:inline-flex;align-items:center;justify-content:center;flex:none}',
    '.acc-preset.on{background:color-mix(in srgb,var(--accent) 20%,transparent);border-color:var(--accent);color:var(--accent)}',
    '@media (max-width:560px){.acc-tiers{grid-template-columns:1fr}.acc-gate h1{font-size:26px}}'
  ].join('\n') }));

  // ---------- avatar (local only, like the Mac's UserCustomizationStore) ----------
  var AV_CUSTOM = 'jarvis.avatar.custom', AV_SYMBOL = 'jarvis.avatar.symbol';
  var PRESETS = {
    person: ICON.person,
    head: '<path d="M14.5 20v-3h2a2 2 0 0 0 2-2v-2.5l1.5-.8-1.6-3.2A7 7 0 0 0 5 9.5c0 2.3 1 4 3 5.3V20"/><path d="M10 9.5a2 2 0 0 1 3-1.6"/>',
    sparkles: '<path d="M10 3l1.7 5.3L17 10l-5.3 1.7L10 17l-1.7-5.3L3 10l5.3-1.7z"/><path d="M18 14l.8 2.2L21 17l-2.2.8L18 20l-.8-2.2L15 17l2.2-.8z"/>',
    bolt: '<circle cx="12" cy="12" r="9"/><path d="M13 6l-4 7h3l-1 5 4-7h-3z"/>',
    atom: '<circle cx="12" cy="12" r="1.4"/><ellipse cx="12" cy="12" rx="9.5" ry="3.6"/><ellipse cx="12" cy="12" rx="9.5" ry="3.6" transform="rotate(60 12 12)"/><ellipse cx="12" cy="12" rx="9.5" ry="3.6" transform="rotate(120 12 12)"/>',
    star: '<circle cx="12" cy="12" r="9"/><path d="M12 6.8l1.6 3.3 3.6.5-2.6 2.5.6 3.6-3.2-1.7-3.2 1.7.6-3.6-2.6-2.5 3.6-.5z"/>',
    crown: '<path d="M4 19h16M5 16L4 7l5 4 3-6 3 6 5-4-1 9z"/>',
    shield: '<path d="M12 3l7 3v5c0 4.5-3 8.3-7 10-4-1.7-7-5.5-7-10V6z"/>',
    flame: '<path d="M12 3c1 4 5 5.5 5 10a5 5 0 0 1-10 0c0-2.5 1.5-4 2.5-5 .3 2 1.5 3 2.5 3-1-3 0-6 0-8z"/>',
    globe: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3 3.5 3 14.5 0 18M12 3c-3 3.5-3 14.5 0 18"/>'
  };
  function accent() { return getComputedStyle(document.documentElement).getPropertyValue('--accent').trim() || '#00c7f2'; }
  function avatarSrc() {
    var custom = store.get(AV_CUSTOM);
    if (/^data:image\/(jpeg|png);base64,/.test(custom)) return custom;
    var sym = PRESETS[store.get(AV_SYMBOL)] ? store.get(AV_SYMBOL) : 'person', c = accent();
    return 'data:image/svg+xml,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48"><rect width="48" height="48" fill="#16181c"/>' +
      '<circle cx="24" cy="24" r="23.5" fill="' + c + '" fill-opacity=".2" stroke="' + c + '" stroke-opacity=".4"/>' +
      '<g transform="translate(11.5 11.5) scale(1.04)" fill="none" stroke="' + c + '" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">' + PRESETS[sym] + '</g></svg>');
  }
  function avatar(size) { return h('img', { class: 'acc-av', alt: '', width: size, height: size, src: avatarSrc(), 'data-acc-av': '1' }); }
  function paintAvatars() {
    var src = avatarSrc();
    document.querySelectorAll('#profile .avatar,[data-acc-av]').forEach(function (img) { if (img.getAttribute('src') !== src) img.src = src; });
  }
  // Downscale to a 160px square JPEG so the data URL stays small in local storage.
  function setPhoto(file, done) {
    if (!file || !/^image\//.test(file.type)) return done('Choose an image file.');
    if (file.size > 20 * 1024 * 1024) return done('That image is too large.');
    var url = URL.createObjectURL(file), img = new Image();
    img.onload = function () {
      var s = 160, cv = h('canvas'), m = Math.min(img.naturalWidth, img.naturalHeight);
      cv.width = cv.height = s;
      cv.getContext('2d').drawImage(img, (img.naturalWidth - m) / 2, (img.naturalHeight - m) / 2, m, m, 0, 0, s, s);
      URL.revokeObjectURL(url);
      store.set(AV_CUSTOM, cv.toDataURL('image/jpeg', 0.85));
      done('');
    };
    img.onerror = function () { URL.revokeObjectURL(url); done('Could not read that image.'); };
    img.src = url;
  }

  // ---------- Settings > General: Profile & Avatar ----------
  var profileMsg = '';
  function renderProfileCard() {
    var root = $('modProfile');
    if (!root) return;
    var custom = !!store.get(AV_CUSTOM), u = H.user;
    var file = h('input', { type: 'file', accept: 'image/png,image/jpeg,image/webp,image/gif', hidden: true, 'aria-label': 'Choose photo' });
    file.onchange = function () {
      setPhoto(file.files[0], function (err) { profileMsg = err; renderProfileCard(); paintAvatars(); });
    };
    var presets = h('div', { class: 'acc-presets', role: 'group', 'aria-label': 'Preset symbols' });
    Object.keys(PRESETS).forEach(function (k) {
      var on = !custom && (store.get(AV_SYMBOL) || 'person') === k;
      presets.appendChild(h('button', { type: 'button', class: 'acc-preset' + (on ? ' on' : ''), 'aria-label': 'Symbol ' + k, 'aria-pressed': on ? 'true' : 'false', html: svg(PRESETS[k], 20, 1.7),
        onclick: function () { store.set(AV_CUSTOM, ''); store.set(AV_SYMBOL, k); profileMsg = ''; renderProfileCard(); paintAvatars(); } }));
    });
    var pick = h('button', { type: 'button', class: 'btn', onclick: function () { file.click(); } }, [icon('photo', 14), 'Choose Photo…']);
    var reset = custom ? h('button', { type: 'button', class: 'btn danger', 'aria-label': 'Reset to symbol', title: 'Reset to Symbol',
      onclick: function () { store.set(AV_CUSTOM, ''); renderProfileCard(); paintAvatars(); } }, [icon('trash', 14)]) : null;
    root.replaceChildren(
      h('h3', { text: 'Profile & Avatar' }),
      h('div', { class: 'card' }, [
        h('div', { class: 'acc-prof' }, [
          avatar(56),
          h('div', null, [
            h('strong', { text: custom ? 'Custom Photo' : 'Symbol Preset' }),
            h('small', { text: (u ? (u.name || u.email) + ' · ' : '') + 'Select a symbol preset below or upload a custom image. Saved on this PC only.' })
          ]),
          pick, reset, file
        ]),
        profileMsg ? h('p', { class: 'note bad', text: profileMsg }) : null,
        h('hr', { style: 'border:0;border-top:1px solid var(--line);margin:12px 0' }),
        h('div', { class: 'acc-label', text: 'PRESET SYMBOLS', style: 'font-family:var(--mono);margin-bottom:6px' }),
        presets
      ])
    );
  }

  // ---------- Google sign-in (same flow as the Mac AccountSession) ----------
  var GUEST = 'jarvis.guestChosen';
  var guest = store.get(GUEST) === '1';
  var signin = { busy: false, timer: 0, msg: '', run: 0 };
  function signIn() {
    if (signin.busy) return;
    var run = ++signin.run;
    signin.busy = true; signin.msg = ''; repaint();
    H.api('/api/auth/google/start').then(function (r) {
      if (run !== signin.run) return;
      var u = null;
      try { u = new URL(r.auth_url); } catch (e) {}
      // Sign-in goes through the Supabase project, which forwards to Google.
      if (!u || u.protocol !== 'https:' || !(u.hostname === 'accounts.google.com' || /\.supabase\.co$/.test(u.hostname))) throw new Error('Google sign-in returned an unexpected address.');
      window.open(u.href, '_blank', 'noopener');
      var tries = 0;
      signin.timer = setInterval(function () {
        if (++tries > 120) { stopSignIn('Sign-in timed out. Please try again.'); return; }
        H.api('/api/auth/google/status?state=' + encodeURIComponent(r.state)).then(function (st) {
          if (run !== signin.run || !st.done) return;
          if (!st.token) { stopSignIn('Google sign-in did not finish. Please try again.'); return; }
          stopSignIn('');
          signedInWith(st.token);
        }).catch(function () {});
      }, 2000);
    }).catch(function (e) { if (run === signin.run) stopSignIn(e.message); });
  }
  function stopSignIn(msg) { clearInterval(signin.timer); signin.run++; signin.busy = false; signin.msg = msg; repaint(); }
  function signedInWith(token) {
    guest = false; store.set(GUEST, '');
    H.setUserToken(token);
    checkGate();
  }
  function syncFromThisPC() {
    signin.msg = ''; signin.syncing = true; repaint();
    H.api('/api/auth/paired_session').then(function (r) {
      if (r.has_user && r.token) signedInWith(r.token);
      else signin.msg = 'No Google account found on this PC yet. Choose Continue with Google.';
    }).catch(function () { signin.msg = 'No Google account found on this PC yet. Choose Continue with Google.'; })
      .then(function () { signin.syncing = false; repaint(); });
  }
  function signOut() {
    ask({ title: 'Sign out of Jarvis?', confirm: 'Sign out', danger: true }).then(function (ok) {
      if (!ok) return;
      H.api('/api/auth/logout', 'POST', {}).then(function () { signin.msg = ''; })
        .catch(function () { signin.msg = 'Signed out on this device. Server revocation failed; reconnect to revoke the session.'; })
        .then(function () {
          guest = false; store.set(GUEST, '');
          H.setUserToken('');
          H.go('assistant');
          checkGate();
        });
    });
  }
  function signInButton(label) {
    return h('button', { type: 'button', class: 'btn primary', disabled: signin.busy, onclick: signIn },
      signin.busy ? [h('span', { class: 'acc-spin' }), 'Opening Google Sign-In…'] : [label]);
  }

  // ---------- sign-in gate (GoogleSignInView) ----------
  var gate = null, bootOk = null;
  function bootFailed() { return bootOk === false || $('btnSend').disabled; }
  function renderGate() {
    if (!gate) return;
    gate.replaceChildren(
      icon('sparkle', 56, 1.2),
      h('div', null, [h('h1', { text: 'Welcome to Jarvis' }), h('p', { class: 'sub', text: 'Your autonomous assistant. Your workspace.' })]),
      h('div', { class: 'col' }, [
        signInButton('Continue with Google'),
        signin.busy ? btn('Cancel sign-in', '', function () { stopSignIn('Sign-in cancelled.'); }) : null,
        h('button', { type: 'button', class: 'btn', disabled: signin.busy || signin.syncing, onclick: syncFromThisPC },
          [signin.syncing ? h('span', { class: 'acc-spin' }) : icon('person', 15), signin.syncing ? 'Checking this PC…' : 'Use the Account Signed In on This PC']),
        h('button', { type: 'button', class: 'btn', disabled: signin.busy, onclick: function () {
          guest = true; store.set(GUEST, '1'); signin.msg = ''; checkGate();
        } }, [icon('person', 15), 'Continue as Guest (Local Mode)']),
        h('p', { class: 'fine', text: 'Free includes 30 requests each calendar month. Pro has unlimited requests and 5-member family sharing.' }),
        signin.msg ? h('p', { class: 'err', role: 'alert', text: signin.msg }) : null
      ]),
      h('p', { class: 'fine', text: 'Google handles sign-in in your browser. Jarvis never asks for your Google password.' })
    );
  }
  function checkGate() {
    var need = H.revealed && !bootFailed() && !H.signedIn && !guest;
    if (need && !gate) {
      gate = h('div', { class: 'acc-gate', id: 'accGate', role: 'dialog', 'aria-modal': 'true', 'aria-label': 'Sign in to Jarvis' });
      document.body.appendChild(gate);
      renderGate();
      var first = gate.querySelector('button'); if (first) first.focus();
    } else if (!need && gate) { gate.remove(); gate = null; }
    syncChrome();
    if (!need) maybeOnboard();
  }

  // ---------- first-launch honorific onboarding (HonorificOnboardingView) ----------
  var ONBOARDED = 'jarvis.honorificOnboarded';
  // A first launch is one that starts without a saved account session, so returning users are not interrupted.
  var firstRun = !H.signedIn && !store.get(ONBOARDED);
  function maybeOnboard() {
    if (!firstRun || store.get(ONBOARDED) || !H.revealed || bootFailed() || $('accOnboard')) return;
    var choice = 'Sir';
    var custom = h('input', { type: 'text', maxLength: 32, placeholder: 'Your title or name', 'aria-label': 'Your title or name', hidden: true });
    var go = h('button', { type: 'button', class: 'go', text: 'BEGIN' });
    var seg = h('div', { class: 'seg', role: 'group', 'aria-label': 'Honorific' });
    [['Sir', 'Sir'], ["Ma'am", "Ma'am"], ['Custom', 'Custom…']].forEach(function (o) {
      seg.appendChild(h('button', { type: 'button', 'data-ob': o[0], text: o[1], onclick: function () { choice = o[0]; paint(); if (choice === 'Custom') custom.focus(); } }));
    });
    function value() { return choice === 'Custom' ? custom.value.trim() : choice; }
    function paint() {
      seg.querySelectorAll('button').forEach(function (b) { b.classList.toggle('on', b.getAttribute('data-ob') === choice); b.setAttribute('aria-pressed', b.classList.contains('on') ? 'true' : 'false'); });
      custom.hidden = choice !== 'Custom';
      go.disabled = !value();
    }
    custom.oninput = paint;
    var dlg = h('dialog', { class: 'acc-ob', id: 'accOnboard', 'aria-labelledby': 'accObTitle' }, [
      h('div', null, [h('div', { class: 'kicker', text: 'WELCOME TO JARVIS' }), h('h2', { id: 'accObTitle', text: 'How should I address you?' })]),
      seg, custom, go
    ]);
    go.onclick = function () {
      var name = value();
      if (!name) return;
      go.disabled = true;
      store.set(ONBOARDED, '1');
      store.set('jarvis.honorific', name);
      H.api('/api/settings', 'PUT', { honorific: name }).catch(function () {});
      dlg.close(); dlg.remove();
    };
    dlg.addEventListener('cancel', function (e) { e.preventDefault(); }); // Like the Mac sheet: choose, then Begin.
    document.body.appendChild(dlg);
    paint();
    dlg.showModal();
    seg.querySelector('.on').focus();
  }

  // ---------- sidebar: plan capsule, avatar and Admin row ----------
  var adminRow = h('button', { type: 'button', class: 'navbtn', id: 'accAdminNav', hidden: true, html: svg(ICON.admin, 16, 1.7) + 'Admin',
    onclick: function () { nextPage = 'admin'; H.go('account'); } });
  var settingsNav = document.querySelector('.side-scroll .navbtn[data-go="settings"]');
  if (settingsNav) settingsNav.after(adminRow);
  function syncChrome() {
    var u = H.user, badge = $('acctPlan');
    paintAvatars();
    adminRow.hidden = !(u && u.is_admin);
    if (!u) {
      // Mac: "Local Host" with a THIS MAC capsule when nobody is signed in.
      setText($('acctName'), H.signedIn ? 'Signing in…' : 'Local Host');
      if (badge.hidden) badge.hidden = false;
      setText(badge, 'THIS PC');
      if (badge.className !== 'badge') badge.className = 'badge';
    }
    var onAdmin = H.destination === 'account' && page === 'admin';
    adminRow.classList.toggle('on', onAdmin);
    $('profile').classList.toggle('on', H.destination === 'account' && !onAdmin);
  }
  // hud.html re-renders the footer whenever the account changes; follow it.
  var lastUser = '';
  new MutationObserver(function () {
    syncChrome();
    var sig = JSON.stringify(H.user || null);
    if (sig !== lastUser) {
      lastUser = sig;
      if (!H.signedIn) checkGate();
      if (H.destination === 'account') renderPage();
      if (H.destination === 'settings') renderProfileCard();
    }
  }).observe($('profile'), { subtree: true, childList: true, characterData: true, attributes: true, attributeFilter: ['hidden', 'class'] });

  // ---------- account view: Account, Plans & Payment, Admin ----------
  var page = 'account', nextPage = null;
  var P = { info: null, family: null, referral: null, ok: '', err: '', busy: false, join: '', invite: '', qr: false };
  var A = { data: null, bank: null, amount: '', msg: '', busy: false, timer: 0, sig: '' };
  var basic = $('acctBasic');
  if (basic) basic.hidden = true; // replaced by this module

  function top(title) {
    var kids = [];
    if (page !== 'account') kids.push(h('button', { type: 'button', class: 'acc-back', onclick: function () { show('account'); } }, [icon('back', 16, 2.2), 'Account']));
    kids.push(h('h2', { text: title }));
    return h('div', { class: 'acc-top' }, kids);
  }
  function kv(label, value) { return h('div', { class: 'acc-kv' }, [h('span', { text: label }), h('b', { text: value })]); }
  function banner(text, isError, clear) {
    return h('div', { class: 'acc-banner ' + (isError ? 'bad' : 'ok'), role: isError ? 'alert' : 'status' }, [
      icon(isError ? 'warn' : 'ok', 16), h('span', { class: 't', text: text }),
      h('button', { type: 'button', class: 'acc-iconbtn', 'aria-label': 'Dismiss', html: svg(ICON.x, 11, 2), onclick: clear })
    ]);
  }
  function show(p) {
    page = p;
    if (p === 'plans') loadPlans();
    if (p === 'admin') loadAdmin(true);
    renderPage();
    syncChrome();
    var sc = document.querySelector('[data-view="account"]'); if (sc) sc.scrollTop = 0;
  }
  function renderPage() {
    var root = $('modAccount');
    if (!root) return;
    var sheet = h('div', { class: 'sheet acc' });
    if (page === 'plans') buildPlans(sheet);
    else if (page === 'admin') buildAdmin(sheet);
    else buildAccount(sheet);
    root.replaceChildren(sheet);
    paintAvatars();
  }

  // Account (AccountProfileView)
  function buildAccount(s) {
    var u = H.user;
    s.appendChild(top('Account'));
    if (!u) {
      s.appendChild(h('h3', { class: 'sec', text: 'Local host' }));
      s.appendChild(h('div', { class: 'card' }, [
        h('p', { class: 'note', text: H.signedIn ? 'Loading your account…' : 'You’re using this PC without an account. Sign in to view your profile, plans, and payment status.' }),
        H.signedIn ? null : h('div', { class: 'row' }, [signInButton('Sign in with Google'),
          signin.busy ? btn('Cancel sign-in', '', function () { stopSignIn('Sign-in cancelled.'); }) : null])
      ]));
      if (signin.msg) s.appendChild(h('p', { class: 'acc-msg', role: 'alert', text: signin.msg }));
      return;
    }
    var pro = u.plan === 'pro', now = Date.now() / 1000, reward = u.pro_until && u.pro_until > now;
    s.appendChild(h('div', { class: 'card' }, [h('div', { class: 'acc-id' }, [
      avatar(52),
      h('div', null, [
        h('strong', { text: u.name || 'Jarvis user' }),
        h('span', { class: 'mail', text: u.email || '' }),
        h('div', { class: 'acc-caps' }, [
          h('span', { class: 'acc-cap' + (pro ? ' pro' : ''), text: String(u.plan || 'free').toUpperCase() }),
          reward ? h('span', { class: 'acc-cap reward', text: 'Reward Pro' }) : null,
          u.is_admin ? h('span', { class: 'acc-cap admin', text: 'ADMIN' }) : null
        ])
      ])
    ])]));
    s.appendChild(h('h3', { class: 'sec', text: 'Your Plan & Quotas' }));
    s.appendChild(h('div', { class: 'card' }, [
      kv('Active Plan', pro ? 'Pro (Unlimited)' : 'Free Plan'),
      kv('Requests Remaining', u.quota_remaining == null ? 'Unlimited' : String(u.quota_remaining)),
      u.cloud_remaining == null ? null : kv('Cloud Messages Left', String(u.cloud_remaining)),
      reward ? kv('Pro Reward Expires', when(u.pro_until)) : null,
      h('p', { class: 'note', style: 'margin:10px 0', text: 'Free plan resets on the 1st of each calendar month (UTC). Pro members get unlimited requests and family sharing.' }),
      h('div', { class: 'row' }, [
        btn('View Plans, Family & Payment', 'primary', function () { show('plans'); }),
        btn('Refresh Account Status', '', function () { H.refreshAccount(); }),
        u.is_admin ? btn('Admin Dashboard', '', function () { show('admin'); }) : null
      ])
    ]));
    if (u.referral_code) {
      s.appendChild(h('h3', { class: 'sec', text: 'Your Invite Code' }));
      s.appendChild(h('div', { class: 'card' }, [
        h('div', { class: 'acc-split' }, [h('span', { class: 'acc-big', text: u.referral_code }), copyBtn(u.referral_code, 'Copy')]),
        h('p', { class: 'note', style: 'margin:8px 0 0', text: 'Share your code with friends. For every friend who joins, you get 1 week of Pro free!' })
      ]));
    }
    s.appendChild(h('div', { class: 'card' }, [btn('Sign out', 'danger', signOut)]));
    if (signin.msg) s.appendChild(h('p', { class: 'acc-msg', role: 'alert', text: signin.msg }));
  }

  // Plans, payment, family and invites (PlansView)
  function loadPlans() {
    if (!H.user) return Promise.resolve();
    P.busy = true;
    return Promise.all([H.api('/api/billing/info'), H.api('/api/family'), H.api('/api/referral')]).then(function (r) {
      P.info = r[0]; P.family = r[1]; P.referral = r[2];
      H.refreshAccount();
    }).catch(function (e) { P.err = e.message; }).then(function () { P.busy = false; if (page === 'plans') renderPage(); });
  }
  function act(path, body, ok) {
    P.busy = true; P.err = ''; P.ok = ''; renderPage();
    return H.api(path, 'POST', body || {}).then(function (res) {
      P.ok = typeof ok === 'function' ? ok(res) : ok;
      return loadPlans();
    }).catch(function (e) { P.err = e.message; P.busy = false; renderPage(); });
  }
  function bankOk(b) { return !!(b && b.bank_name && b.account_number && b.account_name); }
  function buildPlans(s) {
    var u = H.user;
    s.appendChild(top('Plans & Payment'));
    if (P.ok) s.appendChild(banner(P.ok, false, function () { P.ok = ''; renderPage(); }));
    if (P.err) s.appendChild(banner(P.err, true, function () { P.err = ''; renderPage(); }));
    var price = P.info && P.info.bank ? P.info.bank.amount_vnd : 300000;
    s.appendChild(h('div', { class: 'acc-tiers' }, [
      h('div', { class: 'acc-tier' }, [h('div', { class: 'acc-split' }, [h('span', { class: 'acc-label', text: 'FREE' }), h('b', { text: '0đ' })]),
        h('strong', { text: '30 requests / month' }), h('p', { text: 'Standard Claude / local agent, web search, system telemetry.' })]),
      h('div', { class: 'acc-tier pro' }, [h('div', { class: 'acc-split' }, [h('span', { class: 'acc-label', text: 'PRO & FAMILY' }), h('b', { text: money(price) })]),
        h('strong', { text: 'Unlimited Requests' }), h('p', { text: 'Invite up to 5 family members (3,000 tasks/mo pool). Pro owner gets unlimited tasks.' })])
    ]));
    if (!u) {
      s.appendChild(h('div', { class: 'card', style: 'text-align:center' }, [h('p', { class: 'note', style: 'margin:6px 0', text: 'Sign in with Google to view payment cards, family sharing, and invite rewards.' })]));
      return;
    }
    if (!P.info) { s.appendChild(h('p', { class: 'note', text: P.busy ? 'Loading plans…' : '' })); return; }
    if (u.plan === 'pro' || P.info.my_plan === 'pro') {
      s.appendChild(h('div', { class: 'acc-state pro' }, [icon('seal', 24), h('div', null, [h('strong', { text: 'Pro Subscription Active' }),
        h('p', { text: 'You have unlimited requests, high-priority models, and family sharing.' })])]));
    } else if (P.info.pending) {
      s.appendChild(h('div', { class: 'acc-state wait' }, [icon('clock', 22), h('div', null, [h('strong', { text: 'Payment Awaiting Admin Approval' }),
        h('div', { class: 'mono', text: 'Transaction: ' + P.info.pending.id })]),
        h('p', { style: 'flex-basis:100%', text: 'Your bank transfer claim was submitted. The owner will verify the funds and approve your Pro upgrade. Your Free quota remains active.' })]));
    } else s.appendChild(payCard(P.info.bank || {}));
    s.appendChild(familyCard(u));
    s.appendChild(inviteCard(u));
  }
  function payRow(label, value, hi) {
    return h('div', { class: 'acc-row' + (hi ? ' hi' : '') }, [h('span', { text: label }), h('b', { text: value }), copyBtn(value)]);
  }
  function qrUrl(b) {
    // Fetched from VietQR only after the viewer asks, like the Mac app.
    if (!/^\d{6}$/.test(b.bank_bin || '') || !/^[0-9A-Za-z]{4,32}$/.test(b.account_number || '')) return '';
    return 'https://img.vietqr.io/image/' + b.bank_bin + '-' + b.account_number + '-compact2.png?amount=' + encodeURIComponent(b.amount_vnd) +
      '&addInfo=' + encodeURIComponent(b.transfer_note || '') + '&accountName=' + encodeURIComponent(b.account_name || '');
  }
  function payCard(b) {
    var ready = bankOk(b), url = ready ? qrUrl(b) : '';
    var qr = P.qr && url ? h('img', { src: url, alt: 'VietQR payment code', referrerpolicy: 'no-referrer' })
      : h('div', { class: 'ph' }, [icon('qr', 48, 1.4), url ? btn('Show QR code', '', function () { P.qr = true; renderPage(); }) : h('span', { text: 'VietQR Code' })]);
    return h('div', { class: 'acc-pay' }, [
      h('div', { class: 'acc-split' }, [h('span', { class: 'acc-momo' }, [h('i'), 'MoMo']), h('span', { class: 'net', text: 'VietQR · Napas 247' }), h('span', { class: 'amt', text: money(b.amount_vnd) })]),
      h('div', { class: 'acc-qr' }, [qr, h('span', { text: 'Quét mã để thanh toán qua MoMo hoặc Ngân hàng' })]),
      h('hr'),
      ready ? h('div', null, [
        payRow('Chủ tài khoản', b.account_name), payRow('Số tài khoản', b.account_number), payRow('Ngân hàng', b.bank_name),
        payRow('Số tiền', Number(b.amount_vnd || 0).toLocaleString('vi-VN') + ' VND'), payRow('Nội dung chuyển khoản', b.transfer_note || '', true)
      ]) : h('p', { class: 'note', text: 'Payment details are not set up yet. Try again later.' }),
      h('p', { class: 'center', text: '⚠️ Vui lòng giữ đúng nội dung chuyển khoản để admin duyệt kích hoạt Pro cho bạn.' }),
      h('button', { type: 'button', class: 'acc-paybtn', disabled: P.busy || !ready, onclick: function () {
        ask({ title: 'Confirm transfer sent', confirm: 'Submit for manual verification',
          message: 'This places your Pro upgrade on hold until the owner manually verifies the bank transfer. Your Free plan stays active.' })
          .then(function (ok) { if (ok) act('/api/billing/claim', {}, function (r) { return r.message || 'Received.'; }); });
      } }, [P.busy ? h('span', { class: 'acc-spin' }) : null, ' Tiếp tục — Tôi đã chuyển khoản'])
    ]);
  }
  function familyCard(u) {
    var st = P.family || {}, fam = st.family, kids = [h('div', { class: 'hd' }, [icon('family', 18), 'Family Group Sharing', h('small', { text: '3,000 tasks / mo' })])];
    if (fam) {
      var total = fam.monthly_pool_total || 3000, used = fam.monthly_pool_used || 0;
      kids.push(h('div', { class: 'acc-split' }, [h('div', null, [h('div', { class: 'acc-label', text: 'FAMILY CODE' }), h('div', { class: 'fam', text: fam.code })]), copyBtn(fam.code, 'Copy Code')]));
      kids.push(h('div', null, [
        h('div', { class: 'acc-split', style: 'font-size:12px;margin-bottom:4px' }, [h('span', { text: 'Monthly Task Pool' }), h('b', { style: 'font-family:var(--mono)', text: used + ' / ' + total + ' tasks' })]),
        h('div', { class: 'acc-bar', role: 'progressbar', 'aria-valuemin': 0, 'aria-valuemax': total, 'aria-valuenow': used }, [h('i', { style: 'width:' + Math.min(100, used / total * 100) + '%' })]),
        h('p', { style: 'margin-top:4px;font-size:11px', text: fam.monthly_pool_remaining + ' tasks remaining for family members this month' })
      ]));
      kids.push(h('hr'));
      kids.push(h('div', { class: 'acc-split', style: 'font-size:12px' }, [h('b', { text: 'Members (' + fam.member_count + '/' + fam.max_seats + ' Google accounts)' }),
        h('span', { style: 'font-size:10px;color:var(--tertiary)', text: 'Phone/PC on same account = 1' })]));
      (fam.members || []).forEach(function (m) {
        var owner = m.user_id === fam.owner_id;
        kids.push(h('div', { class: 'acc-member' }, [
          h('span', { class: 'acc-ic', style: 'color:var(--secondary)', html: svg(ICON.person, 24, 1.5) }),
          h('div', null, [h('div', { class: 'nm' }, [m.name || 'Family Member', owner ? h('span', { class: 'acc-owner', text: 'OWNER' }) : null]), h('div', { class: 'em', text: m.email || '' })]),
          h('span', { class: 'used', text: (m.tasks_used || 0) + ' used' }),
          st.is_owner && !owner ? h('button', { type: 'button', class: 'acc-iconbtn', style: 'color:var(--bad)', 'aria-label': 'Remove ' + (m.name || m.email || 'member'), html: svg('<circle cx="12" cy="12" r="9"/><path d="M9 9l6 6M15 9l-6 6"/>', 16),
            onclick: function () {
              ask({ title: 'Remove ' + (m.name || m.email || 'this member') + '?', message: 'They return to the Free plan (30 requests/month).', confirm: 'Remove Member', danger: true })
                .then(function (ok) { if (ok) act('/api/family/remove_member', { user_id: m.user_id }, 'Member removed.'); });
            } }) : null
        ]));
      });
      kids.push(st.is_owner
        ? h('button', { type: 'button', class: 'acc-link', text: 'Disband Family Group', onclick: function () {
          ask({ title: 'Disband Family?', message: 'All family members will lose access to the shared 3,000 monthly task pool.', confirm: 'Disband Family Group', danger: true })
            .then(function (ok) { if (ok) act('/api/family/leave', {}, 'Family group disbanded.'); });
        } })
        : h('button', { type: 'button', class: 'acc-link', text: 'Leave Family', onclick: function () {
          ask({ title: 'Leave Family?', message: 'You will return to the Free plan (30 requests/month).', confirm: 'Leave Family', danger: true })
            .then(function (ok) { if (ok) act('/api/family/leave', {}, 'You have left the family group.'); });
        } }));
    } else if (u.plan === 'pro') {
      kids.push(h('p', { text: 'As a Pro member, you can invite up to 5 family members (Google accounts). Family members share 3,000 tasks/month while you retain unlimited usage.' }));
      kids.push(h('button', { type: 'button', class: 'btn primary', style: 'min-height:38px', disabled: P.busy, onclick: function () {
        act('/api/family/create', {}, 'Family group created! Share your code with up to 5 members.');
      } }, [P.busy ? h('span', { class: 'acc-spin' }) : null, ' Create Family & Share Code']));
    } else {
      kids.push(h('p', { text: 'Have a family code from a Pro member? Join their family group to share their 3,000 monthly tasks pool.' }));
      kids.push(codeForm('FAM-XXXX', 'join', 'Join Family', 'primary', function (code) {
        act('/api/family/join', { code: code }, 'Joined family! You now share the 3,000 monthly task pool.').then(function () { if (!P.err) P.join = ''; renderPage(); });
      }));
    }
    return h('div', { class: 'acc-sect' }, kids);
  }
  function codeForm(placeholder, key, label, cls, run) {
    var input = h('input', { type: 'text', value: P[key], placeholder: placeholder, 'aria-label': placeholder, maxLength: 32, autocomplete: 'off' });
    var go = btn(label, cls, function () { var c = input.value.trim().toUpperCase(); if (c) run(c); }, { disabled: !P[key].trim() || P.busy });
    input.oninput = function () { P[key] = input.value; go.disabled = !input.value.trim() || P.busy; };
    input.onkeydown = function (e) { if (e.key === 'Enter') { e.preventDefault(); go.click(); } };
    return h('div', { class: 'acc-join' }, [input, go]);
  }
  function inviteCard(u) {
    var code = (P.referral && P.referral.referral_code) || u.referral_code || '', n = (P.referral && P.referral.invited_count) || 0;
    return h('div', { class: 'acc-sect gift' }, [
      h('div', { class: 'hd' }, [icon('gift', 18), 'Invite Rewards — Earn 1 Week Pro', h('small', { style: 'font-weight:700', text: '+7 days Pro' })]),
      h('p', { text: 'For every friend who joins with your referral code, you earn 1 full week of Pro for free!' }),
      code ? h('div', { class: 'acc-split' }, [h('div', null, [h('div', { class: 'acc-label', text: 'YOUR REFERRAL CODE' }), h('div', { class: 'acc-big', text: code })]), copyBtn(code, 'Copy')]) : null,
      n > 0 ? h('div', { class: 'acc-ok', text: '🎉 You have invited ' + n + ' friend' + (n === 1 ? '' : 's') + ' (+' + n + ' week' + (n === 1 ? '' : 's') + ' of Pro earned)' }) : null,
      h('hr'),
      h('b', { style: 'font-size:12px', text: 'Claim a Friend’s Invite Code' }),
      codeForm('INV-XXXX', 'invite', 'Claim 1 Week', '', function (c) {
        act('/api/referral/claim', { code: c }, function (r) { return r.message || 'Referral claimed!'; }).then(function () { if (!P.err) P.invite = ''; renderPage(); });
      })
    ]);
  }

  // Admin dashboard (AdminDashboardView); every rule is enforced in Supabase too.
  function loadAdmin(updateBank) {
    if (!(H.user && H.user.is_admin)) return;
    A.busy = true;
    return H.api('/api/admin/overview').then(function (o) {
      var sig = JSON.stringify(o);
      if (updateBank || !A.bank) {
        var b = o.bank || {};
        A.bank = { bank_name: b.bank_name || '', bank_bin: b.bank_bin || '', account_number: b.account_number || '', account_name: b.account_name || '' };
        A.amount = String(b.amount_vnd || 300000);
      }
      A.msg = '';
      if (sig === A.sig && !updateBank) return 'same';
      A.sig = sig; A.data = o;
    }).catch(function (e) { A.msg = e.message; }).then(function (same) {
      A.busy = false;
      if (page === 'admin' && H.destination === 'account' && same !== 'same') renderPage();
    });
  }
  function mutate(path, body) {
    A.busy = true; renderPage();
    return H.api(path, 'POST', body).then(function () { H.refreshAccount(); return loadAdmin(false); })
      .catch(function (e) { A.msg = e.message; A.busy = false; renderPage(); });
  }
  function banUser(u, reason) {
    ask({ title: 'Ban ' + (u.email || 'account') + '?', message: 'A banned account cannot run tasks, pay, or join a family until you unban it.',
      input: reason, placeholder: 'Reason (shown to the user)', confirm: 'Ban', danger: true })
      .then(function (r) { if (r !== null) mutate('/api/admin/ban', { user_id: u.id, ban: 'true', reason: r }); });
  }
  function buildAdmin(s) {
    s.appendChild(top('Admin Dashboard'));
    if (!(H.user && H.user.is_admin)) { s.appendChild(h('p', { class: 'note', text: 'Admin access required' })); return; }
    var o = A.data, dis = A.busy;
    s.appendChild(h('h3', { class: 'sec', text: 'Payment review' }));
    var pay = h('div', { class: 'card' }, [h('p', { class: 'note', text: 'Check your bank account before approving. Jarvis does not verify transfers automatically.' })]);
    if (o) {
      if (!o.pending.length) pay.appendChild(h('div', { class: 'acc-ok' }, ['✓ No payments waiting for review']));
      o.pending.forEach(function (t) {
        pay.appendChild(h('div', { class: 'acc-item' }, [
          h('strong', { text: t.name || t.email || t.user_id }),
          h('span', { class: 'sub', text: t.email || '' }),
          kv(t.id, Number(t.amount_vnd).toLocaleString() + ' VND'),
          h('span', { text: 'Transfer note: ' + t.bank_ref, style: 'user-select:text;overflow-wrap:anywhere' }),
          h('span', { class: 'sub', text: day(t.created_at) }),
          h('div', { class: 'row' }, [
            btn('Approve transaction', 'primary', function () { decide(t, true); }, { disabled: dis }),
            btn('Reject', 'danger', function () { decide(t, false); }, { disabled: dis })
          ])
        ]));
      });
    }
    s.appendChild(pay);

    s.appendChild(h('h3', { class: 'sec', text: 'Users' }));
    var users = h('div', { class: 'card' });
    (o ? o.users : []).forEach(function (u) {
      var plan = h('select', { 'aria-label': 'Change plan for ' + (u.email || u.name), disabled: dis }, [
        h('option', { value: '', text: 'Change plan…' }), h('option', { value: 'free', text: 'Free — 30 / month' }), h('option', { value: 'pro', text: 'Pro — unlimited' })]);
      plan.onchange = function () { if (plan.value) mutate('/api/admin/plan', { user_id: u.id, plan: plan.value }); };
      users.appendChild(h('div', { class: 'acc-item' }, [
        h('strong', { text: u.name || u.email }),
        h('span', { class: 'sub', text: u.email }),
        u.banned ? h('span', { class: 'acc-bad', text: '⊘ Banned' + (u.ban_reason ? ': ' + u.ban_reason : '') }) : null,
        h('div', { class: 'row' }, [
          h('span', { text: (u.plan === 'pro' ? 'Pro' : 'Free') + (u.is_admin ? ' · Admin' : ''), style: 'margin-right:auto' }),
          u.is_admin ? null : u.banned
            ? btn('Unban', '', function () { mutate('/api/admin/ban', { user_id: u.id, ban: 'false' }); }, { disabled: dis })
            : btn('Ban…', 'danger', function () { banUser(u, ''); }, { disabled: dis }),
          plan
        ])
      ]));
    });
    s.appendChild(users);

    s.appendChild(h('h3', { class: 'sec', text: 'Integrity reports' }));
    var reps = h('div', { class: 'card' }, [h('p', { class: 'note', text: 'Copies of Jarvis whose files do not match the published release. Review before banning — a report alone is not proof of abuse.' })]);
    if (o && o.reports) {
      if (!o.reports.length) reps.appendChild(h('div', { class: 'acc-ok', text: '✓ No reports' }));
      o.reports.forEach(function (r) {
        var files = r.mismatched_files || [], target = null;
        o.users.forEach(function (u) { if (u.id === r.user_id) target = u; });
        reps.appendChild(h('div', { class: 'acc-item' }, [
          h('strong', { text: r.name || r.email || r.user_id }),
          h('span', { class: 'sub', text: (r.email || '') + ' · v' + r.app_version }),
          h('span', { class: 'sub', text: day(r.created_at) }),
          h('div', { class: 'files', text: files.slice(0, 8).join('\n') + (files.length > 8 ? '\n…and ' + (files.length - 8) + ' more' : '') }),
          r.banned ? h('span', { class: 'acc-bad', text: '⊘ Account banned' })
            : target && !target.is_admin ? btn('Ban this account…', 'danger', function () { banUser(target, 'Modified app files'); }, { disabled: dis, style: 'align-self:flex-start' }) : null
        ]));
      });
    }
    s.appendChild(reps);

    s.appendChild(h('h3', { class: 'sec', text: 'Receiving bank' }));
    var b = A.bank || { bank_name: '', bank_bin: '', account_number: '', account_name: '' };
    function field(label, key, attrs) {
      var input = h('input', Object.assign({ type: 'text', value: key === 'amount' ? A.amount : b[key], autocomplete: 'off' }, attrs || {}));
      input.oninput = function () { if (key === 'amount') A.amount = input.value; else b[key] = input.value; };
      return h('label', { class: 'field' }, [label, input]);
    }
    s.appendChild(h('div', { class: 'card acc-form' }, [
      field('Bank name', 'bank_name'),
      field('VietQR bank BIN (6 digits)', 'bank_bin', { inputmode: 'numeric', maxLength: 6 }),
      field('Account number', 'account_number'),
      field('Account holder name', 'account_name'),
      field('Pro upgrade price (VND)', 'amount', { inputmode: 'numeric' }),
      h('div', { class: 'row end' }, [btn('Save bank details', 'primary', function () {
        var value = Number(A.amount);
        if (!/^\d+$/.test(A.amount.trim()) || value < 1000) { A.msg = 'Enter a price of at least 1,000 VND.'; renderPage(); return; }
        mutate('/api/admin/bank', { bank_name: b.bank_name, bank_bin: b.bank_bin, account_number: b.account_number, account_name: b.account_name, amount_vnd: String(value) });
      }, { disabled: dis })])
    ]));
    if (A.busy) s.appendChild(h('p', { class: 'note' }, [h('span', { class: 'acc-spin' }), ' Working…']));
    if (A.msg) s.appendChild(h('p', { class: 'acc-msg', role: 'alert', text: A.msg }));
    s.appendChild(h('div', { class: 'row' }, [btn('Refresh dashboard', '', function () { loadAdmin(true); }, { disabled: dis })]));
  }
  function decide(t, approve) {
    ask({
      title: approve ? 'Approve this payment?' : 'Reject this payment?',
      message: approve ? 'Approving activates Pro immediately. Confirm the amount and transfer note in your bank statement first.' : 'The user will remain on their current plan.',
      confirm: approve ? 'I verified receipt — approve Pro' : 'Reject payment', danger: !approve
    }).then(function (ok) { if (ok) mutate('/api/admin/transaction', { transaction_id: t.id, approve: approve }); });
  }
  // Mac refreshes the dashboard every 30 seconds while it is open.
  setInterval(function () {
    if (page === 'admin' && H.destination === 'account' && !A.busy && !document.querySelector('.acc-dlg')) loadAdmin(false);
  }, 30000);

  // ---------- wiring ----------
  H.on('view', function (dest) {
    if (dest === 'account') {
      if (basic) basic.hidden = true;
      page = nextPage || 'account'; nextPage = null;
      if (page === 'account') H.refreshAccount();
      show(page);
    }
    if (dest === 'settings') renderProfileCard();
    syncChrome();
  });
  H.on('boot', function (ok) { bootOk = ok; });
  H.on('reveal', function () { setTimeout(checkGate, 0); });
  // Accent changes recolour the symbol avatar.
  document.addEventListener('click', function (e) { if (e.target.closest('[data-accent]')) setTimeout(function () { paintAvatars(); renderProfileCard(); }, 0); });
  function repaint() {
    renderGate();
    if (H.destination === 'account') renderPage();
  }
  renderProfileCard();
  syncChrome();
  if (H.revealed) checkGate();
})();
