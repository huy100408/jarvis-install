#!/bin/bash
set -euo pipefail

# Install JARVIS Bridge as a user LaunchAgent on macOS (loopback 127.0.0.1:20128)

PLIST_NAME="com.jarvis.bridge.plist"
TARGET_DIR="${HOME}/Library/LaunchAgents"
TARGET_PATH="${TARGET_DIR}/${PLIST_NAME}"
BRIDGE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
NODE_BIN="$(command -v node)"

mkdir -p "${TARGET_DIR}"

echo "Creating LaunchAgent plist at ${TARGET_PATH}..."

cat <<EOF > "${TARGET_PATH}"
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>com.jarvis.bridge</string>
    <key>ProgramArguments</key>
    <array>
        <string>${NODE_BIN}</string>
        <string>dist/src/cli.js</string>
        <string>serve</string>
    </array>
    <key>WorkingDirectory</key>
    <string>${BRIDGE_DIR}</string>
    <key>RunAtLoad</key>
    <true/>
    <key>KeepAlive</key>
    <true/>
    <key>StandardOutPath</key>
    <string>${HOME}/Library/Application Support/JARVIS/bridge/server.stdout.log</string>
    <key>StandardErrorPath</key>
    <string>${HOME}/Library/Application Support/JARVIS/bridge/server.stderr.log</string>
    <key>EnvironmentVariables</key>
    <dict>
        <key>PATH</key>
        <string>/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin</string>
    </dict>
</dict>
</plist>
EOF

mkdir -p "${HOME}/Library/Application Support/JARVIS/bridge"
chmod 700 "${HOME}/Library/Application Support/JARVIS/bridge"
chmod 644 "${TARGET_PATH}"

echo "LaunchAgent installed."
echo "To start now: launchctl load ${TARGET_PATH}"
echo "To stop:      launchctl unload ${TARGET_PATH}"
