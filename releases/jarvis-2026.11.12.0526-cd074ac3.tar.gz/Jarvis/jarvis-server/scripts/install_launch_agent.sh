#!/bin/bash
set -euo pipefail

# Install JARVIS Server as a user LaunchAgent on macOS

PLIST_NAME="com.jarvis.server.plist"
TARGET_DIR="${HOME}/Library/LaunchAgents"
TARGET_PATH="${TARGET_DIR}/${PLIST_NAME}"
SERVER_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
CORE_DIR="$(cd "${SERVER_DIR}/../jarvis-core" && pwd)"

if [ -f "${SERVER_DIR}/../.venv/bin/python3" ]; then
  PYTHON_BIN="$(cd "${SERVER_DIR}/.." && pwd)/.venv/bin/python3"
elif [ -f "${SERVER_DIR}/../.venv312/bin/python3" ]; then
  PYTHON_BIN="$(cd "${SERVER_DIR}/.." && pwd)/.venv312/bin/python3"
elif [ -n "${VIRTUAL_ENV:-}" ] && [ -f "${VIRTUAL_ENV}/bin/python3" ]; then
  PYTHON_BIN="${VIRTUAL_ENV}/bin/python3"
else
  PYTHON_BIN="$(which python3)"
fi

"${PYTHON_BIN}" -m pip install -q "python-multipart>=0.0.9" 2>/dev/null || true

mkdir -p "${TARGET_DIR}"

echo "Creating LaunchAgent plist at ${TARGET_PATH}..."

cat <<EOF > "${TARGET_PATH}"
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>com.jarvis.server</string>
    <key>ProgramArguments</key>
    <array>
        <string>${PYTHON_BIN}</string>
        <string>-m</string>
        <string>jarvis_server</string>
        <string>serve</string>
    </array>
    <key>WorkingDirectory</key>
    <string>${SERVER_DIR}</string>
    <key>RunAtLoad</key>
    <true/>
    <key>KeepAlive</key>
    <true/>
    <key>StandardOutPath</key>
    <string>${HOME}/Library/Application Support/JARVIS/server/server.stdout.log</string>
    <key>StandardErrorPath</key>
    <string>${HOME}/Library/Application Support/JARVIS/server/server.stderr.log</string>
    <key>EnvironmentVariables</key>
    <dict>
        <key>PATH</key>
        <string>/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin:${HOME}/.local/bin</string>
        <key>PYTHONPATH</key>
        <string>${SERVER_DIR}/src:${CORE_DIR}/src</string>
    </dict>
</dict>
</plist>
EOF

mkdir -p "${HOME}/Library/Application Support/JARVIS/server"
chmod 644 "${TARGET_PATH}"

echo "LaunchAgent installed."
echo "To start now: launchctl load ${TARGET_PATH}"
echo "To stop:      launchctl unload ${TARGET_PATH}"
